﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class ExemplarRepositorio
    {
        public void Inserir(Exemplares model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Exemplares.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Exemplares model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
             
            }
        }

        public void Excluir(Exemplares model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Exemplares Localizar(int codigo)
        {
            Exemplares obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Exemplares
                       where e.Codigo_Exemplar == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public vw_ExemplarRepetido LocalizarExemplarRepetido(int codigoUsu, int codigoLivro)
        {
            vw_ExemplarRepetido obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_ExemplarRepetido
                       where e.Codigo_Usuario == codigoUsu && e.Codigo_Livro == codigoLivro
                       && e.Data_EfetivaDevolucao == null
                         select e).FirstOrDefault();
            }

            return obj;
        }

        public List<Exemplares> LocalizarCodigo(int codigo)
        {
            List<Exemplares> obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Exemplares
                       where e.Codigo_Exemplar == codigo
                       select e).ToList();
            }

            return obj;
        }

        public List<vw_LivroExemplar> LocalizarExemplar(String titulo)
        {
            List<vw_LivroExemplar> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.vw_LivroExemplar
                         where e.Titulo.Contains(titulo)
                         orderby e.Titulo
                         select e).ToList();
            }
            return lista;
        }

        public Exemplares LocalizarExemplar2(int codigo)
        {
            Exemplares obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Exemplares
                         join l in db.Livro
                         on e.Codigo_Livro equals l.Codigo_livro
                         where e.Codigo_Exemplar == codigo
                         select e).FirstOrDefault();
            }
            return obj;
        }

        public vw_LivroExemplarDisponivel LocalizarExemplarDisponivel(int codigo)
        {
            vw_LivroExemplarDisponivel obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_LivroExemplarDisponivel
                         where e.Exemplar == codigo
                         orderby e.Titulo
                         select e).FirstOrDefault();
            }
            return obj;
        }

        public List<vw_LivroExemplarDisponivel> LocalizarExemplarDisponivel(string titulo)
        {
            List<vw_LivroExemplarDisponivel> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.vw_LivroExemplarDisponivel
                       where e.Titulo.Contains(titulo)
                       orderby e.Titulo
                       select e).ToList();
            }
            return lista;
        }

        public void Excluir(int codigo)
        {
            Exemplares model = Localizar(codigo);

            if (model != null)
                Excluir(model);
        }
    }
}
