﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class EditoraRepositorio
    {
        public void Inserir(Editora model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Editora.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Editora model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Editora model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Editora Localizar(int codigo)
        {
            Editora obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Editora
                       where e.Codigo_Editora == codigo
                       select e).FirstOrDefault();
            }
            return obj;
        }

        public List<Editora> Localizar(String nome)
        {
            List<Editora> lista = null;
            using (BibliotecaEntities db =  new BibliotecaEntities())
            {
                lista = (from e in db.Editora
                         where e.Nome.Contains(nome)
                         orderby e.Nome
                         select e).ToList();
            }
            return lista;
        }

        public void Excluir(int codigo)
        {
            Editora model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public Editora LocalizaEditora(string nome)
        {
            Editora obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Editora
                       where e.Nome == nome
                       select e).FirstOrDefault();
            }
            return obj;
        }
    }
}
