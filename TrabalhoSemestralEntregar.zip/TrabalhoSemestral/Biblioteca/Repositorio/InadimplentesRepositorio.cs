﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class InadimplentesRepositorio
    {
        public void Inserir(Inadimplentes model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Inadimplentes.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Inadimplentes model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Inadimplentes model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Inadimplentes Localizar(int codigo)
        {
            Inadimplentes obj = null;

           using(BibliotecaEntities db = new BibliotecaEntities())
           {
                obj = (from i in db.Inadimplentes
                       where i.Codigo_Usuario == codigo
                       select i).FirstOrDefault();
           }

            return obj;
        }

        public void Excluir(int codigo)
        {
            Inadimplentes model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }
    }
}
