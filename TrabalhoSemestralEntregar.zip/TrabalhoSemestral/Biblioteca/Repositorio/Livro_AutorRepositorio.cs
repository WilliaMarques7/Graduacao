﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class Livro_AutorRepositorio
    {
        public void Inserir(Livro_Autor model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Livro_Autor.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Livro_Autor model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Livro_Autor model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Livro_Autor Localizar(int codigo)
        {
            Livro_Autor obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Livro_Autor
                       where e.Codigo_LiAu == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public List<vw_LivroAutor> LocalizarLivro(int codigo)
        {
            List < vw_LivroAutor> obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_LivroAutor
                       where e.Codigo_Livro == codigo
                       select e).ToList();
            }

            return obj;
        }

        public void Excluir(int codigo)
        {
            Livro_Autor model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public void ExcluirLivro(int codigo)
        {
            
            bool existe = true;
            while (existe == true)
            {
                Livro_Autor model = LocalizarExcluirLivro(codigo);
                if (model != null)
                    Excluir(model);
                else
                    existe = false;
            } 
        }

        public Livro_Autor LocalizarExcluirLivro(int codigo)
        {
            Livro_Autor obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Livro_Autor
                       where e.Codigo_Livro == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public List<Livro_Autor> LocalizarLivroTeste(int codigo)
        {
            List<Livro_Autor> obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Livro_Autor
                       where e.Codigo_Livro == codigo
                       select e).ToList();
            }

            return obj;
        }
    }
}
