﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class EmprestimoRepositorio
    {
        public void Inserir(Emprestimo model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Emprestimo.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Emprestimo model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Emprestimo model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Emprestimo Localizar(int codigoExemplar, int codigoUsuario)
        {
            Emprestimo obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Emprestimo
                       where e.Codigo_Exemplar == codigoExemplar
                       && e.Codigo_Usuario == codigoUsuario
                       && e.Data_EfetivaDevolucao == null
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public vw_QuantidadeLivrosUsuario LocalizaQuantidade(int codigo)
        {
            vw_QuantidadeLivrosUsuario obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_QuantidadeLivrosUsuario
                       where e.Codigo_Usuario == codigo
                       select e).FirstOrDefault();
            }
            return obj;
        }

        //public void Excluir(int codigo)
        //{
        //    Emprestimo model = Localizar(codigo);
        //    if (model != null)
        //        Excluir(model);
        //}

        public List<vw_EmprestimosPendentes> LocalizaEmprestimoUsu(int codigo)
        {
            List<vw_EmprestimosPendentes> lista = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.vw_EmprestimosPendentes
                         where e.Codigo_Usuario == codigo
                         orderby e.Data_Emprestimo
                         select e).ToList();
            }

            return lista;
        }

        public Emprestimo LocalizarUsuario(int codigo)
        {
            Emprestimo obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Emprestimo
                       where e.Codigo_Usuario == codigo
                       && e.Data_EfetivaDevolucao ==null
                       select e).FirstOrDefault();
            }

            return obj;
        }
    }
}
