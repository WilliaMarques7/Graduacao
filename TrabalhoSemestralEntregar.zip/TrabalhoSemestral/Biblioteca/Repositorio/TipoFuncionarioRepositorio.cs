﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class TipoFuncionarioRepositorio
    {
        public void Inserir(Tipo_Funcionario model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Tipo_Funcionario.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Tipo_Funcionario model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Tipo_Funcionario model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Tipo_Funcionario Localizar(int codigo)
        {
            Tipo_Funcionario obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Tipo_Funcionario
                       where e.Codigo_TipoFuncionario == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public Tipo_Funcionario LocalizaTipo(string tipo)
        {
            Tipo_Funcionario obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Tipo_Funcionario
                       where e.Tipo == tipo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public List<Tipo_Funcionario> Localizar(String tipo)
        {
            List<Tipo_Funcionario> lista = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Tipo_Funcionario
                         where e.Tipo.Contains(tipo)
                         orderby e.Tipo
                         select e).ToList();
            }

            return lista;
        }

        public void Excluir(int codigo)
        {
            Tipo_Funcionario model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }
    }
}
