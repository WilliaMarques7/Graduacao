﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class Livro_GeneroRepositorio
    {
        public void Inserir(Livro_Genero model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Livro_Genero.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Livro_Genero model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Livro_Genero model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Livro_Genero Localizar(int codigo)
        {
            Livro_Genero obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Livro_Genero
                       where e.Codigo_LivroGenero == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public void Excluir(int codigo)
        {
            Livro_Genero model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public List<vw_LivroGenero> LocalizarLivro(int codigo)
        {
            List<vw_LivroGenero> lista = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.vw_LivroGenero
                         where e.Codigo_livro == codigo
                         select e).ToList();
            }

            return lista;
        }

        public void ExcluirLivro(int codigo)
        {

            bool existe = true;
            while (existe == true)
            {
                Livro_Genero model = LocalizarExcluirLivro(codigo);
                if (model != null)
                    Excluir(model);
                else
                    existe = false;
            }
        }
        public Livro_Genero LocalizarExcluirLivro(int codigo)
        {
            Livro_Genero obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Livro_Genero
                       where e.Codigo_livro == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }
    }
}
