﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class MultaRepositorio
    {
        public void Inserir(Multa model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Multa.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Multa model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Multa model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Multa Localizar(int codigo)
        {
            Multa obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Multa
                       where e.Codigo_multa == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public List<Multa> Localizar(string mes)
        {
            List<Multa> lista = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Multa
                         where e.Data_Multa.Contains(mes)
                         orderby e.Data_Multa
                         select e).ToList();
            }

            return lista;
        }

        public vw_ValorAtual Localizar()
        {
            vw_ValorAtual obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_ValorAtual
                       orderby e.Data_Multa
                         select e).FirstOrDefault();
            }

            return obj;
        }

        public void Excluir(int codigo)
        {
            Multa model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }
    }
}
