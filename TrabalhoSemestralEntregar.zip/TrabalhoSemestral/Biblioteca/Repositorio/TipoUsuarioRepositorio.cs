﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class TipoUsuarioRepositorio
    {
        public void Inserir(TipoUsuario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.TipoUsuario.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(TipoUsuario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(TipoUsuario model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public TipoUsuario Localizar(int codigo)
        {
            TipoUsuario obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.TipoUsuario
                       where e.Codigo_TipoUsuario ==  codigo select e).FirstOrDefault();
            }
            return obj;
        }

        public List<TipoUsuario> Localizar(String tipo)
        {
            List<TipoUsuario> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.TipoUsuario
                         where e.Tipo.Contains(tipo)
                         orderby e.Tipo
                         select e).ToList();  
            }
            return lista;
        }

        public void Excluir(int codigo)
        {
            TipoUsuario model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public TipoUsuario LocalizarUsuario(string tipo)
        {
            TipoUsuario obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.TipoUsuario
                       where e.Tipo == tipo
                       select e).FirstOrDefault();
            }
            return obj;
        }

        public vw_PrazoUsuario LocalizaPrazo(int codigo)
        {
            vw_PrazoUsuario obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_PrazoUsuario
                       where e.Codigo_Usuario == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }
    }
}
