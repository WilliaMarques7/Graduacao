﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class AutorRepositorio
    {
        public void Inserir(Autor model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Autor.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Autor model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Autor model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Autor Localizar(int codigo)
        {
            Autor obj = null;
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Autor
                       where e.Codigo_Autor == codigo
                       select e).FirstOrDefault();
            }
            return obj;
        }

        public List<Autor> Localizar(String nome)
        {
            List<Autor> lista = null;
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Autor
                         where e.Nome.Contains(nome)
                         orderby e.Nome
                         select e).ToList();
            }
            return lista;
        }

        public void Excluir(int codigo)
        {
            Autor model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public Autor LocalizaAutor(string nome)
        {
            Autor obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Autor
                       where e.Nome == nome
                       select e).FirstOrDefault();
            }
            return obj;
        }
        //public void Inserir(string nome)
        //{
        //    Autor model = LocalizaAutor(nome);
        //    if (model != null)
        //        Inserir(model);
        //}

        public List<Autor> Localizar()
        {
            List<Autor> lista = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Autor
                         select e).ToList();
            }

            return lista;
        }
    }
}
