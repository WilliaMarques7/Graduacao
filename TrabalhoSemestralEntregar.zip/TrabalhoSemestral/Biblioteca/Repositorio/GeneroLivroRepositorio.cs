﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class GeneroLivroRepositorio
    {
        public void Inserir(Genero model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Genero.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Genero model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Genero model)
        {
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Genero Localizar(int codigo)
        {
            Genero obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Genero
                       where e.Codigo_Genero == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public List<Genero> Localizar(String genero)
        {
            List<Genero> lista = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Genero
                         where e.Tipo_Genero.Contains(genero)
                         orderby e.Tipo_Genero
                         select e).ToList();
            }

            return lista;
        }

        public void Excluir(int codigo)
        {
            Genero model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public Genero LocalizaGenero(string genero)
        {
            Genero obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Genero
                       where e.Tipo_Genero == genero
                       select e).FirstOrDefault();
            }

            return obj;
        }
    }
}
