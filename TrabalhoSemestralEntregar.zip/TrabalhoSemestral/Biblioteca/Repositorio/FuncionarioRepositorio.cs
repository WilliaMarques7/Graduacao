﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositorio
{
    public class FuncionarioRepositorio
    {
        public void Inserir(Funcionario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Funcionario.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Funcionario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Funcionario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Funcionario Localizar(int codigo)
        {
            Funcionario obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Funcionario
                       where e.Matricula == codigo
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public List<Funcionario> Localizar(String nome)
        {
            List<Funcionario> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Funcionario
                         where e.Nome.Contains(nome)
                         orderby e.Nome
                         select e).ToList();
            }
            return lista;
        }

        public void Excluir(int codigo)
        {
            Funcionario model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }

        public Funcionario LocalizaInsere(string login)
        {
            Funcionario obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Funcionario
                       where e.Login == login
                       select e).FirstOrDefault();
            }

            return obj;
        }

        public Funcionario LocalizaAltera(string login, int matricula)
        {
            Funcionario obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Funcionario
                       where e.Login == login
                       select e).FirstOrDefault();
            }

            return obj;

        }

        public vw_funcionario ValidaLogin(String Login, String Senha)
        {
            vw_funcionario obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.vw_funcionario
                       where e.Login == Login && e.Senha == Senha
                       select e).FirstOrDefault();
            }

            return obj;
        }
    }
}
