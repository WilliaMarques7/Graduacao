﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Repositorio
{
    public class LivroRepositorio
    {
        public void Inserir(Livro model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Livro.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Livro model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Livro model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public Livro Localizar(int codigo)
        {
            Livro obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Livro where e.Codigo_livro == codigo select e).FirstOrDefault();
            }
            return obj;
        }

        public List<Livro> Localizar(String titulo)
        {
            List<Livro> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Livro
                         where e.Titulo.Contains(titulo)
                         orderby e.Titulo
                         select e).ToList();
            }
            return lista;
        }

        public List<Livro> LocalizarExemplar(String titulo)
        {
            List<Livro> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from l in db.Livro
                         join e in db.Exemplares
                         on l.Codigo_livro equals e.Codigo_Livro
                         where l.Titulo.Contains(titulo)
                         orderby l.Titulo
                         select l).ToList();
            }
            return lista;
        }

        public void Excluir(int codigo)
        {
            Livro model = Localizar(codigo);
            if (model != null)
                Excluir(model);
        }
    }
}
