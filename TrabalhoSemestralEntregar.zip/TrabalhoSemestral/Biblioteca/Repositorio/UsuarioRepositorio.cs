﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Repositorio
{
    public class UsuarioRepositorio
    {
        public void Inserir(Usuario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Usuario.Add(model);
                db.SaveChanges();
            }
        }

        public void Alterar(Usuario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Excluir(Usuario model)
        {
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public void Excluir(int cpf)
        {
            Usuario model = Localizar(cpf);
            if (model != null)
                Excluir(model);
        }

        public Usuario Localizar(int codigo)
        {
            Usuario obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Usuario where e.Codigo_Usuario == codigo select e).FirstOrDefault();
            }
            return obj;
        }

        public Usuario LocalizaExiste(string nome)
        {
            Usuario obj = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from e in db.Usuario
                       where e.Nome == nome
                       select e).FirstOrDefault();
            }
            return obj;
        }

        public List<Usuario> Localizar(String nome)
        {
            List<Usuario> lista = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from e in db.Usuario
                         where e.Nome.Contains(nome)
                         orderby e.Nome
                         select e).ToList();
            }
            return lista;
        }

        public List<vw_UsuariosAtivos> LocalizarAtivos(string nome)
        {
            List<vw_UsuariosAtivos> lista = null;
            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from u in db.vw_UsuariosAtivos
                         where u.Nome.Contains(nome)
                         orderby u.Nome
                         select u).ToList();
            }
            return lista;
        }

        public vw_UsuariosAtivos LocalizarAtivos(int codigo)
        {
            vw_UsuariosAtivos obj = null;
            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from u in db.vw_UsuariosAtivos
                         where u.Codigo_Usuario == codigo
                         orderby u.Nome
                         select u).FirstOrDefault();
            }
            return obj;
        }

        public List<vw_UsuarioPgMulta> LocalizaUsuMulta(string nome)
        {
            List<vw_UsuarioPgMulta> lista = null;

            using(BibliotecaEntities db = new BibliotecaEntities())
            {
                lista = (from u in db.vw_UsuarioPgMulta
                         where u.nome.Contains(nome)
                         orderby u.nome
                         select u).ToList();
            }

            return lista;
        }
        public vw_UsuarioPgMulta LocalizaUsuMulta(int codigo)
        {
            vw_UsuarioPgMulta obj = null;

            using (BibliotecaEntities db = new BibliotecaEntities())
            {
                obj = (from u in db.vw_UsuarioPgMulta
                       where u.codigo_usuario == codigo
                       orderby u.nome
                       select u).FirstOrDefault();
            }

            return obj;
        }
    }
}
