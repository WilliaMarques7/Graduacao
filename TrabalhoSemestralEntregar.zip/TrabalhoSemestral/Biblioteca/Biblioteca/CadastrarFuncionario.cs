﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarFuncionario : Form
    {
        Funcionario model;

        public CadastrarFuncionario()
        {
            InitializeComponent();
        }

        private void CadastrarFuncionario_Load(object sender, EventArgs e)
        {
            model = new Funcionario();
            txtNome.Focus();

            cbTipoFunc.DataSource = (new TipoFuncionarioRepositorio()).Localizar("");
            cbTipoFunc.ValueMember = "Codigo_TipoFuncionario";
            cbTipoFunc.DisplayMember = "Tipo";
            cbTipoFunc.SelectedIndex = -1;
        }

        private void PbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        //public bool VerificaCPF(string strCPFCliente)
        //{
        //    string strCPFOriginal = strCPFCliente.Replace(".", "").Replace("-", "");
        //    string strCPF = Strings.Mid(strCPFOriginal, 1, 9);
        //    string strCPFTemp;
        //    int intSoma=0;
        //    int intResto;
        //    string strDigito;
        //    int intMultiplicador = 10;
        //    const int constIntMultiplicador = 11;
        //    int i;
        //    for (i = 0; i <= strCPF.ToString().Length - 1; i++)
        //    {
        //        intSoma += System.Convert.ToInt32(strCPF.ToString().Chars[i].ToString()) * intMultiplicador;
        //        intMultiplicador -= 1;
        //    }
        //    if ((intSoma % constIntMultiplicador) < 2)
        //        intResto = 0;
        //    else
        //        intResto = constIntMultiplicador - (intSoma % constIntMultiplicador);
        //    strDigito = intResto.ToString();
        //    intSoma = 0;
        //    strCPFTemp = strCPF + strDigito;
        //    intMultiplicador = 11;
        //    for (i = 0; i <= strCPFTemp.Length - 1; i++)
        //    {
        //        intSoma += System.Convert.ToInt32(strCPFTemp.Chars[i].ToString()) * intMultiplicador;
        //        intMultiplicador -= 1;
        //    }
        //    if ((intSoma % constIntMultiplicador) < 2)
        //        intResto = 0;
        //    else
        //        intResto = constIntMultiplicador - (intSoma % constIntMultiplicador);
        //    strDigito += intResto;
        //    if (strDigito == String.Substring(strCPFOriginal, int 10, strCPFOriginal.Length))
        //        return true;
        //    else
        //        return false;
        //}


        public void VerificaLabels()
        {
            if (txtNome.Text == "")
                lblInformeNome.Visible = true;
            if (txtCPF.Text == "")
                lblCpf.Visible = true;
            if (txtEmail.Text == "")
                lblInformaEmail.Visible = true;
            if (txtTelefone.Text == "")
                lblInformetelefone.Visible = true;
            if (rbFeminino.Checked == false && rbMasculino.Checked == false)
                lblInformeSexo.Visible = true;
            if (cbTipoFunc.SelectedIndex == -1)
                lblInformeCargo.Visible = true;
            if (txtLogin.Text == "")
                lblInformeLogin.Visible = true;
            if (txtSenha.Text == "")
                lblInformeSenha.Visible = true;
        }


        public bool VerificaPreenchidos()
        {
            bool retorno = true;

            if (txtNome.Text.Trim() != "" && txtCPF.Text.Trim() != "" &&
                txtEmail.Text.Trim() != "" && txtTelefone.Text.Trim() != "" &&
                txtLogin.Text.Trim() != "" && txtSenha.Text.Trim() != ""
                && cbTipoFunc.Text != "")
            {
                if(rbFeminino.Checked == true || rbMasculino.Checked == true)
                    retorno = true;
            }
            else
                retorno = false;

            VerificaLabels();

            return retorno;
        }

        public void LimpaTudo()
        {
            txtCodigo.Clear();
            txtCPF.Clear();
            txtEmail.Clear();
            txtLogin.Clear();
            txtNome.Clear();
            txtSenha.Clear();
            txtTelefone.Clear();
            
            rbFeminino.Checked = false;
            rbMasculino.Checked = false;
            cbTipoFunc.SelectedIndex = -1;
            
            lblInformeNome.Visible = false;
            lblCpf.Visible = false;
            lblInformaEmail.Visible = false;
            lblInformetelefone.Visible = false;
            lblInformeSexo.Visible = false;
            lblInformeCargo.Visible = false;
            lblInformeLogin.Visible = false;
            lblInformeSenha.Visible = false;

            HabDesab(false);
            HabDesab2(true);

            txtNome.Focus();
        }

        public void CarregaCampos()
        {
            txtNome.Text = model.Nome;
            txtCPF.Text = model.CPF;
            txtEmail.Text = model.Email;
            txtTelefone.Text = model.Telefone;
            txtLogin.Text = model.Login;
            txtSenha.Text = model.Senha;
            txtCodigo.Text = model.Matricula.ToString();
            cbTipoFunc.SelectedValue = model.Codigo_TipoFuncionario;

            if (model.Sexo == "Masculino")
                rbMasculino.Checked = true;
            else
                rbFeminino.Checked = true;
        }

        void CarregaProp()
        {
            model.Nome = txtNome.Text;
            model.CPF = txtCPF.Text;
            model.Email = txtEmail.Text;
            model.Telefone = txtTelefone.Text;
            model.Login = txtLogin.Text;
            model.Senha = txtSenha.Text;
            model.Codigo_TipoFuncionario = (int)cbTipoFunc.SelectedValue;

            if (rbFeminino.Checked == true)
                model.Sexo = rbFeminino.Text;
            if(rbMasculino.Checked == true)
                model.Sexo = rbMasculino.Text;

            if (txtCodigo.Text == "")
                model.Matricula = 0;
            else
                model.Matricula = int.Parse(txtCodigo.Text);
        }

        public void HabDesab(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;
        }

        public void HabDesab2(bool status)
        {
            btnSalvar.Enabled = status;
            btnProcura.Enabled = status;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaPreenchidos() ==  true)
                {
                    CarregaProp();
                    if (txtCodigo.Text == "")
                    {
                        if ((new FuncionarioRepositorio()).LocalizaInsere(txtLogin.Text) == null)
                        {
                            (new FuncionarioRepositorio()).Inserir(model);
                            MessageBox.Show("Funcionário cadastardo com sucesso!");
                            LimpaTudo();
                        }
                        else
                        {
                            MessageBox.Show("Login já está sendo usado");
                            lblNovoLogin.Visible = true;
                        } 
                    }
                    else
                        (new FuncionarioRepositorio()).Alterar(model);
                }
                else
                    MessageBox.Show("Preencha todos os campos!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void BtnNovo_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaTudo();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro!");
            }
        }

        private void BtnProcura_Click(object sender, EventArgs e)
        {
            try
            {
                LocalizaFuncionario frm = new LocalizaFuncionario();
                frm.ShowDialog();

                if (frm.codigo != 0)
                {
                    model = (new FuncionarioRepositorio()).Localizar(frm.codigo);
                    CarregaCampos();
                    HabDesab(true);
                    HabDesab2(false);
                }

                frm.Dispose();
                frm = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaPreenchidos())
                {
                    CarregaProp();
                    
                    if ((new FuncionarioRepositorio().LocalizaInsere(txtLogin.Text)) == null ||
                        (new FuncionarioRepositorio().LocalizaInsere(txtLogin.Text)).Matricula == model.Matricula)
                    {
                        (new FuncionarioRepositorio()).Alterar(model);
                        MessageBox.Show("Alterado com sucesso!");
                        LimpaTudo();
                    }
                    else
                    {
                        MessageBox.Show("Login já está sendo usado!");
                        lblNovoLogin.Visible = true;
                    }
                }
                
                else
                    MessageBox.Show("Nenhum campo pode estar vazio!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaPreenchidos())
                {
                    (new FuncionarioRepositorio()).Excluir(model);
                    LimpaTudo();
                    MessageBox.Show("Registro excluído com sucesso!");
                    HabDesab(false);
                    HabDesab2(true);
                }
                else
                    MessageBox.Show("Nenhum campo pode estar vazio!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir!");
            }
        }

        private void TxtLogin_Click(object sender, EventArgs e)
        {
            lblNovoLogin.Visible = false;
            lblInformeLogin.Visible = false;
        }

        private void txtNome_Click(object sender, EventArgs e)
        {
            lblInformeNome.Visible = false;
        }

        private void txtEmail_Click(object sender, EventArgs e)
        {
            lblInformaEmail.Visible = false;
        }

        private void txtCPF_Click(object sender, EventArgs e)
        {
            lblCpf.Visible = false;
        }

        private void txtTelefone_Click(object sender, EventArgs e)
        {
            lblInformetelefone.Visible = false;
        }

        private void rbFeminino_Click(object sender, EventArgs e)
        {
            lblInformeSexo.Visible = false;
        }

        private void rbMasculino_Click(object sender, EventArgs e)
        {
            lblInformeSexo.Visible = false;
        }

        private void cbTipoFunc_Click(object sender, EventArgs e)
        {
            lblInformeCargo.Visible = false;
        }

        private void txtSenha_Click(object sender, EventArgs e)
        {
            lblInformeSenha.Visible = false;
        }

        private void txtCPF_Leave(object sender, EventArgs e)
        {
            if(txtCPF.Text!="")
            {
                if (Funcoes.ValidaCPF(txtCPF.Text)==false || txtCPF.Text == "00000000000")
                {
                    MessageBox.Show("CPF Inválido!");
                    txtCPF.Text = "";
                }
            }
        }
    }
}
