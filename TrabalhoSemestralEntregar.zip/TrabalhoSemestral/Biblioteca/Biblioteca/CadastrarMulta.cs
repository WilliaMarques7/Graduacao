﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarMulta : Form
    {
        Multa model;
        public int codigo;

        public CadastrarMulta()
        {
            InitializeComponent();
        }
        private void CadastrarMulta_Load(object sender, EventArgs e)
        {
            model = new Multa();
            txtValorMulta.Focus();

            Habilita(false);
            Habilita2(true);
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void Habilita(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;

            if (btnAlterar.Enabled == false)
            {
                btnAlterar.BackColor = Color.LightGray;
                btnAlterar.ForeColor = Color.Black;
            }
            else
            {
                btnAlterar.BackColor = Color.FromArgb(0, 122, 204);
                btnAlterar.ForeColor = Color.White;
            }

            if (btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void Habilita2(bool status)
        {
            btnSalvar.Enabled = status;

            if (btnSalvar.Enabled == false)
            {
                btnSalvar.BackColor = Color.LightGray;
                btnSalvar.ForeColor = Color.Black;
            }
            else
            {
                btnSalvar.BackColor = Color.FromArgb(0, 122, 204);
                btnSalvar.ForeColor = Color.White;
            }
        }

        public void LimpaGeral()
        {
            txtCodigo.Clear();
            txtValorMulta.Clear();
            txtPesquisaMulta.Clear();

            for (int i = 0; i < dgvResultadosBusca.Rows.Count; i++)
            {
                dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
            }

            Habilita(false);
            Habilita2(true);

            txtValorMulta.Focus();
        }

        private void txtValorMulta_Click(object sender, EventArgs e)
        {
            lblAviso.Visible = false;
        }

        public void CarregaProp()
        {
            model.Valor_Multa = Decimal.Parse(txtValorMulta.Text);

            if (txtCodigo.Text == "")
                model.Codigo_multa = 0;
            else
                model.Codigo_multa = int.Parse(txtCodigo.Text);

            model.Data_Multa = DateTime.Now.ToLongDateString();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtValorMulta.Text != "")
                {
                    CarregaProp();

                    if (txtCodigo.Text == "")
                    {
                        (new MultaRepositorio()).Inserir(model);
                        btnNovoRegistro_Click(sender, e);
                        MessageBox.Show("Multa cadastrada com sucesso!");
                    }
                    else
                        (new MultaRepositorio()).Alterar(model);
                }
                else
                {
                    MessageBox.Show("Informe o valor da multa!");
                    lblAviso.Visible = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaGeral();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao limpar!");
            }
        }

        private void btnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                dgvResultadosBusca.DataSource =
                    (new MultaRepositorio()).Localizar(txtPesquisaMulta.Text);

                for (int i = 2; i < dgvResultadosBusca.Rows.Count; i++)
                {
                    dgvResultadosBusca.Columns[i].Visible = false;
                }

                dgvResultadosBusca.Columns[0].HeaderText = "Código";
                dgvResultadosBusca.Columns[1].HeaderText = "Valor";
                dgvResultadosBusca.Columns[2].HeaderText = "Data";
                dgvResultadosBusca.Columns[0].Width = 60;
                dgvResultadosBusca.Columns[1].Width = 60;
                dgvResultadosBusca.Columns[2].Width = 243;
                
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao procurar!");
            }
        }

        private void dgvResultadosBusca_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvResultadosBusca.Rows[e.RowIndex].Cells["Codigo_multa"].Value;
            if(codigo != 0)
            {
                model = (new MultaRepositorio()).Localizar(codigo);
                txtCodigo.Text = model.Codigo_multa.ToString();
                txtValorMulta.Text = model.Valor_Multa.ToString();
                Habilita(true);
                Habilita2(false);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtValorMulta.Text != "")
                {
                    CarregaProp();

                    (new MultaRepositorio()).Alterar(model);
                    btnNovoRegistro_Click(sender, e);
                    MessageBox.Show("Registro alterado com sucesso!");
                }
                else
                    MessageBox.Show("Informe o novo valor de multa!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtValorMulta.Text != "" && txtCodigo.Text != "")
                {
                    if(MessageBox.Show("Tem certeza que deseja excluir o registro?", "Atenção!",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation,
                        MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        (new MultaRepositorio()).Excluir(model);
                        btnNovoRegistro_Click(sender, e);
                        MessageBox.Show("Registro excluído com sucesso!");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir!");
            }
        }
    }
}
