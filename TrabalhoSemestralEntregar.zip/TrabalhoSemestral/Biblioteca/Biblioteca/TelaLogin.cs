﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class TelaLogin : Form
    {
        
        public TelaLogin()
        {
            InitializeComponent();
            //Mostrar();
        }

        //private void Mostrar()
        //{
        //    FundoInicial obj2 = new FundoInicial();
        //    obj2.Show();
        //    obj2.Location = new Point(this.Width + this.Location.X, this.Location.Y);
        //}

        private void BtnAcessar_Click(object sender, EventArgs e)
        {
            try
            {
                vw_funcionario funcionario = 
                    new FuncionarioRepositorio().ValidaLogin(txtLogin.Text.Trim(), txtSenha.Text.Trim());
                
                if(txtLogin.Text != "" && txtSenha.Text != "")
                {
                    if (funcionario != null)
                    {
                        MenuInicial frm = new MenuInicial();
                        frm.nome = funcionario.Nome;
                        frm.email = funcionario.Email;
                        frm.cargo = funcionario.cargo;
                        frm.codFun = funcionario.Matricula;
                        frm.ShowDialog();
                        frm.Dispose();
                        
                        EsconderLabels();
                        esconderTelaLogin();
                        // chamarMenu();
                    }
                    else
                    {
                        lblLoginSenha.Visible = true;
                        lblLoginSenha.Text = "Login e/ou senha incorreto(s)!";
                    }
                }
                else
                    MessageBox.Show("Preencha todos os campos!");
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao logar!");
            }
        }

        public void EsconderLabels()
        {
            lblLoginSenha.Visible = false;
        }

        public void chamarMenu()
        {
            MenuInicial frm = new MenuInicial();
            
            frm.ShowDialog();
            frm.Dispose();
        }

        public void esconderTelaLogin()
        {
            TelaLogin login = new TelaLogin();
            txtLogin.Text = "usuário";
            txtLogin.ForeColor = Color.DimGray;
            txtSenha.Text = "senha";
            txtSenha.ForeColor = Color.DimGray;
            txtSenha.UseSystemPasswordChar = false;
            login.Hide();
        }

        private void TxtLogin_Enter(object sender, EventArgs e)
        {
            if(txtLogin.Text == "usuário")
            {
                txtLogin.Text = "";
                txtLogin.ForeColor = Color.LightGray;
                EsconderLabels();
            }
        }
        private void TxtSenha_Enter(object sender, EventArgs e)
        {
            if(txtSenha.Text == "senha")
            {
                txtSenha.Text = "";
                txtSenha.ForeColor = Color.LightGray;
                txtSenha.UseSystemPasswordChar = true;
                EsconderLabels();
            }
        }

        private void TxtLogin_Leave(object sender, EventArgs e)
        {
            if (txtLogin.Text == "")
            {
                txtLogin.Text = "usuário";
                txtLogin.ForeColor = Color.DimGray;
                EsconderLabels();
            }
        }

        private void TxtSenha_Leave_1(object sender, EventArgs e)
        {
            if (txtSenha.Text == "")
            {
                txtSenha.Text = "senha";
                txtSenha.ForeColor = Color.DimGray;
                txtSenha.UseSystemPasswordChar = false;
                EsconderLabels();
            }
        }


        private void PbFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PbMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void txtLogin_Click(object sender, EventArgs e)
        {
            lblLoginSenha.Visible = false;
        }

        private void txtSenha_Click(object sender, EventArgs e)
        {
            lblLoginSenha.Visible = false;
        }

        private void txtLogin_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if(e.KeyCode == Keys.Enter)
                {
                    BtnAcessar_Click(sender, e);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao logar");
            }
        }

        private void txtSenha_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if(e.KeyCode == Keys.Enter)
                {
                    BtnAcessar_Click(sender, e);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao logar!");
            }
        }
    }
}
