﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class LocalizaUsuario : Form
    {
        public int codigo;
        public int tipoConsulta;

        public LocalizaUsuario()
        {
            InitializeComponent();
        }

        private void LocalizaUsuario_Load(object sender, EventArgs e)
        {
            txtUsuario.Focus();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            switch (tipoConsulta)
            {
                case 1:
                    dgvLocalizaUsuario.DataSource =
                        (new UsuarioRepositorio()).LocalizarAtivos(txtUsuario.Text);
                    break;
                case 2:
                    dgvLocalizaUsuario.DataSource =
                        (new UsuarioRepositorio()).LocalizaUsuMulta(txtUsuario.Text);
                    break;
                default:
                    dgvLocalizaUsuario.DataSource =
                (new UsuarioRepositorio()).Localizar(txtUsuario.Text);
                    break;
            }

            for (int i = 3; i < dgvLocalizaUsuario.Columns.Count; i++)
            {
                dgvLocalizaUsuario.Columns[i].Visible = false;
            }

            dgvLocalizaUsuario.Columns[0].HeaderText = "Código";
            dgvLocalizaUsuario.Columns[2].HeaderText = "Usuário";
            dgvLocalizaUsuario.Columns[0].Width = 50;
            dgvLocalizaUsuario.Columns[2].Width = 300;
            dgvLocalizaUsuario.Columns.Remove("TipoUsuario_codigo");
        }

        private void dgvLocalizaUsuario_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvLocalizaUsuario.Rows[e.RowIndex].Cells["Codigo_Usuario"].Value;
            this.Close();
        }
    }
}
