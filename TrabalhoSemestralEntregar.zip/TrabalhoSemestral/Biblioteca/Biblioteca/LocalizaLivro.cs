﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class LocalizaLivro : Form
    {

        public int codigo;

        public LocalizaLivro()
        {
            InitializeComponent();
        }

        private void LocalizaLivro_Load(object sender, EventArgs e)
        {
            txtLivro.Focus();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            dgvLocalizaLivro.DataSource =
                (new LivroRepositorio()).Localizar(txtLivro.Text);

            for (int i = 2; i < dgvLocalizaLivro.Columns.Count; i++)
            {
                dgvLocalizaLivro.Columns[0].HeaderText = "Código";
                dgvLocalizaLivro.Columns[1].HeaderText = "Título";
                dgvLocalizaLivro.Columns[0].Width = 50;
                dgvLocalizaLivro.Columns[1].Width = 300;
            }
        }

        private void dgvLocalizaLivro_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvLocalizaLivro.Rows[e.RowIndex].Cells["Codigo_livro"].Value;
            this.Close();
        }

        private void dgvLocalizaLivro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
