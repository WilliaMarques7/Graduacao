﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarGenLivro : Form
    {
        Genero model;
        public int codigo;

        public CadastrarGenLivro()
        {
            InitializeComponent();
        }

        private void CadastrarGenLivro_Load(object sender, EventArgs e)
        {
            model = new Genero();
            txtGenero.Focus();
            HabDesab1(false);
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void HabDesab1(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;

            if(btnAlterar.Enabled == false)
            {
                btnAlterar.BackColor = Color.LightGray;
                btnAlterar.ForeColor = Color.Black;
            }
            else
            {
                btnAlterar.BackColor = Color.FromArgb(0,122,204);
                btnAlterar.ForeColor = Color.White;
            }

            if(btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void HabDesan2(bool status)
        {
            btnSalvar.Enabled = status;

            if (btnSalvar.Enabled == false)
            {
                btnSalvar.BackColor = Color.LightGray;
                btnSalvar.ForeColor = Color.Black;
            }
            else
            {
                btnSalvar.BackColor = Color.FromArgb(0, 122, 204);
                btnSalvar.ForeColor = Color.White;
            }
        }

        public void LimpaTudo()
        {
            txtGenero.Clear();
            txtCodigo.Clear();
            txtGenero.Focus();

            HabDesab1(false);
            HabDesan2(true);

            for (int i = 0; i < dgvResultadosBusca.RowCount; i++)
            {
                dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
            }

            txtGenero.Focus();
        }

        public bool VerificaCampos()
        {
            bool retorno = false;

            if (txtGenero.Text != "")
                retorno = true;
            else
                retorno = false;

            return retorno;
        }

        public void CarregaProp()
        {
            model.Tipo_Genero = txtGenero.Text;
            if (txtCodigo.Text == "")
                model.Codigo_Genero = 0;
            else
                model.Codigo_Genero = int.Parse(txtCodigo.Text);
        }

        public void CarregaCampos()
        {
            txtGenero.Text = model.Tipo_Genero;
            txtCodigo.Text = model.Codigo_Genero.ToString();
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaTudo();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao criar novo registro!");
            }
        }

        private void txtGenero_Click(object sender, EventArgs e)
        {
            lbInformeGenero.Visible = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if(txtCodigo.Text == "")
                    {
                        if ((new GeneroLivroRepositorio()).LocalizaGenero(txtGenero.Text) == null)
                        {
                            (new GeneroLivroRepositorio()).Inserir(model);
                            LimpaTudo();
                            MessageBox.Show("Registro salvo com sucesso!");
                        }
                        else
                        {
                            MessageBox.Show("O gênero informado já foi cadastrado!");
                            lbInformeGenero.Visible = true;
                        }
                    }
                    else
                    {
                        (new GeneroLivroRepositorio()).Alterar(model);
                        LimpaTudo();
                    }
                }
                else
                {
                    MessageBox.Show("O campo gênero não pode estar vazio!");
                    lbInformeGenero.Visible = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void btnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                dgvResultadosBusca.DataSource =
                    (new GeneroLivroRepositorio()).Localizar(txtBuscaGenero.Text);

                for (int i = 2; i < dgvResultadosBusca.Columns.Count; i++)
                {
                    dgvResultadosBusca.Columns[i].Visible = false;
                }

                dgvResultadosBusca.Columns[0].HeaderText = "Codigo";
                dgvResultadosBusca.Columns[1].HeaderText = "Gênero";
                dgvResultadosBusca.Columns[0].Width = 60;
                dgvResultadosBusca.Columns[1].Width = 240;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao localizar!");
            }
        }

        private void dgvResultadosBusca_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvResultadosBusca.Rows[e.RowIndex].Cells["Codigo_Genero"].Value;

            if(codigo != 0)
            {
                model = (new GeneroLivroRepositorio()).Localizar(codigo);
                CarregaCampos();
                HabDesab1(true);
                HabDesan2(false);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if((new GeneroLivroRepositorio()).LocalizaGenero(txtGenero.Text) == null)
                    {
                        (new GeneroLivroRepositorio()).Alterar(model);
                        LimpaTudo(); 
                        MessageBox.Show("Registro alterado com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("O gênero informado já foi cadastrado!");
                        lbInformeGenero.Visible = true;
                    }
                }
                else
                {
                    MessageBox.Show("O campo gênero não pode estar vazio!");
                    lbInformeGenero.Visible = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                        (new GeneroLivroRepositorio()).Excluir(model);
                        LimpaTudo();
                        MessageBox.Show("Registro excluido com sucesso!");
                }
                else
                {
                    MessageBox.Show("O campo gênero não pode estar vazio!");
                    lbInformeGenero.Visible = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluír!");
            }
        }
    }
}
