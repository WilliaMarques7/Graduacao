﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;
using Biblioteca.Relatorios;

namespace Biblioteca
{
    public partial class Gerenciamento : Form
    {
        private Form objetFormulario;

        public Gerenciamento()
        {
            InitializeComponent();
            customizaBotoes();
        }

        public void btnMouseHover(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.FlatAppearance.BorderSize = 1;
            botaoNovo.FlatAppearance.BorderColor = Color.White;
        }

        public void btnLeave(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.FlatAppearance.BorderSize = 0;
        }

        private void PbFechar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void AbrirFormPainel(object FormNoPainel)
        {
            objetFormulario?.Close();
            objetFormulario = FormNoPainel as Form;
            objetFormulario.TopLevel = false;
            objetFormulario.Dock = DockStyle.Fill;

            this.painelContainer.Controls.Add(objetFormulario);
            this.painelContainer.Tag = objetFormulario;

            objetFormulario.Show();
        }

        private void BtnNovoFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormPainel(new CadastrarFuncionario());
                lbTitulo.Text = "Novo funcionário";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void BtnNovoTUsu_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormPainel(new CadastroTipoUsuario());
                lbTitulo.Text = "Novo tipo de usuário";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void btnNovoTipoFunc_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormPainel(new CadastrarTipoFuncionario());
                lbTitulo.Text = "Novo tipo de funcionário";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void btnCadGenLivro_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormPainel(new CadastrarGenLivro());
                lbTitulo.Text = "Gênero literário";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void btnValorMulta_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormPainel(new CadastrarMulta());
                lbTitulo.Text = "Cadastro valor da multa";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void painelContainer_ControlRemoved(object sender, ControlEventArgs e)
        {
            lbTitulo.Text = "Acesso restrito - Área de gerenciamento do sistema";
        }

        private void btnRelatorios_Click(object sender, EventArgs e)
        {
            mostraSubmenu(painelRetratil);
        }

        private void mostraSubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                escondeSubmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }

        private void escondeSubmenu()
        {
            if (painelRetratil.Visible == true)
                painelRetratil.Visible = false;
        }
        private void customizaBotoes()
        {
            painelRetratil.Visible = false;
        }

        private void btnRelatUsu_Click(object sender, EventArgs e)
        {
            try
            {
                frmRelatorios rel = new frmRelatorios();
                rpt_Usuarios rpt = new rpt_Usuarios();
                rel.crystalReportViewer1.ReportSource = rpt;
                rel.crystalReportViewer1.Refresh();
                AbrirFormPainel(rel);
                escondeSubmenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir! Erro: " + ex.Message);
            }
        }

        private void btnRelatEmp_Click(object sender, EventArgs e)
        {
            try
            {
                frmRelatorios rel = new frmRelatorios();
                rptEmprestimos rpt = new rptEmprestimos();
                rel.crystalReportViewer1.ReportSource = rpt;
                rel.crystalReportViewer1.Refresh();
                AbrirFormPainel(rel);
                escondeSubmenu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir! Erro: " + ex.Message);
            }
        }

        private void btnRelatMulta_Click(object sender, EventArgs e)
        {
            try
            {
                frmRelatorios rel = new frmRelatorios();
                rtpMultaPendente rpt = new rtpMultaPendente();
                rel.crystalReportViewer1.ReportSource = rpt;
                rel.crystalReportViewer1.Refresh();
                AbrirFormPainel(rel);
                escondeSubmenu();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir! Erro: " + ex.Message);
            }
        }

        public void btn_MouseHover2(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.ForeColor = Color.Black;
        }

        public void btn_Leave2(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.ForeColor = Color.White;
            botaoNovo.BackColor = Color.FromArgb(153,180,209);
        }
    }
}
