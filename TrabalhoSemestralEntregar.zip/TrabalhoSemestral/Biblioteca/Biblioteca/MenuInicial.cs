﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class MenuInicial : Form
    {
        public string nome, email,cargo;
        public int codFun;
        private Form objetFormulario;

        public MenuInicial()
        {
            InitializeComponent();
            customizaBotoes();
        }

        private void MenuInicial_Load(object sender, EventArgs e)
        {
            lblFuncionario.Text = nome;
            lblEmail.Text = email;
            lblCargo.Text = cargo;
            lblCodFun.Text = codFun.ToString();

            if (lblCargo.Text == "Coordenador")
                btnGerenciamento.Visible = true;
            else
                btnGerenciamento.Visible = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Atenção!",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                this.Close();
        }

        private void PbFecharMenu_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo encerrar o programa?", "Atenção!",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                Application.Exit();
        }

        private void PbMinimizaMenu_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        public void AbrirFormNoPainel(object formNoPainel)
        {
            //verificar se há formulario já usando o painel
            objetFormulario?.Close(); //fecha formulario
        
            //istancia novo formulario recebendo o passado por parâmetro
            objetFormulario = formNoPainel as Form;
            objetFormulario.TopLevel = false;
            objetFormulario.Dock = DockStyle.Fill;

            this.panelContainer.Controls.Add(objetFormulario);
            this.panelContainer.Tag = objetFormulario;

            objetFormulario.Show();
        }

        private void BtnRealizaEmprestimo_Click(object sender, EventArgs e)
        {
            try
            {
                RealizaEmprestimo realiza = new RealizaEmprestimo();
                realiza.nome = lblFuncionario.Text;
                realiza.cargo = lblCargo.Text;
                realiza.codigoFun = lblCodFun.Text;
                AbrirFormNoPainel(realiza);
                
                lbTitulo.Text = "Empréstimo de Livros";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!"); ;
            }
        }

        private void BtnCadastrarUsuario_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new CadastroUsuarios());
                lbTitulo.Text = "Cadastro de Usuários";
                escondeSubmenu();
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao abrir!");
            }
        }

        public void BtnAutor_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new CadastrarAutor());
                lbTitulo.Text = "Cadastro de Autor(a)";
                escondeSubmenu();
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void BtnCadastrarEditora_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new CadastrarEditora());
                lbTitulo.Text = "Cadastro de Editora";
                escondeSubmenu();
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao abrir!");
            }
        }

        public void btn_MouseHover(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.FlatAppearance.BorderSize = 1;
            botaoNovo.FlatAppearance.BorderColor = Color.White;
            botaoNovo.ForeColor = Color.White;
        }

        public void btn_Leave(object sender, EventArgs e)
        {
            Button botaoLeave = (Button)sender;
            botaoLeave.FlatAppearance.BorderSize = 0;
            botaoLeave.ForeColor = Color.LightGray;
        }

        public void btn_MouseHover2(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.ForeColor = Color.Black;
        }

        public void btn_Leave2(object sender, EventArgs e)
        {
            Button botaoNovo = (Button)sender;
            botaoNovo.ForeColor = Color.LightGray;
            botaoNovo.BackColor = Color.FromArgb(64,64,64);
        }

        private void customizaBotoes()
        {
            painelRetratil.Visible = false;
        }

        private void escondeSubmenu()
        {
            if (painelRetratil.Visible == true)
                painelRetratil.Visible = false;
        }

        private void mostraSubmenu(Panel submenu)   
        {
            if (submenu.Visible == false)
            {
                escondeSubmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }

        private void BtnCadastros_Click(object sender, EventArgs e)
        {
            mostraSubmenu(painelRetratil);
        }

        private void BtnGerenciamento_Click(object sender, EventArgs e)
        {
            try
            {
                Gerenciamento frm = new Gerenciamento();
                frm.ShowDialog();
                frm.Dispose();
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }

        private void btnCadastrarLivro_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new CadastrarLivro());
                lbTitulo.Text = "Cadastro de livro";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }

        private void btnCadastrarGenero_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new CadastrarGenLivro());
                lbTitulo.Text = "Gênero literário";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }

        private void btnPagaMulta_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new PagaMulta());
                lbTitulo.Text = "Pagamento de multa";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }

        private void panelContainer_ControlRemoved(object sender, ControlEventArgs e)
        {
            lbTitulo.Text = "Bem vindo!";
        }


        private void BtnDevolucao_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new DevolucaoLivros());
                lbTitulo.Text = "Devolucão de livros";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }

        private void btnMultas_Click(object sender, EventArgs e)
        {
            try
            {
                AbrirFormNoPainel(new ConsultaMulta());
                lbTitulo.Text = "Histórico de multas";
                escondeSubmenu();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }
    }
}
