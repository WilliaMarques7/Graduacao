﻿namespace Biblioteca
{
    partial class MenuInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuInicial));
            this.btnSair = new JThinButton.JThinButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnRealizaEmprestimo = new System.Windows.Forms.Button();
            this.btnPagaMulta = new System.Windows.Forms.Button();
            this.btnGerenciamento = new System.Windows.Forms.Button();
            this.btnDevolucao = new System.Windows.Forms.Button();
            this.btnMultas = new System.Windows.Forms.Button();
            this.painelRetratil = new System.Windows.Forms.Panel();
            this.btnCadastrarUsuario = new System.Windows.Forms.Button();
            this.btnCadastrarLivro = new System.Windows.Forms.Button();
            this.btnCadastrarGenero = new System.Windows.Forms.Button();
            this.btnCadastrarEditora = new System.Windows.Forms.Button();
            this.btnAutor = new System.Windows.Forms.Button();
            this.btnCadastros = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblFuncionario = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCodFun = new System.Windows.Forms.Label();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbMinimizaMenu = new System.Windows.Forms.PictureBox();
            this.pbFecharMenu = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panelContainer = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.painelRetratil.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMinimizaMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFecharMenu)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Transparent;
            this.btnSair.BackgroundColor = System.Drawing.SystemColors.Highlight;
            this.btnSair.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnSair.BorderRadius = 11;
            this.btnSair.ButtonText = "  Sair";
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Font_Size = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColors = System.Drawing.Color.White;
            this.btnSair.HoverBackground = System.Drawing.SystemColors.HotTrack;
            this.btnSair.HoverBorder = System.Drawing.SystemColors.HotTrack;
            this.btnSair.HoverFontColor = System.Drawing.Color.White;
            this.btnSair.LineThickness = 2;
            this.btnSair.Location = new System.Drawing.Point(4, 567);
            this.btnSair.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(68, 25);
            this.btnSair.TabIndex = 7;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnRealizaEmprestimo);
            this.panel1.Controls.Add(this.btnSair);
            this.panel1.Controls.Add(this.btnPagaMulta);
            this.panel1.Controls.Add(this.btnGerenciamento);
            this.panel1.Controls.Add(this.btnDevolucao);
            this.panel1.Controls.Add(this.btnMultas);
            this.panel1.Controls.Add(this.painelRetratil);
            this.panel1.Controls.Add(this.btnCadastros);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 598);
            this.panel1.TabIndex = 4;
            // 
            // btnRealizaEmprestimo
            // 
            this.btnRealizaEmprestimo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnRealizaEmprestimo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRealizaEmprestimo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRealizaEmprestimo.FlatAppearance.BorderSize = 0;
            this.btnRealizaEmprestimo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnRealizaEmprestimo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnRealizaEmprestimo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRealizaEmprestimo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRealizaEmprestimo.ForeColor = System.Drawing.Color.LightGray;
            this.btnRealizaEmprestimo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRealizaEmprestimo.Location = new System.Drawing.Point(0, 492);
            this.btnRealizaEmprestimo.Name = "btnRealizaEmprestimo";
            this.btnRealizaEmprestimo.Size = new System.Drawing.Size(198, 42);
            this.btnRealizaEmprestimo.TabIndex = 6;
            this.btnRealizaEmprestimo.Text = "Realizar Empréstimo";
            this.btnRealizaEmprestimo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRealizaEmprestimo.UseVisualStyleBackColor = false;
            this.btnRealizaEmprestimo.Click += new System.EventHandler(this.BtnRealizaEmprestimo_Click);
            this.btnRealizaEmprestimo.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.btnRealizaEmprestimo.MouseLeave += new System.EventHandler(this.btn_Leave);
            this.btnRealizaEmprestimo.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // btnPagaMulta
            // 
            this.btnPagaMulta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnPagaMulta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPagaMulta.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPagaMulta.FlatAppearance.BorderSize = 0;
            this.btnPagaMulta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnPagaMulta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnPagaMulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPagaMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPagaMulta.ForeColor = System.Drawing.Color.LightGray;
            this.btnPagaMulta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPagaMulta.Location = new System.Drawing.Point(0, 450);
            this.btnPagaMulta.Name = "btnPagaMulta";
            this.btnPagaMulta.Size = new System.Drawing.Size(198, 42);
            this.btnPagaMulta.TabIndex = 5;
            this.btnPagaMulta.Text = "Pagamento de multa";
            this.btnPagaMulta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPagaMulta.UseVisualStyleBackColor = false;
            this.btnPagaMulta.Click += new System.EventHandler(this.btnPagaMulta_Click);
            this.btnPagaMulta.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.btnPagaMulta.MouseLeave += new System.EventHandler(this.btn_Leave);
            this.btnPagaMulta.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // btnGerenciamento
            // 
            this.btnGerenciamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnGerenciamento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGerenciamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGerenciamento.FlatAppearance.BorderSize = 0;
            this.btnGerenciamento.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnGerenciamento.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnGerenciamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGerenciamento.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGerenciamento.ForeColor = System.Drawing.Color.LightGray;
            this.btnGerenciamento.Location = new System.Drawing.Point(0, 408);
            this.btnGerenciamento.Name = "btnGerenciamento";
            this.btnGerenciamento.Size = new System.Drawing.Size(198, 42);
            this.btnGerenciamento.TabIndex = 4;
            this.btnGerenciamento.Text = "Gerenciamento";
            this.btnGerenciamento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGerenciamento.UseVisualStyleBackColor = false;
            this.btnGerenciamento.Click += new System.EventHandler(this.BtnGerenciamento_Click);
            this.btnGerenciamento.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.btnGerenciamento.MouseLeave += new System.EventHandler(this.btn_Leave);
            this.btnGerenciamento.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // btnDevolucao
            // 
            this.btnDevolucao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnDevolucao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDevolucao.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDevolucao.FlatAppearance.BorderSize = 0;
            this.btnDevolucao.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnDevolucao.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnDevolucao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDevolucao.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDevolucao.ForeColor = System.Drawing.Color.LightGray;
            this.btnDevolucao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDevolucao.Location = new System.Drawing.Point(0, 366);
            this.btnDevolucao.Name = "btnDevolucao";
            this.btnDevolucao.Size = new System.Drawing.Size(198, 42);
            this.btnDevolucao.TabIndex = 3;
            this.btnDevolucao.Text = "Devolução de Livros";
            this.btnDevolucao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDevolucao.UseVisualStyleBackColor = false;
            this.btnDevolucao.Click += new System.EventHandler(this.BtnDevolucao_Click);
            this.btnDevolucao.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.btnDevolucao.MouseLeave += new System.EventHandler(this.btn_Leave);
            this.btnDevolucao.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // btnMultas
            // 
            this.btnMultas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnMultas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMultas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMultas.FlatAppearance.BorderSize = 0;
            this.btnMultas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnMultas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnMultas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMultas.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultas.ForeColor = System.Drawing.Color.LightGray;
            this.btnMultas.Location = new System.Drawing.Point(0, 324);
            this.btnMultas.Name = "btnMultas";
            this.btnMultas.Size = new System.Drawing.Size(198, 42);
            this.btnMultas.TabIndex = 2;
            this.btnMultas.Text = "Consulta Multas";
            this.btnMultas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMultas.UseVisualStyleBackColor = false;
            this.btnMultas.Click += new System.EventHandler(this.btnMultas_Click);
            this.btnMultas.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.btnMultas.MouseLeave += new System.EventHandler(this.btn_Leave);
            this.btnMultas.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // painelRetratil
            // 
            this.painelRetratil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.painelRetratil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.painelRetratil.Controls.Add(this.btnCadastrarUsuario);
            this.painelRetratil.Controls.Add(this.btnCadastrarLivro);
            this.painelRetratil.Controls.Add(this.btnCadastrarGenero);
            this.painelRetratil.Controls.Add(this.btnCadastrarEditora);
            this.painelRetratil.Controls.Add(this.btnAutor);
            this.painelRetratil.Dock = System.Windows.Forms.DockStyle.Top;
            this.painelRetratil.Location = new System.Drawing.Point(0, 108);
            this.painelRetratil.Name = "painelRetratil";
            this.painelRetratil.Size = new System.Drawing.Size(198, 216);
            this.painelRetratil.TabIndex = 16;
            // 
            // btnCadastrarUsuario
            // 
            this.btnCadastrarUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCadastrarUsuario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrarUsuario.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCadastrarUsuario.FlatAppearance.BorderSize = 0;
            this.btnCadastrarUsuario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnCadastrarUsuario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnCadastrarUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarUsuario.ForeColor = System.Drawing.Color.LightGray;
            this.btnCadastrarUsuario.Location = new System.Drawing.Point(0, 168);
            this.btnCadastrarUsuario.Name = "btnCadastrarUsuario";
            this.btnCadastrarUsuario.Padding = new System.Windows.Forms.Padding(21, 0, 0, 0);
            this.btnCadastrarUsuario.Size = new System.Drawing.Size(196, 42);
            this.btnCadastrarUsuario.TabIndex = 0;
            this.btnCadastrarUsuario.Text = "● Cadastrar Usuário";
            this.btnCadastrarUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrarUsuario.UseVisualStyleBackColor = false;
            this.btnCadastrarUsuario.Click += new System.EventHandler(this.BtnCadastrarUsuario_Click);
            this.btnCadastrarUsuario.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnCadastrarUsuario.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnCadastrarUsuario.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnCadastrarLivro
            // 
            this.btnCadastrarLivro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCadastrarLivro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrarLivro.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCadastrarLivro.FlatAppearance.BorderSize = 0;
            this.btnCadastrarLivro.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnCadastrarLivro.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnCadastrarLivro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarLivro.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarLivro.ForeColor = System.Drawing.Color.LightGray;
            this.btnCadastrarLivro.Location = new System.Drawing.Point(0, 126);
            this.btnCadastrarLivro.Name = "btnCadastrarLivro";
            this.btnCadastrarLivro.Padding = new System.Windows.Forms.Padding(21, 0, 0, 0);
            this.btnCadastrarLivro.Size = new System.Drawing.Size(196, 42);
            this.btnCadastrarLivro.TabIndex = 4;
            this.btnCadastrarLivro.Text = "● Cadastrar Livro";
            this.btnCadastrarLivro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrarLivro.UseVisualStyleBackColor = false;
            this.btnCadastrarLivro.Click += new System.EventHandler(this.btnCadastrarLivro_Click);
            this.btnCadastrarLivro.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnCadastrarLivro.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnCadastrarLivro.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnCadastrarGenero
            // 
            this.btnCadastrarGenero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCadastrarGenero.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrarGenero.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCadastrarGenero.FlatAppearance.BorderSize = 0;
            this.btnCadastrarGenero.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnCadastrarGenero.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnCadastrarGenero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarGenero.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarGenero.ForeColor = System.Drawing.Color.LightGray;
            this.btnCadastrarGenero.Location = new System.Drawing.Point(0, 84);
            this.btnCadastrarGenero.Name = "btnCadastrarGenero";
            this.btnCadastrarGenero.Padding = new System.Windows.Forms.Padding(21, 0, 0, 0);
            this.btnCadastrarGenero.Size = new System.Drawing.Size(196, 42);
            this.btnCadastrarGenero.TabIndex = 3;
            this.btnCadastrarGenero.Text = "● Cadastrar Gênero";
            this.btnCadastrarGenero.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrarGenero.UseVisualStyleBackColor = false;
            this.btnCadastrarGenero.Click += new System.EventHandler(this.btnCadastrarGenero_Click);
            this.btnCadastrarGenero.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnCadastrarGenero.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnCadastrarGenero.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnCadastrarEditora
            // 
            this.btnCadastrarEditora.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCadastrarEditora.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrarEditora.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCadastrarEditora.FlatAppearance.BorderSize = 0;
            this.btnCadastrarEditora.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnCadastrarEditora.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnCadastrarEditora.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastrarEditora.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrarEditora.ForeColor = System.Drawing.Color.LightGray;
            this.btnCadastrarEditora.Location = new System.Drawing.Point(0, 42);
            this.btnCadastrarEditora.Name = "btnCadastrarEditora";
            this.btnCadastrarEditora.Padding = new System.Windows.Forms.Padding(21, 0, 0, 0);
            this.btnCadastrarEditora.Size = new System.Drawing.Size(196, 42);
            this.btnCadastrarEditora.TabIndex = 2;
            this.btnCadastrarEditora.Text = "● Cadastrar Editora";
            this.btnCadastrarEditora.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastrarEditora.UseVisualStyleBackColor = false;
            this.btnCadastrarEditora.Click += new System.EventHandler(this.BtnCadastrarEditora_Click);
            this.btnCadastrarEditora.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnCadastrarEditora.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnCadastrarEditora.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnAutor
            // 
            this.btnAutor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAutor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAutor.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAutor.FlatAppearance.BorderSize = 0;
            this.btnAutor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnAutor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnAutor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutor.ForeColor = System.Drawing.Color.LightGray;
            this.btnAutor.Location = new System.Drawing.Point(0, 0);
            this.btnAutor.Name = "btnAutor";
            this.btnAutor.Padding = new System.Windows.Forms.Padding(21, 0, 0, 0);
            this.btnAutor.Size = new System.Drawing.Size(196, 42);
            this.btnAutor.TabIndex = 1;
            this.btnAutor.Text = "● Cadastrar Autor";
            this.btnAutor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAutor.UseVisualStyleBackColor = false;
            this.btnAutor.Click += new System.EventHandler(this.BtnAutor_Click);
            this.btnAutor.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnAutor.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnAutor.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnCadastros
            // 
            this.btnCadastros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnCadastros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastros.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCadastros.FlatAppearance.BorderSize = 0;
            this.btnCadastros.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnCadastros.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnCadastros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadastros.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastros.ForeColor = System.Drawing.Color.LightGray;
            this.btnCadastros.Image = ((System.Drawing.Image)(resources.GetObject("btnCadastros.Image")));
            this.btnCadastros.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCadastros.Location = new System.Drawing.Point(0, 66);
            this.btnCadastros.Name = "btnCadastros";
            this.btnCadastros.Size = new System.Drawing.Size(198, 42);
            this.btnCadastros.TabIndex = 1;
            this.btnCadastros.Text = "Cadastros";
            this.btnCadastros.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCadastros.UseVisualStyleBackColor = false;
            this.btnCadastros.Click += new System.EventHandler(this.BtnCadastros_Click);
            this.btnCadastros.MouseEnter += new System.EventHandler(this.btn_MouseHover);
            this.btnCadastros.MouseLeave += new System.EventHandler(this.btn_Leave);
            this.btnCadastros.MouseHover += new System.EventHandler(this.btn_MouseHover);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(198, 66);
            this.panel3.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.label2.Location = new System.Drawing.Point(25, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "Biblioteca";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(27, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Toledo Prudente";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.lblEmail.Location = new System.Drawing.Point(54, 46);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 16);
            this.lblEmail.TabIndex = 3;
            this.lblEmail.Text = "E-mail";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 58);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.lblCargo.Location = new System.Drawing.Point(54, 28);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(49, 16);
            this.lblCargo.TabIndex = 1;
            this.lblCargo.Text = "Cargo";
            // 
            // lblFuncionario
            // 
            this.lblFuncionario.AutoSize = true;
            this.lblFuncionario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFuncionario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.lblFuncionario.Location = new System.Drawing.Point(54, 8);
            this.lblFuncionario.Name = "lblFuncionario";
            this.lblFuncionario.Size = new System.Drawing.Size(84, 16);
            this.lblFuncionario.TabIndex = 0;
            this.lblFuncionario.Text = "Funcionário";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblCodFun);
            this.panel2.Controls.Add(this.lbTitulo);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.pbMinimizaMenu);
            this.panel2.Controls.Add(this.pbFecharMenu);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(833, 67);
            this.panel2.TabIndex = 5;
            // 
            // lblCodFun
            // 
            this.lblCodFun.AutoSize = true;
            this.lblCodFun.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodFun.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.lblCodFun.Location = new System.Drawing.Point(235, 4);
            this.lblCodFun.Name = "lblCodFun";
            this.lblCodFun.Size = new System.Drawing.Size(55, 16);
            this.lblCodFun.TabIndex = 4;
            this.lblCodFun.Text = "codFun";
            this.lblCodFun.Visible = false;
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbTitulo.Location = new System.Drawing.Point(296, 16);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(161, 32);
            this.lbTitulo.TabIndex = 8;
            this.lbTitulo.Text = "Bem vindo!";
            // 
            // pbMinimizaMenu
            // 
            this.pbMinimizaMenu.BackColor = System.Drawing.Color.Transparent;
            this.pbMinimizaMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbMinimizaMenu.Image = ((System.Drawing.Image)(resources.GetObject("pbMinimizaMenu.Image")));
            this.pbMinimizaMenu.Location = new System.Drawing.Point(776, 3);
            this.pbMinimizaMenu.Name = "pbMinimizaMenu";
            this.pbMinimizaMenu.Size = new System.Drawing.Size(23, 22);
            this.pbMinimizaMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMinimizaMenu.TabIndex = 7;
            this.pbMinimizaMenu.TabStop = false;
            this.pbMinimizaMenu.Click += new System.EventHandler(this.PbMinimizaMenu_Click);
            // 
            // pbFecharMenu
            // 
            this.pbFecharMenu.BackColor = System.Drawing.Color.Transparent;
            this.pbFecharMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFecharMenu.Image = ((System.Drawing.Image)(resources.GetObject("pbFecharMenu.Image")));
            this.pbFecharMenu.Location = new System.Drawing.Point(805, 3);
            this.pbFecharMenu.Name = "pbFecharMenu";
            this.pbFecharMenu.Size = new System.Drawing.Size(23, 22);
            this.pbFecharMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFecharMenu.TabIndex = 6;
            this.pbFecharMenu.TabStop = false;
            this.pbFecharMenu.Click += new System.EventHandler(this.PbFecharMenu_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblEmail);
            this.panel4.Controls.Add(this.lblCargo);
            this.panel4.Controls.Add(this.lblFuncionario);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(229, 65);
            this.panel4.TabIndex = 0;
            // 
            // panelContainer
            // 
            this.panelContainer.BackColor = System.Drawing.Color.White;
            this.panelContainer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelContainer.BackgroundImage")));
            this.panelContainer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelContainer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContainer.Location = new System.Drawing.Point(200, 67);
            this.panelContainer.Name = "panelContainer";
            this.panelContainer.Size = new System.Drawing.Size(833, 531);
            this.panelContainer.TabIndex = 6;
            this.panelContainer.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.panelContainer_ControlRemoved);
            // 
            // MenuInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1033, 598);
            this.Controls.Add(this.panelContainer);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MenuInicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Inicial";
            this.Load += new System.EventHandler(this.MenuInicial_Load);
            this.panel1.ResumeLayout(false);
            this.painelRetratil.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbMinimizaMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFecharMenu)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private JThinButton.JThinButton btnSair;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pbFecharMenu;
        private System.Windows.Forms.PictureBox pbMinimizaMenu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelContainer;
        public System.Windows.Forms.Button btnRealizaEmprestimo;
        public System.Windows.Forms.Button btnCadastrarUsuario;
        public System.Windows.Forms.Button btnCadastrarLivro;
        public System.Windows.Forms.Button btnGerenciamento;
        public System.Windows.Forms.Label lbTitulo;
        public System.Windows.Forms.Button btnDevolucao;
        public System.Windows.Forms.Button btnCadastros;
        public System.Windows.Forms.Button btnAutor;
        public System.Windows.Forms.Button btnMultas;
        private System.Windows.Forms.Panel painelRetratil;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.Button btnCadastrarEditora;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblFuncionario;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Button btnCadastrarGenero;
        private System.Windows.Forms.Label lblCodFun;
        public System.Windows.Forms.Button btnPagaMulta;
    }
}