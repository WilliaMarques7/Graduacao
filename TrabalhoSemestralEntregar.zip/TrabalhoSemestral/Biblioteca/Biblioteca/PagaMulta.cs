﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class PagaMulta : Form
    {
        Inadimplentes model;
        public int codigo;

        public PagaMulta()
        {
            InitializeComponent();
        }

        private void PagaMulta_Load(object sender, EventArgs e)
        {
            model = new Inadimplentes();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar fomulário!");
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario usu = new Usuario();

                dgvLocalizaUsuario.DataSource =
                    (new UsuarioRepositorio()).LocalizaUsuMulta(txtUsuario.Text);
                
                for (int i = 2; i < dgvLocalizaUsuario.Columns.Count; i++)
                {
                    dgvLocalizaUsuario.Columns[i].Visible = false;
                }
                dgvLocalizaUsuario.Columns[0].HeaderText = "Código";
                dgvLocalizaUsuario.Columns[1].HeaderText = "Nome";
                dgvLocalizaUsuario.Columns[0].Width = 50;
                dgvLocalizaUsuario.Columns[1].Width = 250;

            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao localizar!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvLocalizaUsuario.Columns.Count; i++)
                {
                    dgvLocalizaUsuario.Rows[i].DataGridView.Columns.Clear();
                }

                txtUsuario.Clear();
                txtUsuario.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao iniciar nova consulta!");
            }
        }


        private void dgvLocalizaUsuario_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                codigo = (int)dgvLocalizaUsuario.Rows[e.RowIndex].Cells["codigo_usuario"].Value;

                if (codigo != 0)
                {
                    gbDadosMulta.Visible = true;
                    btnPagar.Visible = true;
                    btnLimpaGeral.Visible = true;
                    txtCodigoUsuario.Text = codigo.ToString();
                    model = (new InadimplentesRepositorio()).Localizar(int.Parse(txtCodigoUsuario.Text));
                    txtCodigoMulta.Text = model.Codigo_Inadimplente.ToString();
                    txtValorMulta.Text = model.Multa_Valor.ToString();
                    txtDataMulta.Value = model.Multa_Dat.Value;
                    txtNomeUsuario.Text = txtUsuario.Text;
                    if (model.Multa_Paga == "N")
                        txtStatusMuta.Text = "Não";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnPagar_Click(object sender, EventArgs e)
        {
            try
            {
                model.Multa_Paga = "S";
                model.Multa_DataPagamento = DateTime.Now.Date;
                (new InadimplentesRepositorio()).Alterar(model);

                txtPagamentoMulta.Visible = true;
                lblMultaPagaEm.Visible = true;
                txtPagamentoMulta.Value = model.Multa_DataPagamento.Value;
                if(model.Multa_Paga == "S")
                txtStatusMuta.Text = "Sim";

                MessageBox.Show("Pagamento realizado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao efetuar pagamento! Erro: " + ex.Message);
            }
        }

        private void btnLimpaGeral_Click(object sender, EventArgs e)
        {
            txtCodigoMulta.Clear();
            txtCodigoUsuario.Clear();
            txtNomeUsuario.Clear();
            txtStatusMuta.Clear();
            txtUsuario.Clear();
            txtValorMulta.Clear();

            txtDataMulta.Value = DateTime.Now;
            txtPagamentoMulta.Value = DateTime.Now;

            for (int i = 0; i < dgvLocalizaUsuario.Columns.Count; i++)
            {
                dgvLocalizaUsuario.Rows[i].DataGridView.Columns.Clear();
            }

            gbDadosMulta.Visible = false;

            btnPagar.Visible = false;
            btnLimpar.Visible = false;

            txtUsuario.Focus();
        }
    }
}
