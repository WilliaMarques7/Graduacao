﻿using System; 
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarLivro : Form
    {
        Livro model;
        Autor Autor;
        Livro_Autor Livro_Autor;
        Livro_Genero Livro_Genero;

        public int codigo;
        DataTable tabGenero;
        DataTable tabAutor; 
        List<Autor> plItensAutor;
        List<Genero> plItensGenero;
        DataRow linhaGenero;
        DataRow linhaAutor;

        public CadastrarLivro()
        {
            InitializeComponent();
        }

        private void CadastrarLivro_Load(object sender, EventArgs e)
        {
            model = new Livro();
            Livro_Autor = new Livro_Autor();
            Livro_Genero = new Livro_Genero();
            Autor = new Autor();

            txtTitulo.Focus();

            IniciaComboBoxEditora();

            IniciaComboBoxAutor();
            AtualizaConteudoAutor();

            IniciaComboBoxGenero();
            AtualizaConteudoGenero();
        }

        public void IniciaComboBoxEditora()
        {
            cbEditora.DataSource = (new EditoraRepositorio()).Localizar("");
            cbEditora.ValueMember = "Codigo_Editora";
            cbEditora.DisplayMember = "Nome";
            cbEditora.SelectedIndex = -1;
        }

        public void IniciaComboBoxAutor()
        {
            cbAutor.DataSource = (new AutorRepositorio()).Localizar("");
            cbAutor.ValueMember = "Codigo_Autor";
            cbAutor.DisplayMember = "Nome";
            cbAutor.SelectedIndex = -1;
        }

        public void IniciaComboBoxGenero()
        {
            cbGenero.DataSource = (new GeneroLivroRepositorio()).Localizar("");
            cbGenero.ValueMember = "Codigo_Genero";
            cbGenero.DisplayMember = "Tipo_Genero";
            cbGenero.SelectedIndex = -1;
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void AtualizaConteudoAutor()
        {
            try
            {
                
                tabAutor = new DataTable();
                //criar colunas da tabela
                tabAutor.Columns.Add("Codigo", typeof(int));
                tabAutor.Columns.Add("Nome", typeof(string));

                //associar a tabela a grid
                dgvAutor.DataSource = tabAutor;
                dgvAutor.Columns[0].HeaderText = "Codigo";
                dgvAutor.Columns[0].Width = 50;
                dgvAutor.Columns[1].HeaderText = "Nome";
                dgvAutor.Columns[1].Width = 200;
                dgvAutor.RowHeadersVisible = false;
                dgvAutor.AllowUserToAddRows = false;
                dgvAutor.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); 
            }
        }

        public void AtualizaConteudoGenero()
        {
            try
            {
                tabGenero = new DataTable();
                tabGenero.Columns.Add("Codigo", typeof(int));
                tabGenero.Columns.Add("Gênero", typeof(string));

                dgvGenero.DataSource = tabGenero;
                dgvGenero.Columns[0].HeaderText = "Codigo";
                dgvGenero.Columns[0].Width = 50;
                dgvGenero.Columns[1].HeaderText = "Gênero";
                dgvGenero.Columns[1].Width = 200;
                dgvAutor.RowHeadersVisible = false;
                dgvGenero.AllowUserToAddRows = false;
                dgvGenero.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //verifica se autor já está inserirdo na datagridview
        public bool VerificaGridAutor()
        {
            bool retorno = false;

            foreach (DataRow linha in tabAutor.Rows)
            {
                if ((linha["Codigo"].ToString() == cbAutor.SelectedValue.ToString()))
                    retorno = true;
                else
                    retorno = false;
            }
            return retorno;
        }

        //verifica se gênero já está inserirdo na datagridview
        public bool VerificaGridGenero()
        {
            bool retorno = false;

            foreach (DataRow linha in tabGenero.Rows)
            {
                if ((linha["Codigo"].ToString() == cbGenero.SelectedValue.ToString()))
                    retorno = true;
                else
                    retorno = false;
            }

            return retorno;
        }

        //Adiciona autor selecionado a datagridview
        private void pbAddAutor_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbAutor.Text != "")
                {
                    if (!VerificaGridAutor())
                    {
                        linhaAutor = tabAutor.NewRow();
                        linhaAutor["Codigo"] = cbAutor.SelectedValue;
                        linhaAutor["Nome"] = cbAutor.Text;
                        tabAutor.Rows.Add(linhaAutor);
                        tabAutor.AcceptChanges();
                        cbAutor.SelectedIndex = -1;
                    }
                    else
                    {
                        MessageBox.Show("Autor já inserido");
                    }
                }
                else
                {
                    MessageBox.Show("Selecione um autor!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao inserir autor!");
            }
            
        }

        private void pbAddGen_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbGenero.Text != "")
                {
                    if (!VerificaGridGenero())
                    {
                        linhaGenero = tabGenero.NewRow();
                        linhaGenero["Codigo"] = cbGenero.SelectedValue;
                        linhaGenero["Gênero"] = cbGenero.Text;
                        tabGenero.Rows.Add(linhaGenero);
                        tabGenero.AcceptChanges();
                        cbGenero.SelectedIndex = -1;
                    }
                    else
                        MessageBox.Show("Gênero já inserido!");
                }
                else
                    MessageBox.Show("Selecione um gênero!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao inserir gênero!");
            }
        }

        //remove autor selecionado da datagridview
        private void pbRemoveAutor_Click(object sender, EventArgs e)
        {
            int i;
            string permissao;
            i = default(int);
            permissao = null;

            foreach (DataGridViewRow linha in dgvAutor.SelectedRows)
            {
                i = linha.Index;
                permissao = "a";
            }
            //int i = dgvAutor.CurrentCell.RowIndex;

            if (i >= 0 && permissao == "a")
            {
                tabAutor.Rows.RemoveAt(i);
                tabAutor.AcceptChanges();
            }
            else
                MessageBox.Show("Não há item para ser removido!");

            tabAutor.AcceptChanges();
        }

        //remove gênero selecionado da datagridview
        private void pbRemoveGen_Click(object sender, EventArgs e)
        {
            int i;
            string permissao;
            i = default(int);
            permissao = null;

            foreach (DataGridViewRow linha in dgvGenero.SelectedRows)
            {
                i = linha.Index;
                permissao = "a";
            }

            if (i >= 0 && permissao == "a")
            {
                tabGenero.Rows.RemoveAt(i);
                tabGenero.AcceptChanges();
            }
            else
                MessageBox.Show("Não há intem para ser removido!");

            tabGenero.AcceptChanges();
        }

        public void HabDesab1(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;
        }
        public void HabDesab2(bool status)
        {
            btnSalvar.Enabled = status;
            btnProcura.Enabled = status;
        }
        
        public void LimpaTudo()
        {
            txtTitulo.Clear();
            txtCodigo.Clear();
            txtAno.Clear();
            txtEdicao.Clear();

            cbAutor.SelectedIndex = -1;
            cbGenero.SelectedIndex = -1;
            cbEditora.SelectedIndex = -1;

            lblInformeAno.Visible = false;
            lblInformeAutor.Visible = false;
            lblInformeEdicao.Visible = false;
            lblInformeGenero.Visible = false;
            lblInformeTitulo.Visible = false;

            dgvAutor.DataSource = null;
            dgvGenero.DataSource = null;
            AtualizaConteudoAutor();
            AtualizaConteudoGenero();

            txtTitulo.Focus();

            HabDesab1(false);
            HabDesab2(true);
        }

        public void VerificaLabels()
        {
            if (txtTitulo.Text == "")
                lblInformeTitulo.Visible = true;
            else
                lblInformeTitulo.Visible = false;

            if (txtAno.Text == "")
                lblInformeAno.Visible = true;
            else
                lblInformeAno.Visible = false;

            if (txtEdicao.Text == "")
                lblInformeEdicao.Visible = true;
            else
                lblInformeEdicao.Visible = false;

            if (dgvAutor.Rows.Count == 0)
                lblInformeAutor.Visible = true;
            else
                lblInformeAutor.Visible = false;

            if (dgvGenero.Rows.Count == 0)
                lblInformeGenero.Visible = true;
            else
                lblInformeGenero.Visible = false;

            if (cbEditora.SelectedIndex == -1)
                lblInformaEditora.Visible = true;
            else
                lblInformaEditora.Visible = false;
        }

        public bool VerificaPreenchidos()
        {
            bool retorno = false;

            if (txtTitulo.Text.Trim() != "" && txtAno.Text.Trim() != "" &&
                txtEdicao.Text.Trim() != "" && cbEditora.Text != "")
            {
                if (dgvAutor.Rows.Count > 0 && dgvGenero.Rows.Count > 0)
                    retorno = true;
            }
            else
                retorno = false;

            VerificaLabels();

            return retorno;
        }

        public void CarregaCampos(int codigo)
        {
            
                txtTitulo.Text = model.Titulo;
                txtAno.Text = model.Ano.ToString();
                txtEdicao.Text = model.Edicao;
                txtCodigo.Text = model.Codigo_livro.ToString();
                cbEditora.SelectedValue = model.Codigo_Editora;


            DataTable tabAutor2 = new DataTable();
            
            DataRow linha;
            tabAutor.Clear();

            foreach (vw_LivroAutor item in CarregarListaAutor(codigo))
            {
                linha = tabAutor.NewRow();
                linha["Codigo"] = item.Codigo_Autor.ToString();
                linha["Nome"] = item.Nome;
                tabAutor.Rows.Add(linha);
                tabAutor.AcceptChanges();
                cbAutor.SelectedIndex = -1;
            }

            DataTable tabGenero2 = new DataTable();
            DataRow linhaGen;
            tabGenero.Clear();

            foreach (vw_LivroGenero item in CarregarListaGenero(codigo))
            {
                linhaGen = tabGenero.NewRow();
                linhaGen["Codigo"] = item.Codigo_Genero.ToString();
                linhaGen["Gênero"] = item.Tipo_Genero;
                tabGenero.Rows.Add(linhaGen);
                tabGenero.AcceptChanges();
            }

        }

        //Carrega lista de autores usando view criada no banco e sendo usada no repositorio
        public List<vw_LivroAutor> CarregarListaAutor(int codigo)
        {
         
            List<vw_LivroAutor> lista= (new Livro_AutorRepositorio()).LocalizarLivro(codigo);
            
            return lista;
        }

        //Carrega lista de autores usando view criada no banco e sendo usada no repositorio
        public List<vw_LivroGenero> CarregarListaGenero(int codigo)
        {
            List<vw_LivroGenero> lista = (new Livro_GeneroRepositorio()).LocalizarLivro(codigo);

            return lista;
        }

        public void CarregarProp()
        {
            model.Titulo = txtTitulo.Text;
            model.Ano = int.Parse(txtAno.Text);
            model.Edicao = txtEdicao.Text;
            model.Codigo_Editora = (int)cbEditora.SelectedValue;

            if (txtCodigo.Text == "")
                model.Codigo_livro = 0;
            else
                model.Codigo_livro = int.Parse(txtCodigo.Text);
        }

        //Insere na tabela N:N Livro_Autor
        public void CadastrarListaAutor(int codigo)
        {
            foreach (Autor obj in plItensAutor)
            {
                Livro_Autor.Codigo_Livro = codigo;
                Livro_Autor.Codigo_Autor = obj.Codigo_Autor;

                (new Livro_AutorRepositorio()).Inserir(Livro_Autor);
            }
        }

        //Insere na tabela N:N Livro_Genero
        public void CadastrarListaGenero(int codigo)
        {
            foreach (Genero obj in plItensGenero)
            {
                Livro_Genero.Codigo_livro = codigo;
                Livro_Genero.Codigo_Genero = obj.Codigo_Genero;
                (new Livro_GeneroRepositorio()).Inserir(Livro_Genero);
            }
        }

        public void ExcluirAutor()
        {
            (new Livro_AutorRepositorio()).ExcluirLivro(int.Parse(txtCodigo.Text));
        }

        public void ExcluirGenero()
        {
            (new Livro_GeneroRepositorio()).ExcluirLivro(int.Parse(txtCodigo.Text));
        }

        public void RecadastrarListaAutor(int codigo)
        {
            foreach (Autor obj in plItensAutor)
            {
                Livro_Autor.Codigo_Livro = codigo;
                Livro_Autor.Codigo_Autor = obj.Codigo_Autor;
                (new Livro_AutorRepositorio()).Alterar(Livro_Autor);
            }
        }

        public void RecadastrarListaGenero(int codigo)
        {
            foreach (Genero obj in plItensGenero)
            {
                Livro_Genero.Codigo_livro = codigo;
                Livro_Genero.Codigo_Genero = obj.Codigo_Genero;
                (new Livro_GeneroRepositorio()).Alterar(Livro_Genero);
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaTudo();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao iniciar novo registro!");
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaPreenchidos())
                {
                    //carregar Lista de autores
                    plItensAutor = new List<Autor>();
                    plItensAutor.Clear();
                    Autor objAutor;
                    foreach (DataRow linha in tabAutor.Rows)
                    {
                        objAutor = new Autor();
                        objAutor.Codigo_Autor = int.Parse(linha["Codigo"].ToString());
                        plItensAutor.Add(objAutor);
                    }

                    //carregar Lista de gêneros
                    plItensGenero = new List<Genero>();
                    plItensGenero.Clear();
                    Genero objGenero;
                    foreach (DataRow linha in tabGenero.Rows)
                    {
                        objGenero = new Genero();
                        objGenero.Codigo_Genero = int.Parse(linha["Codigo"].ToString());
                        plItensGenero.Add(objGenero);
                    }


                    CarregarProp();

                    if(txtCodigo.Text == "")
                    {
                        (new LivroRepositorio()).Inserir(model);
                        

                        int codigo = model.Codigo_livro;
                        CadastrarListaAutor(codigo);
                        CadastrarListaGenero(codigo);

                        MessageBox.Show("Livro cadastrado com sucesso!");
                        btnNovo_Click(sender, e);
                    }
                    else
                    {
                        (new LivroRepositorio()).Alterar(model);
                    }
                }
                else
                    MessageBox.Show("Preencha todos os campos!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void btnProcura_Click(object sender, EventArgs e)
        {
            try
            {
                LocalizaLivro frm = new LocalizaLivro();
                frm.ShowDialog();

                if (frm.codigo != 0)
                {
                    model = (new LivroRepositorio()).Localizar(frm.codigo);
                    CarregaCampos(frm.codigo);
                    HabDesab1(true);
                    HabDesab2(false);
                }

                frm.Dispose();
                frm = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir formulário!" + ex);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaPreenchidos())
                {
                    //carregar Lista de autores
                    plItensAutor = new List<Autor>();
                    plItensAutor.Clear();
                    Autor objAutor;
                    foreach (DataRow linha in tabAutor.Rows)
                    {
                        objAutor = new Autor();
                        objAutor.Codigo_Autor = int.Parse(linha["Codigo"].ToString());
                        plItensAutor.Add(objAutor);
                    }

                    //carregar Lista de gêneros
                    plItensGenero = new List<Genero>();
                    plItensGenero.Clear();
                    Genero objGenero;
                    foreach (DataRow linha in tabGenero.Rows)
                    {
                        objGenero = new Genero();
                        objGenero.Codigo_Genero = int.Parse(linha["Codigo"].ToString());
                        plItensGenero.Add(objGenero);
                    }
                    
                    CarregarProp();

                    if (txtCodigo.Text != "")
                    {
                        (new LivroRepositorio()).Alterar(model);

                        int codigo = int.Parse(txtCodigo.Text);

                        ExcluirAutor();
                        CadastrarListaAutor(codigo);

                        ExcluirGenero();
                        CadastrarListaGenero(codigo);

                        MessageBox.Show("Registro alterado com sucesso");
                        btnNovo_Click(sender, e);
                    }
                }
                else
                    MessageBox.Show("Preencha todos os campos!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao alterar!" + ex);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaPreenchidos())
                {
                    ExcluirAutor();
                    ExcluirGenero();

                    (new LivroRepositorio()).Excluir(model);
                    btnNovo_Click(sender, e);

                    MessageBox.Show("Registro excluido com sucesso!");

                }
                else
                    MessageBox.Show("Nenhum campo pode estar vazio!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir!");
            }
        }

        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            try
            {
                MultiplicaLivros frm = new MultiplicaLivros();
                frm.ShowDialog();
                frm.Dispose();
                frm = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário!");
            }
        }
    }
}
