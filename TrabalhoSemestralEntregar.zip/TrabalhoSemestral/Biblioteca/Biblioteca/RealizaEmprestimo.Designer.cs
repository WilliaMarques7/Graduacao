﻿namespace Biblioteca
{
    partial class RealizaEmprestimo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RealizaEmprestimo));
            this.btnLocalizar = new System.Windows.Forms.Button();
            this.pbFecharMenu = new System.Windows.Forms.PictureBox();
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtCodigoUsuario = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCodTipoUsu = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblAvisoExemplar = new System.Windows.Forms.Label();
            this.txtCodigoLivro = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLocalizaExemplar = new System.Windows.Forms.Button();
            this.txtCodigoExemplar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTituloExemplar = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCodigoFuncionario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtFuncionario = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblDataDevolucao = new System.Windows.Forms.Label();
            this.btnConcluirEmp = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.gbDataDevolucao = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbFecharMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.gbDataDevolucao.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLocalizar
            // 
            this.btnLocalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocalizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLocalizar.FlatAppearance.BorderSize = 0;
            this.btnLocalizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLocalizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLocalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizar.ForeColor = System.Drawing.Color.White;
            this.btnLocalizar.Location = new System.Drawing.Point(315, 59);
            this.btnLocalizar.Name = "btnLocalizar";
            this.btnLocalizar.Size = new System.Drawing.Size(112, 23);
            this.btnLocalizar.TabIndex = 2;
            this.btnLocalizar.Text = "Localizar";
            this.btnLocalizar.UseVisualStyleBackColor = false;
            this.btnLocalizar.Click += new System.EventHandler(this.btnLocalizar_Click);
            // 
            // pbFecharMenu
            // 
            this.pbFecharMenu.BackColor = System.Drawing.Color.Transparent;
            this.pbFecharMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFecharMenu.Image = ((System.Drawing.Image)(resources.GetObject("pbFecharMenu.Image")));
            this.pbFecharMenu.Location = new System.Drawing.Point(1064, 2);
            this.pbFecharMenu.Name = "pbFecharMenu";
            this.pbFecharMenu.Size = new System.Drawing.Size(18, 18);
            this.pbFecharMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFecharMenu.TabIndex = 10;
            this.pbFecharMenu.TabStop = false;
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(811, 1);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 11;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(93, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Usuário";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.Location = new System.Drawing.Point(96, 59);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.ReadOnly = true;
            this.txtUsuario.Size = new System.Drawing.Size(200, 23);
            this.txtUsuario.TabIndex = 1;
            // 
            // txtCodigoUsuario
            // 
            this.txtCodigoUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoUsuario.Location = new System.Drawing.Point(21, 59);
            this.txtCodigoUsuario.Name = "txtCodigoUsuario";
            this.txtCodigoUsuario.Size = new System.Drawing.Size(60, 23);
            this.txtCodigoUsuario.TabIndex = 0;
            this.txtCodigoUsuario.TextChanged += new System.EventHandler(this.txtCodigoUsuario_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "Código";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCodTipoUsu);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnLocalizar);
            this.groupBox1.Controls.Add(this.txtCodigoUsuario);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtUsuario);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(35, 192);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 109);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Usuário";
            // 
            // txtCodTipoUsu
            // 
            this.txtCodTipoUsu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodTipoUsu.Location = new System.Drawing.Point(162, 27);
            this.txtCodTipoUsu.Name = "txtCodTipoUsu";
            this.txtCodTipoUsu.Size = new System.Drawing.Size(48, 23);
            this.txtCodTipoUsu.TabIndex = 17;
            this.txtCodTipoUsu.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblAvisoExemplar);
            this.groupBox2.Controls.Add(this.txtCodigoLivro);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btnLocalizaExemplar);
            this.groupBox2.Controls.Add(this.txtCodigoExemplar);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtTituloExemplar);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(35, 322);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(451, 119);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Livro";
            // 
            // lblAvisoExemplar
            // 
            this.lblAvisoExemplar.AutoSize = true;
            this.lblAvisoExemplar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvisoExemplar.ForeColor = System.Drawing.Color.Red;
            this.lblAvisoExemplar.Location = new System.Drawing.Point(93, 85);
            this.lblAvisoExemplar.Name = "lblAvisoExemplar";
            this.lblAvisoExemplar.Size = new System.Drawing.Size(40, 17);
            this.lblAvisoExemplar.TabIndex = 17;
            this.lblAvisoExemplar.Text = "aviso";
            this.lblAvisoExemplar.Visible = false;
            // 
            // txtCodigoLivro
            // 
            this.txtCodigoLivro.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoLivro.Location = new System.Drawing.Point(162, 22);
            this.txtCodigoLivro.Name = "txtCodigoLivro";
            this.txtCodigoLivro.Size = new System.Drawing.Size(48, 23);
            this.txtCodigoLivro.TabIndex = 16;
            this.txtCodigoLivro.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 17);
            this.label3.TabIndex = 15;
            this.label3.Text = "Código";
            // 
            // btnLocalizaExemplar
            // 
            this.btnLocalizaExemplar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocalizaExemplar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLocalizaExemplar.FlatAppearance.BorderSize = 0;
            this.btnLocalizaExemplar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLocalizaExemplar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLocalizaExemplar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizaExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizaExemplar.ForeColor = System.Drawing.Color.White;
            this.btnLocalizaExemplar.Location = new System.Drawing.Point(315, 59);
            this.btnLocalizaExemplar.Name = "btnLocalizaExemplar";
            this.btnLocalizaExemplar.Size = new System.Drawing.Size(112, 23);
            this.btnLocalizaExemplar.TabIndex = 2;
            this.btnLocalizaExemplar.Text = "Localizar";
            this.btnLocalizaExemplar.UseVisualStyleBackColor = false;
            this.btnLocalizaExemplar.Click += new System.EventHandler(this.btnLocalizaExemplar_Click);
            // 
            // txtCodigoExemplar
            // 
            this.txtCodigoExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoExemplar.Location = new System.Drawing.Point(21, 59);
            this.txtCodigoExemplar.Name = "txtCodigoExemplar";
            this.txtCodigoExemplar.Size = new System.Drawing.Size(60, 23);
            this.txtCodigoExemplar.TabIndex = 0;
            this.txtCodigoExemplar.Click += new System.EventHandler(this.txtCodigoExemplar_Click);
            this.txtCodigoExemplar.TextChanged += new System.EventHandler(this.txtCodigoExemplar_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(93, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Livro";
            // 
            // txtTituloExemplar
            // 
            this.txtTituloExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTituloExemplar.Location = new System.Drawing.Point(96, 59);
            this.txtTituloExemplar.Name = "txtTituloExemplar";
            this.txtTituloExemplar.ReadOnly = true;
            this.txtTituloExemplar.Size = new System.Drawing.Size(200, 23);
            this.txtTituloExemplar.TabIndex = 1;
            this.txtTituloExemplar.Click += new System.EventHandler(this.txtTituloExemplar_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtCargo);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtCodigoFuncionario);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtFuncionario);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(35, 64);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(451, 109);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Funcionário realizando empréstimo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(312, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 17);
            this.label7.TabIndex = 17;
            this.label7.Text = "Cargo";
            // 
            // txtCargo
            // 
            this.txtCargo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargo.Location = new System.Drawing.Point(315, 59);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.ReadOnly = true;
            this.txtCargo.Size = new System.Drawing.Size(112, 23);
            this.txtCargo.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "Código";
            // 
            // txtCodigoFuncionario
            // 
            this.txtCodigoFuncionario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoFuncionario.Location = new System.Drawing.Point(21, 59);
            this.txtCodigoFuncionario.Name = "txtCodigoFuncionario";
            this.txtCodigoFuncionario.ReadOnly = true;
            this.txtCodigoFuncionario.Size = new System.Drawing.Size(60, 23);
            this.txtCodigoFuncionario.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(93, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Funcionário";
            // 
            // txtFuncionario
            // 
            this.txtFuncionario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFuncionario.Location = new System.Drawing.Point(96, 59);
            this.txtFuncionario.Name = "txtFuncionario";
            this.txtFuncionario.ReadOnly = true;
            this.txtFuncionario.Size = new System.Drawing.Size(200, 23);
            this.txtFuncionario.TabIndex = 13;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblData.Location = new System.Drawing.Point(22, 50);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(109, 44);
            this.lblData.TabIndex = 18;
            this.lblData.Text = "Data";
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpar.FlatAppearance.BorderSize = 0;
            this.btnLimpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLimpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(36, 458);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(222, 29);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar formulário";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblDataDevolucao
            // 
            this.lblDataDevolucao.AutoSize = true;
            this.lblDataDevolucao.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataDevolucao.ForeColor = System.Drawing.Color.Red;
            this.lblDataDevolucao.Location = new System.Drawing.Point(22, 49);
            this.lblDataDevolucao.Name = "lblDataDevolucao";
            this.lblDataDevolucao.Size = new System.Drawing.Size(109, 44);
            this.lblDataDevolucao.TabIndex = 20;
            this.lblDataDevolucao.Text = "Data";
            this.lblDataDevolucao.Visible = false;
            // 
            // btnConcluirEmp
            // 
            this.btnConcluirEmp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnConcluirEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConcluirEmp.FlatAppearance.BorderSize = 0;
            this.btnConcluirEmp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnConcluirEmp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnConcluirEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConcluirEmp.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConcluirEmp.ForeColor = System.Drawing.Color.White;
            this.btnConcluirEmp.Location = new System.Drawing.Point(264, 458);
            this.btnConcluirEmp.Name = "btnConcluirEmp";
            this.btnConcluirEmp.Size = new System.Drawing.Size(222, 29);
            this.btnConcluirEmp.TabIndex = 4;
            this.btnConcluirEmp.Text = "Concluir empréstimo";
            this.btnConcluirEmp.UseVisualStyleBackColor = false;
            this.btnConcluirEmp.Click += new System.EventHandler(this.btnConcluirEmp_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblData);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(515, 73);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(276, 134);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Data de hoje";
            // 
            // gbDataDevolucao
            // 
            this.gbDataDevolucao.Controls.Add(this.lblDataDevolucao);
            this.gbDataDevolucao.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDataDevolucao.Location = new System.Drawing.Point(515, 250);
            this.gbDataDevolucao.Name = "gbDataDevolucao";
            this.gbDataDevolucao.Size = new System.Drawing.Size(276, 134);
            this.gbDataDevolucao.TabIndex = 22;
            this.gbDataDevolucao.TabStop = false;
            this.gbDataDevolucao.Text = "Data para devolução";
            this.gbDataDevolucao.Visible = false;
            // 
            // RealizaEmprestimo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(833, 531);
            this.Controls.Add(this.btnConcluirEmp);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pbFechaForm);
            this.Controls.Add(this.pbFecharMenu);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gbDataDevolucao);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RealizaEmprestimo";
            this.Text = "RealizaEmprestimo";
            this.Load += new System.EventHandler(this.RealizaEmprestimo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFecharMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.gbDataDevolucao.ResumeLayout(false);
            this.gbDataDevolucao.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnLocalizar;
        private System.Windows.Forms.PictureBox pbFecharMenu;
        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtCodigoUsuario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLocalizaExemplar;
        private System.Windows.Forms.TextBox txtCodigoExemplar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTituloExemplar;
        private System.Windows.Forms.TextBox txtCodigoLivro;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCodigoFuncionario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtFuncionario;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblDataDevolucao;
        private System.Windows.Forms.TextBox txtCodTipoUsu;
        private System.Windows.Forms.Button btnConcluirEmp;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox gbDataDevolucao;
        private System.Windows.Forms.Label lblAvisoExemplar;
    }
}