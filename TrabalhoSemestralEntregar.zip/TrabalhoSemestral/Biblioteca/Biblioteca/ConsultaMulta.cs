﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class ConsultaMulta : Form
    {
        Multa model;
        public int codigo;
        
        public ConsultaMulta()
        {
            InitializeComponent();
        }
        private void ConsultaMulta_Load(object sender, EventArgs e)
        {
            model = new Multa();
            txtPesquisaMulta.Focus();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        private void btnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                dgvResultadosBusca.DataSource =
                    (new MultaRepositorio()).Localizar(txtPesquisaMulta.Text);

                for (int i = 3; i < dgvResultadosBusca.Columns.Count; i++)
                {
                    dgvResultadosBusca.Columns[i].Visible = false;
                }

                dgvResultadosBusca.Columns[0].HeaderText = "Código";
                dgvResultadosBusca.Columns[1].HeaderText = "Valor";
                dgvResultadosBusca.Columns[2].HeaderText = "Data";
                dgvResultadosBusca.Columns[0].Width = 80;
                dgvResultadosBusca.Columns[1].Width = 80;
                dgvResultadosBusca.Columns[2].Width = 270;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao localizar");
            }
        }
    }
}
