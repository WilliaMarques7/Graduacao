﻿namespace Biblioteca
{
    partial class ConsultaMulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConsultaMulta));
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnProcurar = new System.Windows.Forms.Button();
            this.dgvResultadosBusca = new System.Windows.Forms.DataGridView();
            this.txtPesquisaMulta = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadosBusca)).BeginInit();
            this.SuspendLayout();
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(811, 1);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 30;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(170, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 17);
            this.label4.TabIndex = 33;
            this.label4.Text = "Pesquisa por data";
            // 
            // btnProcurar
            // 
            this.btnProcurar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnProcurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProcurar.FlatAppearance.BorderSize = 0;
            this.btnProcurar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnProcurar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProcurar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProcurar.ForeColor = System.Drawing.Color.White;
            this.btnProcurar.Location = new System.Drawing.Point(521, 38);
            this.btnProcurar.Name = "btnProcurar";
            this.btnProcurar.Size = new System.Drawing.Size(127, 25);
            this.btnProcurar.TabIndex = 31;
            this.btnProcurar.Text = "Procurar";
            this.btnProcurar.UseVisualStyleBackColor = false;
            this.btnProcurar.Click += new System.EventHandler(this.btnProcurar_Click);
            // 
            // dgvResultadosBusca
            // 
            this.dgvResultadosBusca.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvResultadosBusca.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvResultadosBusca.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultadosBusca.Location = new System.Drawing.Point(173, 83);
            this.dgvResultadosBusca.Name = "dgvResultadosBusca";
            this.dgvResultadosBusca.Size = new System.Drawing.Size(475, 355);
            this.dgvResultadosBusca.TabIndex = 32;
            // 
            // txtPesquisaMulta
            // 
            this.txtPesquisaMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisaMulta.Location = new System.Drawing.Point(301, 40);
            this.txtPesquisaMulta.Name = "txtPesquisaMulta";
            this.txtPesquisaMulta.Size = new System.Drawing.Size(202, 23);
            this.txtPesquisaMulta.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.label1.Location = new System.Drawing.Point(170, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(331, 16);
            this.label1.TabIndex = 34;
            this.label1.Text = "A pesquisa pode ser realizada informando: dia, mês ou ano.";
            // 
            // ConsultaMulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(833, 499);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbFechaForm);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnProcurar);
            this.Controls.Add(this.dgvResultadosBusca);
            this.Controls.Add(this.txtPesquisaMulta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ConsultaMulta";
            this.Text = "ConsultaMulta";
            this.Load += new System.EventHandler(this.ConsultaMulta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultadosBusca)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnProcurar;
        private System.Windows.Forms.DataGridView dgvResultadosBusca;
        private System.Windows.Forms.TextBox txtPesquisaMulta;
        private System.Windows.Forms.Label label1;
    }
}