﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class LocalizaExemplar : Form
    {
        public int codigo;

        public LocalizaExemplar()
        {
            InitializeComponent();
        }

        private void LocalizaExemplar_Load(object sender, EventArgs e)
        {
            txtTituloExemplar.Focus();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            try
            {
                dgvLocalizaExemplar.DataSource =
                    (new ExemplarRepositorio()).LocalizarExemplarDisponivel(txtTituloExemplar.Text);

                for (int i = 3; i < dgvLocalizaExemplar.Columns.Count; i++)
                {
                    dgvLocalizaExemplar.Columns[i].Visible = false;
                }

                dgvLocalizaExemplar.Columns[0].HeaderText = "Exemplar";
                dgvLocalizaExemplar.Columns[1].HeaderText = "Livro";
                dgvLocalizaExemplar.Columns[2].HeaderText = "Título";
                dgvLocalizaExemplar.Columns[0].Width = 50;
                dgvLocalizaExemplar.Columns[1].Width = 50;
                dgvLocalizaExemplar.Columns[2].Width = 250;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao localizar!");
            }
        }

        private void dgvLocalizaExemplar_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvLocalizaExemplar.Rows[e.RowIndex].Cells["Exemplar"].Value;
            this.Close();
        }
    }
}
