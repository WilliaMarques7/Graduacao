﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class RealizaEmprestimo : Form
    {
        Emprestimo model;
        Livro Livro;
        public string nome, cargo, codigoFun;
        public DateTime dataPrevista;
        int QtdPermitido = 0;
        int QtdEmo = 0;

        public RealizaEmprestimo()
        {
            InitializeComponent();
        }

        private void RealizaEmprestimo_Load(object sender, EventArgs e)
        {
            model = new Emprestimo();
            txtCargo.Text = cargo;
            txtFuncionario.Text = nome;
            txtCodigoFuncionario.Text = codigoFun;

            lblData.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public bool VerificaCampos()
        {
            bool retorno = false;

            if (txtCodigoFuncionario.Text != "" && txtCargo.Text != "" && txtFuncionario.Text != ""
                && txtCodigoUsuario.Text != "" && txtUsuario.Text != "" && txtCodigoExemplar.Text != ""
                && txtTituloExemplar.Text != "")
                retorno = true;
            else
                retorno = false;

            return retorno;
        }

        public void CarregaProp(DateTime dataPrevista)
        {
            model.Codigo_Emprestimo = 0;
            model.Codigo_Exemplar = int.Parse(txtCodigoExemplar.Text);
            model.Codigo_Usuario = int.Parse(txtCodigoUsuario.Text);
            model.Codigo_Funcionario = int.Parse(txtCodigoFuncionario.Text);
            model.Data_Emprestimo = DateTime.Now;
            model.Data_PrevistaDevolucao = dataPrevista.Date;
        }
        public void LimpaTudo()
        {
            txtCodigoUsuario.Clear();
            txtUsuario.Clear();
            txtCodTipoUsu.Clear();

            txtCodigoExemplar.Clear();
            txtCodigoLivro.Clear();
            txtTituloExemplar.Clear();

            //gbDataDevolucao.Visible = false;
        }
        public void VerificaDias()
        {
            //Usuario usuario = (new UsuarioRepositorio()).Localizar(int.Parse(txtCodigoUsuario.Text));
            //txtCodTipoUsu.Text = usuario.TipoUsuario_codigo.ToString();
            //TipoUsuario tipoUsuario = (new TipoUsuarioRepositorio()).Localizar(int.Parse(txtCodTipoUsu.Text));
            ////lblInformaDevolucao.Text = tipoUsuario.Prazo.ToString();

            //OU

            vw_PrazoUsuario prazo = (new TipoUsuarioRepositorio()).LocalizaPrazo(int.Parse(txtCodigoUsuario.Text));
            dataPrevista = DateTime.Now.Date.AddDays(prazo.Prazo);
            lblDataDevolucao.Text = dataPrevista.ToString("dd/MM/yyyy");
        }

        public bool CalculaQtdLivros()
        {
            bool retorno = false;

            vw_QuantidadeLivrosUsuario qtdLivro =
                (new EmprestimoRepositorio()).LocalizaQuantidade(int.Parse(txtCodigoUsuario.Text));

            if (qtdLivro != null)
            {
                QtdPermitido = qtdLivro.Quantidade_Livros;
                QtdEmo = (int)qtdLivro.Quantidade_de_empréstimos;
                if (QtdPermitido > QtdEmo)
                    retorno = true;
                else
                    retorno = false;
            }
            else
                retorno = true;
            
            return retorno;
        }

        private bool VerificaExemplar()
        {
            bool retorno = false;

            vw_ExemplarRepetido repetido =
                (new ExemplarRepositorio()).LocalizarExemplarRepetido(int.Parse(txtCodigoUsuario.Text),
                int.Parse(txtCodigoLivro.Text));

            if (repetido == null)
                retorno = true;
            else
                retorno = false;

            return retorno;
        }

        public void MudaStatusExe()
        {
            Exemplares exemplares = (new ExemplarRepositorio()).Localizar(int.Parse(txtCodigoExemplar.Text));
            if (exemplares.Status_Livro == "D")
                exemplares.Status_Livro = "I";
            (new ExemplarRepositorio()).Alterar(exemplares);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaTudo();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao limpar formulário!");
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                LocalizaUsuario localiza = new LocalizaUsuario();
                localiza.tipoConsulta = 1;
                localiza.ShowDialog();
                if(localiza.codigo != 0)
                {
                    Usuario usu = (new UsuarioRepositorio()).Localizar(localiza.codigo);
                    txtUsuario.Text = usu.Nome;
                    txtCodigoUsuario.Text = usu.Codigo_Usuario.ToString();
                }
                localiza.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir!");
            }
        }

        private void txtCodigoUsuario_TextChanged(object sender, EventArgs e)
        {
            if (txtCodigoUsuario.Text != "")
            {
                vw_UsuariosAtivos usu = (new UsuarioRepositorio()).LocalizarAtivos(int.Parse(txtCodigoUsuario.Text));
                if (usu != null)
                {
                    txtUsuario.Text = usu.Nome;
                    txtCodigoUsuario.Text = usu.Codigo_Usuario.ToString();
                }
                else
                {
                    txtUsuario.Text = "";
                    txtCodigoUsuario.Text = "";
                }
            }
            else
                txtCodigoUsuario.Text = "";
        }

        private void btnLocalizaExemplar_Click(object sender, EventArgs e)
        {
            try
            {
                lblAvisoExemplar.Visible = false;

                LocalizaExemplar frm = new LocalizaExemplar();
                frm.ShowDialog();
                if(frm.codigo != 0)
                {
                    Exemplares exe = (new ExemplarRepositorio()).LocalizarExemplar2(frm.codigo);
                    txtCodigoExemplar.Text = exe.Codigo_Exemplar.ToString();
                    txtCodigoLivro.Text = exe.Codigo_Livro.ToString();
                    Livro livro = (new LivroRepositorio()).Localizar(int.Parse(txtCodigoLivro.Text));
                    txtTituloExemplar.Text = livro.Titulo;
                }
                frm.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao abrir formulário de busca!");
            }
        }

        private void txtCodigoExemplar_TextChanged(object sender, EventArgs e)
        {
            if (txtCodigoExemplar.Text != "")
            {
                vw_LivroExemplarDisponivel exe = (new ExemplarRepositorio()).LocalizarExemplarDisponivel(int.Parse(txtCodigoExemplar.Text));
                if (exe != null)
                {
                    txtCodigoExemplar.Text = exe.Exemplar.ToString();
                    txtCodigoLivro.Text = exe.Livro.ToString();
                    Livro livro = (new LivroRepositorio()).Localizar(int.Parse(txtCodigoLivro.Text));
                    txtTituloExemplar.Text = livro.Titulo;
                }
                else
                    txtTituloExemplar.Text = "";
            }
            else
                txtCodigoExemplar.Text = "";
        }

        private void btnConcluirEmp_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    VerificaDias();
                    CarregaProp(dataPrevista);

                    //Verificar se usuário está inadimplente if(VerificaInadimplente)
                    if (VerificaInadimplente())
                    {
                        if (VerificaLivrosDevolvidos())
                        {
                            if (CalculaQtdLivros())
                            {
                                if (VerificaExemplar())
                                {
                                    (new EmprestimoRepositorio()).Inserir(model);
                                    MessageBox.Show("Empréstimo realizado com sucesso!");

                                    MudaStatusExe();

                                    gbDataDevolucao.Visible = true;
                                    lblDataDevolucao.Visible = true;
                                    LimpaTudo();
                                }
                                else
                                {
                                    MessageBox.Show("O usuário já emprestou um exemplar de mesmo título.");
                                    lblAvisoExemplar.Text = "Escolha outro livro!";
                                    lblAvisoExemplar.Visible = true;
                                }
                            }
                            else
                                MessageBox.Show("A quantidade de livros permitida para esse usuário é: " + QtdPermitido +
                                    Environment.NewLine + "O usuário já possui: " + QtdEmo + " livros emprestados");
                        }
                        else
                            MessageBox.Show("Empréstimo cancelado. O usuário precisa devolver os livros vencidos!");
                    }
                    else
                        MessageBox.Show("Empréstimo cancelado. O usuário precisa antes quitar a multa!");
                    
                        
            }
                else
                    MessageBox.Show("Todos os campos devem estar preenchidos!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao concluir emprestimo! erro: "+ ex.Message);
            }
        }

        private void txtTituloExemplar_Click(object sender, EventArgs e)
        {
            lblAvisoExemplar.Visible = false;
        }

        private void txtCodigoExemplar_Click(object sender, EventArgs e)
        {
            lblAvisoExemplar.Visible = false;
        }

        private void btnTeste_Click(object sender, EventArgs e)
        {
            VerificaInadimplente();
        }

        public bool  VerificaInadimplente()
        {
            bool retorno = false;
            Inadimplentes inadimplentes = (new InadimplentesRepositorio()).Localizar(int.Parse(txtCodigoUsuario.Text));

            if (inadimplentes == null)
                retorno = true;
            else
            {
                if (inadimplentes.Multa_Paga == "N")
                    retorno = false;
                else
                    retorno = true;
            }

            return retorno;
        }

        public bool VerificaLivrosDevolvidos()
        {
            DateTime dataHoje = DateTime.Now.Date;
            DateTime dataPrevista;
            DateTime dataDevolucao;
            bool retorno = false;

            Emprestimo emprestimo = 
                (new EmprestimoRepositorio()).LocalizarUsuario(int.Parse(txtCodigoUsuario.Text));

            if (emprestimo != null)
            {
                dataPrevista = emprestimo.Data_PrevistaDevolucao;
                dataDevolucao = emprestimo.Data_EfetivaDevolucao.Value;

                if (dataPrevista > dataHoje && dataDevolucao != null)
                    retorno = false;
                if (dataPrevista < dataHoje && dataDevolucao == null)
                    retorno = true;
            }
            else
                retorno = true;
            
            return retorno;
        }
    }
}
