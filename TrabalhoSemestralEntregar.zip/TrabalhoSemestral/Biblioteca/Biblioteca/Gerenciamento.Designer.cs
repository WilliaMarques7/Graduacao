﻿namespace Biblioteca
{
    partial class Gerenciamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Gerenciamento));
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnValorMulta = new System.Windows.Forms.Button();
            this.painelRetratil = new System.Windows.Forms.Panel();
            this.btnRelatMulta = new System.Windows.Forms.Button();
            this.btnRelatEmp = new System.Windows.Forms.Button();
            this.btnRelatUsu = new System.Windows.Forms.Button();
            this.btnRelatorios = new System.Windows.Forms.Button();
            this.btnNovoTUsu = new System.Windows.Forms.Button();
            this.btnNovoTipoFunc = new System.Windows.Forms.Button();
            this.btnNovoFuncionario = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbFechar = new System.Windows.Forms.PictureBox();
            this.painelContainer = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.painelRetratil.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechar)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnValorMulta);
            this.panel2.Controls.Add(this.painelRetratil);
            this.panel2.Controls.Add(this.btnRelatorios);
            this.panel2.Controls.Add(this.btnNovoTUsu);
            this.panel2.Controls.Add(this.btnNovoTipoFunc);
            this.panel2.Controls.Add(this.btnNovoFuncionario);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 598);
            this.panel2.TabIndex = 1;
            // 
            // btnValorMulta
            // 
            this.btnValorMulta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnValorMulta.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnValorMulta.FlatAppearance.BorderSize = 0;
            this.btnValorMulta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnValorMulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValorMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValorMulta.ForeColor = System.Drawing.Color.White;
            this.btnValorMulta.Location = new System.Drawing.Point(0, 364);
            this.btnValorMulta.Name = "btnValorMulta";
            this.btnValorMulta.Size = new System.Drawing.Size(198, 42);
            this.btnValorMulta.TabIndex = 5;
            this.btnValorMulta.Text = "Valor multa";
            this.btnValorMulta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnValorMulta.UseVisualStyleBackColor = true;
            this.btnValorMulta.Click += new System.EventHandler(this.btnValorMulta_Click);
            this.btnValorMulta.MouseEnter += new System.EventHandler(this.btnMouseHover);
            this.btnValorMulta.MouseLeave += new System.EventHandler(this.btnLeave);
            this.btnValorMulta.MouseHover += new System.EventHandler(this.btnMouseHover);
            // 
            // painelRetratil
            // 
            this.painelRetratil.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.painelRetratil.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.painelRetratil.Controls.Add(this.btnRelatMulta);
            this.painelRetratil.Controls.Add(this.btnRelatEmp);
            this.painelRetratil.Controls.Add(this.btnRelatUsu);
            this.painelRetratil.Dock = System.Windows.Forms.DockStyle.Top;
            this.painelRetratil.Location = new System.Drawing.Point(0, 235);
            this.painelRetratil.Name = "painelRetratil";
            this.painelRetratil.Size = new System.Drawing.Size(198, 129);
            this.painelRetratil.TabIndex = 0;
            // 
            // btnRelatMulta
            // 
            this.btnRelatMulta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRelatMulta.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRelatMulta.FlatAppearance.BorderSize = 0;
            this.btnRelatMulta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnRelatMulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRelatMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatMulta.ForeColor = System.Drawing.Color.White;
            this.btnRelatMulta.Location = new System.Drawing.Point(0, 84);
            this.btnRelatMulta.Name = "btnRelatMulta";
            this.btnRelatMulta.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnRelatMulta.Size = new System.Drawing.Size(196, 42);
            this.btnRelatMulta.TabIndex = 8;
            this.btnRelatMulta.Text = " ● Usuários com multa";
            this.btnRelatMulta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRelatMulta.UseVisualStyleBackColor = true;
            this.btnRelatMulta.Click += new System.EventHandler(this.btnRelatMulta_Click);
            this.btnRelatMulta.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnRelatMulta.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnRelatMulta.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnRelatEmp
            // 
            this.btnRelatEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRelatEmp.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRelatEmp.FlatAppearance.BorderSize = 0;
            this.btnRelatEmp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnRelatEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRelatEmp.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatEmp.ForeColor = System.Drawing.Color.White;
            this.btnRelatEmp.Location = new System.Drawing.Point(0, 42);
            this.btnRelatEmp.Name = "btnRelatEmp";
            this.btnRelatEmp.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnRelatEmp.Size = new System.Drawing.Size(196, 42);
            this.btnRelatEmp.TabIndex = 7;
            this.btnRelatEmp.Text = " ● Empréstimos";
            this.btnRelatEmp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRelatEmp.UseVisualStyleBackColor = true;
            this.btnRelatEmp.Click += new System.EventHandler(this.btnRelatEmp_Click);
            this.btnRelatEmp.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnRelatEmp.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnRelatEmp.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnRelatUsu
            // 
            this.btnRelatUsu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRelatUsu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRelatUsu.FlatAppearance.BorderSize = 0;
            this.btnRelatUsu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.btnRelatUsu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRelatUsu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatUsu.ForeColor = System.Drawing.Color.White;
            this.btnRelatUsu.Location = new System.Drawing.Point(0, 0);
            this.btnRelatUsu.Name = "btnRelatUsu";
            this.btnRelatUsu.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnRelatUsu.Size = new System.Drawing.Size(196, 42);
            this.btnRelatUsu.TabIndex = 6;
            this.btnRelatUsu.Text = " ● Usuários";
            this.btnRelatUsu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRelatUsu.UseVisualStyleBackColor = true;
            this.btnRelatUsu.Click += new System.EventHandler(this.btnRelatUsu_Click);
            this.btnRelatUsu.MouseEnter += new System.EventHandler(this.btn_MouseHover2);
            this.btnRelatUsu.MouseLeave += new System.EventHandler(this.btn_Leave2);
            this.btnRelatUsu.MouseHover += new System.EventHandler(this.btn_MouseHover2);
            // 
            // btnRelatorios
            // 
            this.btnRelatorios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRelatorios.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRelatorios.FlatAppearance.BorderSize = 0;
            this.btnRelatorios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnRelatorios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRelatorios.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelatorios.ForeColor = System.Drawing.Color.White;
            this.btnRelatorios.Location = new System.Drawing.Point(0, 193);
            this.btnRelatorios.Name = "btnRelatorios";
            this.btnRelatorios.Size = new System.Drawing.Size(198, 42);
            this.btnRelatorios.TabIndex = 4;
            this.btnRelatorios.Text = "Relatórios";
            this.btnRelatorios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRelatorios.UseVisualStyleBackColor = true;
            this.btnRelatorios.Click += new System.EventHandler(this.btnRelatorios_Click);
            this.btnRelatorios.MouseEnter += new System.EventHandler(this.btnMouseHover);
            this.btnRelatorios.MouseLeave += new System.EventHandler(this.btnLeave);
            this.btnRelatorios.MouseHover += new System.EventHandler(this.btnMouseHover);
            // 
            // btnNovoTUsu
            // 
            this.btnNovoTUsu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovoTUsu.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNovoTUsu.FlatAppearance.BorderSize = 0;
            this.btnNovoTUsu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnNovoTUsu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovoTUsu.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoTUsu.ForeColor = System.Drawing.Color.White;
            this.btnNovoTUsu.Location = new System.Drawing.Point(0, 151);
            this.btnNovoTUsu.Name = "btnNovoTUsu";
            this.btnNovoTUsu.Size = new System.Drawing.Size(198, 42);
            this.btnNovoTUsu.TabIndex = 3;
            this.btnNovoTUsu.Text = "Cadastrar tipo de usuário";
            this.btnNovoTUsu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNovoTUsu.UseVisualStyleBackColor = true;
            this.btnNovoTUsu.Click += new System.EventHandler(this.BtnNovoTUsu_Click);
            this.btnNovoTUsu.MouseEnter += new System.EventHandler(this.btnMouseHover);
            this.btnNovoTUsu.MouseLeave += new System.EventHandler(this.btnLeave);
            this.btnNovoTUsu.MouseHover += new System.EventHandler(this.btnMouseHover);
            // 
            // btnNovoTipoFunc
            // 
            this.btnNovoTipoFunc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovoTipoFunc.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNovoTipoFunc.FlatAppearance.BorderSize = 0;
            this.btnNovoTipoFunc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnNovoTipoFunc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovoTipoFunc.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoTipoFunc.ForeColor = System.Drawing.Color.White;
            this.btnNovoTipoFunc.Location = new System.Drawing.Point(0, 109);
            this.btnNovoTipoFunc.Name = "btnNovoTipoFunc";
            this.btnNovoTipoFunc.Size = new System.Drawing.Size(198, 42);
            this.btnNovoTipoFunc.TabIndex = 2;
            this.btnNovoTipoFunc.Text = "Cadastrar tipo de funcionário";
            this.btnNovoTipoFunc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNovoTipoFunc.UseVisualStyleBackColor = true;
            this.btnNovoTipoFunc.Click += new System.EventHandler(this.btnNovoTipoFunc_Click);
            this.btnNovoTipoFunc.MouseEnter += new System.EventHandler(this.btnMouseHover);
            this.btnNovoTipoFunc.MouseLeave += new System.EventHandler(this.btnLeave);
            this.btnNovoTipoFunc.MouseHover += new System.EventHandler(this.btnMouseHover);
            // 
            // btnNovoFuncionario
            // 
            this.btnNovoFuncionario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovoFuncionario.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNovoFuncionario.FlatAppearance.BorderSize = 0;
            this.btnNovoFuncionario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnNovoFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovoFuncionario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovoFuncionario.ForeColor = System.Drawing.Color.White;
            this.btnNovoFuncionario.Location = new System.Drawing.Point(0, 67);
            this.btnNovoFuncionario.Name = "btnNovoFuncionario";
            this.btnNovoFuncionario.Size = new System.Drawing.Size(198, 42);
            this.btnNovoFuncionario.TabIndex = 1;
            this.btnNovoFuncionario.Text = "Cadastrar funcionário";
            this.btnNovoFuncionario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNovoFuncionario.UseVisualStyleBackColor = true;
            this.btnNovoFuncionario.Click += new System.EventHandler(this.BtnNovoFuncionario_Click);
            this.btnNovoFuncionario.MouseEnter += new System.EventHandler(this.btnMouseHover);
            this.btnNovoFuncionario.MouseLeave += new System.EventHandler(this.btnLeave);
            this.btnNovoFuncionario.MouseHover += new System.EventHandler(this.btnMouseHover);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(198, 67);
            this.panel1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(29, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Toledo Prudente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.label2.Location = new System.Drawing.Point(27, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 31);
            this.label2.TabIndex = 9;
            this.label2.Text = "Biblioteca";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lbTitulo);
            this.panel3.Controls.Add(this.pbFechar);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(200, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(833, 67);
            this.panel3.TabIndex = 2;
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbTitulo.Location = new System.Drawing.Point(40, 17);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(696, 32);
            this.lbTitulo.TabIndex = 9;
            this.lbTitulo.Text = "Acesso restrito - Área de gerenciamento do sistema";
            // 
            // pbFechar
            // 
            this.pbFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechar.Image = ((System.Drawing.Image)(resources.GetObject("pbFechar.Image")));
            this.pbFechar.Location = new System.Drawing.Point(804, 3);
            this.pbFechar.Name = "pbFechar";
            this.pbFechar.Size = new System.Drawing.Size(24, 21);
            this.pbFechar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechar.TabIndex = 0;
            this.pbFechar.TabStop = false;
            this.pbFechar.Click += new System.EventHandler(this.PbFechar_Click);
            // 
            // painelContainer
            // 
            this.painelContainer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("painelContainer.BackgroundImage")));
            this.painelContainer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.painelContainer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.painelContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.painelContainer.Location = new System.Drawing.Point(200, 67);
            this.painelContainer.Name = "painelContainer";
            this.painelContainer.Size = new System.Drawing.Size(833, 531);
            this.painelContainer.TabIndex = 3;
            this.painelContainer.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.painelContainer_ControlRemoved);
            // 
            // Gerenciamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1033, 598);
            this.Controls.Add(this.painelContainer);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Gerenciamento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gerenciamento";
            this.panel2.ResumeLayout(false);
            this.painelRetratil.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel painelContainer;
        private System.Windows.Forms.PictureBox pbFechar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnNovoFuncionario;
        private System.Windows.Forms.Button btnNovoTUsu;
        private System.Windows.Forms.Button btnValorMulta;
        public System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Button btnNovoTipoFunc;
        private System.Windows.Forms.Button btnRelatorios;
        private System.Windows.Forms.Panel painelRetratil;
        private System.Windows.Forms.Button btnRelatUsu;
        private System.Windows.Forms.Button btnRelatMulta;
        private System.Windows.Forms.Button btnRelatEmp;
    }
}