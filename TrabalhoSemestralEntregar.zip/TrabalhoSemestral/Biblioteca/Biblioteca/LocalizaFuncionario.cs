﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class LocalizaFuncionario : Form
    {
        public int codigo;

        public LocalizaFuncionario()
        {
            InitializeComponent();
        }

        private void LocalizaFuncionario_Load(object sender, EventArgs e)
        {
            txtFuncionario.Focus();
        }

        private void PbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar");
            }
        }

        private void BtnLocaliza_Click(object sender, EventArgs e)
        {
            dgvLocalizaFunc.DataSource =
                (new FuncionarioRepositorio()).Localizar(txtFuncionario.Text);

            for (int i = 3; i < dgvLocalizaFunc.Columns.Count; i++)
            {
                dgvLocalizaFunc.Columns[i].Visible = false;
            }

            dgvLocalizaFunc.Columns[0].HeaderText = "Código";
            dgvLocalizaFunc.Columns[2].HeaderText = "Funcionário";
            dgvLocalizaFunc.Columns[0].Width = 50;
            dgvLocalizaFunc.Columns[2].Width = 300;
            dgvLocalizaFunc.Columns.Remove("Codigo_TipoFuncionario");
        }

        private void DgvLocalizaFunc_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvLocalizaFunc.Rows[e.RowIndex].Cells["Matricula"].Value;
            this.Close();
        }
    }
}
