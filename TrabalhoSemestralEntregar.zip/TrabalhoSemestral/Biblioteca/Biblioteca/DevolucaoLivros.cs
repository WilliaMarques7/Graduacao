﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class DevolucaoLivros : Form
    {
        Emprestimo model;
        Inadimplentes inadimplentes;
        double valorDiario;
        double valorTotal;
        int dias;

        public DevolucaoLivros()
        {
            InitializeComponent();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar formulário!");
            }
        }

        private void DevolucaoLivros_Load(object sender, EventArgs e)
        {
            model = new Emprestimo();
            inadimplentes = new Inadimplentes();

            txtCodigoUsuario.Focus();
        }

        
        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                LocalizaUsuario localiza = new LocalizaUsuario();
                localiza.tipoConsulta = 1;
                localiza.ShowDialog();
                if (localiza.codigo != 0)
                {
                    Usuario usu = (new UsuarioRepositorio()).Localizar(localiza.codigo);
                    txtUsuario.Text = usu.Nome;
                    txtCodigoUsuario.Text = usu.Codigo_Usuario.ToString();
                    EmprestimosPendentes();
                }
                localiza.Dispose();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao localizar!");
            }
        }

        private void txtCodigoUsuario_TextChanged(object sender, EventArgs e)
        {
            if (txtCodigoUsuario.Text != "")
            {
                vw_UsuariosAtivos usu = (new UsuarioRepositorio()).LocalizarAtivos(int.Parse(txtCodigoUsuario.Text));
                if (usu != null)
                {
                    txtUsuario.Text = usu.Nome;
                    txtCodigoUsuario.Text = usu.Codigo_Usuario.ToString();
                    EmprestimosPendentes();
                }
                else
                {
                    txtUsuario.Text = "";
                    txtCodigoUsuario.Text = "";
                }
            }
            else
                txtCodigoUsuario.Text = "";
        }

        public void EmprestimosPendentes()
        {
            dgvLocalizaUsuario.DataSource =
                (new EmprestimoRepositorio()).LocalizaEmprestimoUsu(int.Parse(txtCodigoUsuario.Text));

            for (int i = 6; i < dgvLocalizaUsuario.Columns.Count; i++)
            {
                dgvLocalizaUsuario.Columns[i].Visible = false;
            }
            dgvLocalizaUsuario.Columns[0].HeaderText = "Emprestimo";
            dgvLocalizaUsuario.Columns[1].HeaderText = "Codigo_Usuario";
            dgvLocalizaUsuario.Columns[2].HeaderText = "Codigo_Exemplar";
            dgvLocalizaUsuario.Columns[3].HeaderText = "Titulo";
            dgvLocalizaUsuario.Columns[4].HeaderText = "Data_Emprestimo";
            dgvLocalizaUsuario.Columns[5].HeaderText = "Data_Prevista";
            dgvLocalizaUsuario.Columns[0].Width = 65;
            dgvLocalizaUsuario.Columns[1].Width = 50;
            dgvLocalizaUsuario.Columns[2].Width = 55;
            dgvLocalizaUsuario.Columns[3].Width =250;
        }

        public void VerificaValorMulta()
        {
            vw_ValorAtual multa = (new MultaRepositorio()).Localizar();

            valorDiario = double.Parse(multa.Valor_Multa.ToString());
        }

        public void CarregaInadimplentes(DateTime dataDevolucao, double valorTotal)
        {
            inadimplentes.Codigo_Inadimplente = 0;
            inadimplentes.Codigo_Usuario = int.Parse(txtCodigoUsuario.Text);
            inadimplentes.Multa_Valor = decimal.Parse(valorTotal.ToString());
            inadimplentes.Multa_Dat = dataDevolucao;
            inadimplentes.Multa_Paga = "N";
        }

        private void btnFinalizaEmp_Click(object sender, EventArgs e)
        {
            try
            {
                int CodExemplar;
                
                DateTime dataDevolucao = DateTime.Now.Date;
                DateTime dataPrevista;
                
                VerificaValorMulta();

                //percorrer todas as linhas selecionadas da grid
                foreach (DataGridViewRow linha in dgvLocalizaUsuario.SelectedRows)
                {
                    //Inserindo data efetiva da devolução
                    CodExemplar = (int)linha.Cells["Codigo_Exemplar"].Value;
                    Emprestimo emprestimo = (new EmprestimoRepositorio()).Localizar(CodExemplar, int.Parse(txtCodigoUsuario.Text));
                    emprestimo.Data_EfetivaDevolucao = dataDevolucao;
                    (new EmprestimoRepositorio()).Alterar(emprestimo);

                    //alterar status do exemplar está sendo feito por trigger
                    
                    //calcula multa e se necessário gerar
                    dataPrevista = emprestimo.Data_PrevistaDevolucao;
                    if(dataPrevista < dataDevolucao)
                    {
                        //calcula dias
                        dias = int.Parse(dataDevolucao.Subtract(dataPrevista).TotalDays.ToString());
                        
                        //calcula valor da multa
                        valorTotal = dias * valorDiario;

                        //carrega propriedades dos inadimplentes
                        CarregaInadimplentes(dataDevolucao, valorTotal);

                        //insere na tabela inadimplentes
                        (new InadimplentesRepositorio()).Inserir(inadimplentes);
                        ExibeMulta();

                    }
                    MessageBox.Show("Empréstimo finalizado." + Environment.NewLine +
                            "Devolução realizada com sucesso!");
                    EmprestimosPendentes();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao finalizar empréstimo!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            try
            {
                txtUsuario.Clear();
                txtCodigoUsuario.Clear();

                for (int i = 0; i < dgvLocalizaUsuario.Rows.Count; i++)
                {
                    dgvLocalizaUsuario.Rows[i].DataGridView.Columns.Clear();
                }

                txtUsuario.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao limpar!");
            }
        }

        public void ExibeMulta()
        {
            lblAvisoMulta.Visible = true;
            lblAviso.Visible = true;
            lblAviso2.Visible = true;
            lblAvisoMulta.Text = "Valor da multa: R$" + valorTotal.ToString();
            lblAviso.Text = "O valor da multa é calculado com base nos dias de atraso na devolução.";
            lblAviso2.Text = "Valor da multa R$ " + valorDiario.ToString() + ". Dias de atraso: " + dias;
        }
    }
}
