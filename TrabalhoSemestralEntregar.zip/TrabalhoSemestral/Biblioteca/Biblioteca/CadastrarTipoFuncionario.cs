﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarTipoFuncionario : Form
    {
        Tipo_Funcionario model;
        public int codigo;

        public CadastrarTipoFuncionario()
        {
            InitializeComponent();
        }

        private void CadastrarTipoFuncionario_Load(object sender, EventArgs e)
        {
            model = new Tipo_Funcionario();
            txtTipoFuncionario.Focus();

            Habilita(false);
            Habilita2(true);
        }

        private void pbFechar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void LimpaGeral()
        {
            txtCodigo.Clear();
            txtPesquisaFunc.Clear();
            txtTipoFuncionario.Clear();
            for (int i = 0; i < dgvResultadosBusca.RowCount; i++)
            {
                dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
            }
        }

        public void Habilita(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;

            if (btnAlterar.Enabled == false)
            {
                btnAlterar.BackColor = Color.LightGray;
                btnAlterar.ForeColor = Color.Black;
            }
            else
            {
                btnAlterar.BackColor = Color.FromArgb(0, 122, 204);
                btnAlterar.ForeColor = Color.White;
            }

            if (btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void Habilita2(bool status)
        {
            btnSalvar.Enabled = status;

            if (btnSalvar.Enabled == false)
            {
                btnSalvar.BackColor = Color.LightGray;
                btnSalvar.ForeColor = Color.Black;
            }
            else
            {
                btnSalvar.BackColor = Color.FromArgb(0, 122, 204);
                btnSalvar.ForeColor = Color.White;
            }
        }

        private void txtTipoFuncionario_Click(object sender, EventArgs e)
        {
            lblAviso.Visible = false;
        }

        public bool VerificaCampos()
        {
            bool retorno = true;

            if (txtTipoFuncionario.Text.Trim() != "")
                retorno = true;
            else
                retorno = false;

            return retorno;
        }

        public void CarregaProp()
        {
            model.Tipo = txtTipoFuncionario.Text;
            if (txtCodigo.Text == "")
                model.Codigo_TipoFuncionario = 0;
            else
                model.Codigo_TipoFuncionario = int.Parse(txtCodigo.Text);
        }

        public void CarregaCampos()
        {
            txtTipoFuncionario.Text = model.Tipo;
            txtCodigo.Text = model.Codigo_TipoFuncionario.ToString();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if (txtCodigo.Text == "")
                    {
                        if ((new TipoFuncionarioRepositorio()).LocalizaTipo(txtTipoFuncionario.Text)
                            == null)
                        {
                            (new TipoFuncionarioRepositorio()).Inserir(model);
                            MessageBox.Show("Tipo de funcionário cadastrado com sucesso!");
                            LimpaGeral();
                        }
                        else
                        {
                            MessageBox.Show("Tipo de funcionário já cadastrado!");
                            lblAviso.Visible = true;
                        }
                    }
                    else
                        (new TipoFuncionarioRepositorio()).Alterar(model);
                }
                else
                {
                    MessageBox.Show("Informe o tipo de funcionário!");
                    txtTipoFuncionario.Focus();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaGeral();
                Habilita2(true);
                Habilita(false);
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao limpar!");
            }
        }

        private void btnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                    dgvResultadosBusca.DataSource =
                        (new TipoFuncionarioRepositorio()).Localizar(txtPesquisaFunc.Text);

                    for (int i = 2; i < dgvResultadosBusca.Columns.Count; i++)
                    {
                        dgvResultadosBusca.Columns[i].Visible = false;
                    }
                    dgvResultadosBusca.Columns[0].HeaderText = "Código";
                    dgvResultadosBusca.Columns[1].HeaderText = "Tipo de funcionário";
                    dgvResultadosBusca.Columns[0].Width = 60;
                    dgvResultadosBusca.Columns[1].Width = 240;

             
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao procurar!");
            }
        }

        private void dgvResultadosBusca_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvResultadosBusca.Rows[e.RowIndex].Cells["Codigo_TipoFuncionario"].Value;
            if(codigo != 0)
            {
                model = (new TipoFuncionarioRepositorio()).Localizar(codigo);
                CarregaCampos();
                Habilita(true);
                Habilita2(false);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if (new TipoFuncionarioRepositorio().LocalizaTipo(txtTipoFuncionario.Text)
                        == null)
                    {
                        (new TipoFuncionarioRepositorio()).Alterar(model);
                        MessageBox.Show("Registro alterado com sucesso!");
                        btnProcurar_Click(sender, e);
                    }
                    else
                    {
                        MessageBox.Show("Tipo de funcionário já cadastrado!");
                        lblAviso.Visible = true;
                    }
                }
                else
                {
                    MessageBox.Show("Informe o tipo de funcionário!");
                    txtTipoFuncionario.Focus();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    (new TipoFuncionarioRepositorio()).Excluir(model);
                    MessageBox.Show("Registro excluído com sucesso!");

                    LimpaGeral();
                    Habilita(false);
                    Habilita2(true);
                }
                else
                    MessageBox.Show("Informe o tipo de funcionário!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir!");
            }
        }
    }
}
