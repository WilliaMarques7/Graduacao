﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class MultiplicaLivros : Form
    {
        Exemplares model;
        Livro livro;
        public int codigo;

        public MultiplicaLivros()
        {
            InitializeComponent();
        }

        private void MultiplicaLivros_Load(object sender, EventArgs e)
        {
            model = new Exemplares();
            LimpaTudo();
        }

        private void pbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro aofechar!");
            }
        }

        public void CarregaProp()
        {
            model.Codigo_Livro = int.Parse(txtCodigoLivro.Text);
            model.Status_Livro = cbStatus.Text.Substring(0, 1);
        }
        public void CarregaPropExclusao()
        {
            model.Codigo_Exemplar = int.Parse(txtCodigoExemplar.Text);
            model.Codigo_Livro = int.Parse(txtCodigoLivro.Text);
            model.Status_Livro = txtStatusExemplar.Text.Substring(0, 1);
        }

        public void VerificaLabel()
        {
            if(txtQtdExemplar.Text == "" && cbStatus.SelectedIndex == -1)
            {
                lblInformaExemplar.Visible = true;
                lblInformaExemplar.Text = "Informe a quantidade e o status!";
            }
            else
            {
                if (txtQtdExemplar.Text == "")
                {
                    lblInformaExemplar.Visible = true;
                    lblInformaExemplar.Text = "Informe a quantidade!";
                }
                if (cbStatus.SelectedIndex == -1)
                {
                    lblInformaExemplar.Visible = true;
                    lblInformaExemplar.Text = "Informe o status!";
                }
            }
        }

        public bool VerificaCampos()
        {
            bool retorno = false;

            if (txtCodigoLivro.Text != "" && txtQtdExemplar.Text != ""
                && txtLivro.Text != "" && cbStatus.SelectedIndex != -1)
                retorno = true;
            else
                retorno = false;

            VerificaLabel();

            return retorno;
        }
        
        public bool VerificaCamposExemplar()
        {
            bool retorno = false;

            if (txtTituloExemplar.Text != "" && txtCodigoExemplar.Text != ""
                && txtStatusExemplar.Text != "")
                retorno = true;
            else
                retorno = false;

            return retorno;
        }

        public void LimpaGrid()
        {
            for (int i = 0; i < dgvLocalizaLivro.RowCount; i++)
            {
                dgvLocalizaLivro.Rows[i].DataGridView.Columns.Clear();
            }
        }

        public void LimpaTudo()
        {
            txtBuscaLivro.Clear();
            txtCodigoExemplar.Clear();
            txtCodigoLivro.Clear();
            txtLivro.Clear();
            txtQtdExemplar.Clear();
            txtStatusExemplar.Clear();

            rbTitulo.Checked = false;
            rbExemplar.Checked = false;
            
            cbStatus.SelectedIndex = - 1;
            
            gbExemplares.Enabled = false;
            if (gbExemplares.Enabled == false)
                HabDesabBotoes(false);
            else
                HabDesabBotoes(true);

            gbRemoveExemplar.Enabled = false;
            if (gbRemoveExemplar.Enabled == false)
                HabDesabBotoes(false);
            else
                HabDesabBotoes(true);

            LimpaGrid();
        }

        public void HabDesabBotoes(bool status)
        {
            btnAdicionar.Enabled = status;
            btnExcluir.Enabled = !status;

            if (btnAdicionar.Enabled == false)
            {
                btnAdicionar.BackColor = Color.LightGray;
                btnAdicionar.ForeColor = Color.Black;
            }
            else
            {
                btnAdicionar.BackColor = Color.FromArgb(0, 122, 204);
                btnAdicionar.ForeColor = Color.White;
            }

            if (btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void pesquisarPorTitulo()
        {
            LimpaGrid();

            dgvLocalizaLivro.DataSource =
                    (new LivroRepositorio()).Localizar(txtBuscaLivro.Text);

            for (int i = 2; i < dgvLocalizaLivro.Columns.Count; i++)
            {
                dgvLocalizaLivro.Columns[i].Visible = false;
            }

            dgvLocalizaLivro.Columns[0].HeaderText = "Código";
            dgvLocalizaLivro.Columns[1].HeaderText = "Livro";
            dgvLocalizaLivro.Columns[0].Width = 50;
            dgvLocalizaLivro.Columns[1].Width = 300;
            dgvLocalizaLivro.Columns.Remove("Ano");
            dgvLocalizaLivro.Columns.Remove("Edicao");
            dgvLocalizaLivro.Columns.Remove("Codigo_Editora");
        }

        public void pesquisarPorExemplar()
        {
            dgvLocalizaLivro.DataSource =
                (new ExemplarRepositorio()).LocalizarExemplar(txtBuscaLivro.Text);

            for (int i = 4; i < dgvLocalizaLivro.Columns.Count; i++)
            {
                dgvLocalizaLivro.Columns[i].Visible = false;
            }

            dgvLocalizaLivro.Columns[0].HeaderText = "Exemplar";
            dgvLocalizaLivro.Columns[1].HeaderText = "Livro";
            dgvLocalizaLivro.Columns[2].HeaderText = "Título";
            dgvLocalizaLivro.Columns[3].HeaderText = "Status";
            
            dgvLocalizaLivro.Columns[0].Width = 50;
            dgvLocalizaLivro.Columns[1].Width = 50;
            dgvLocalizaLivro.Columns[2].Width = 250;
            dgvLocalizaLivro.Columns[3].Width = 250;
            //dgvLocalizaLivro.Columns.Remove("Status_Livro");
        }

        private void dgvLocalizaLivro_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(rbTitulo.Checked == true)
                {
                    codigo = (int)dgvLocalizaLivro.Rows[e.RowIndex].Cells["Codigo_livro"].Value;
                    if (codigo != 0)
                    {
                        gbExemplares.Enabled = true;
                        livro = (new LivroRepositorio()).Localizar(codigo);
                        txtCodigoLivro.Text = codigo.ToString();
                        txtLivro.Text = livro.Titulo;
                    }

                    HabDesabBotoes(true);
                }


                if(rbExemplar.Checked == true)
                {
                    codigo = (int)dgvLocalizaLivro.Rows[e.RowIndex].Cells[0].Value;
                    if(codigo != 0)
                    {
                        gbRemoveExemplar.Enabled = true;
                        txtTituloExemplar.Text = dgvLocalizaLivro.Rows[e.RowIndex].Cells[2].Value.ToString();
                        txtCodigoExemplar.Text = dgvLocalizaLivro.Rows[e.RowIndex].Cells[0].Value.ToString();
                        txtCodigoLivro.Text = dgvLocalizaLivro.Rows[e.RowIndex].Cells[1].Value.ToString();
                        if (dgvLocalizaLivro.Rows[e.RowIndex].Cells[3].Value.ToString() == "D")
                            txtStatusExemplar.Text = "Disponível";
                        else
                            txtStatusExemplar.Text = "Indisponível";
                    }

                    HabDesabBotoes(false);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao selecionar!");
            }
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            try
            {
                if (rbTitulo.Checked == false && rbExemplar.Checked == false)
                    MessageBox.Show("Escolha uma das duas opções:" + Environment.NewLine +
                        "pesquisar por livro ou pesquisar por exemplar.");
                else
                {
                    if (rbTitulo.Checked == true)
                        pesquisarPorTitulo();
                    if (rbExemplar.Checked == true)
                        pesquisarPorExemplar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao localizar!" + ex);
            }
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            try
            {
                if(VerificaCampos())
                {
                    int qtdExemplares = int.Parse(txtQtdExemplar.Text);
                    int contador = 1;

                    CarregaProp();

                    while (contador <= qtdExemplares)
                    {
                        (new ExemplarRepositorio()).Inserir(model);
                        contador++;
                    }

                    if(qtdExemplares == 1)
                        MessageBox.Show("Exemplar cadastro com sucesso!");
                    if(qtdExemplares > 1)
                        MessageBox.Show("Exemplares cadastros com sucesso!");

                    LimpaTudo();
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao adicionar exemplares!");
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaTudo();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao limpar!");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            { 
            //    if (VerificaCamposExemplar())
            //    {
                    CarregaPropExclusao();
                    (new ExemplarRepositorio()).Excluir(model);
                    MessageBox.Show("Exemplar excluido com sucesso!");
                    LimpaTudo();
                //}
                //else
                //    MessageBox.Show("Todos os campos devem estar preenchidos!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir exemplar!");
            }
        }

        private void txtQtdExemplar_Click(object sender, EventArgs e)
        {
            lblInformaExemplar.Visible = false;
        }

        private void cbStatus_Click(object sender, EventArgs e)
        {
            lblInformaExemplar.Visible = false;
        }
    }
}
