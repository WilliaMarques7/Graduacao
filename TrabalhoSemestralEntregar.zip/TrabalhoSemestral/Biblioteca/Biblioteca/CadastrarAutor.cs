﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarAutor : Form
    {
        Autor model;
        public int codigo;

        public CadastrarAutor()
        {
            InitializeComponent();
        }

        private void CadastrarAutor_Load(object sender, EventArgs e)
        {
            model = new Autor();
            txtNomeAutor.Focus();
            Habilita(false);
        }

        private void PbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtNomeAutor.Text == "")
                    this.Close();
                else
                {
                    if (MessageBox.Show("Sair sem finalizar?", "Atenção!",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        this.Close();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void CarregarProp()
        {
            model.Nome = txtNomeAutor.Text;
            if (txtCodigo.Text == "")
                model.Codigo_Autor = 0;
            else
                model.Codigo_Autor = int.Parse(txtCodigo.Text);
        }

        public void Habilita(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;

            if (btnAlterar.Enabled == false)
            {
                btnAlterar.BackColor = Color.LightGray;
                btnAlterar.ForeColor = Color.Black;
            }
            else
            {
                btnAlterar.BackColor = Color.FromArgb(0, 122, 204);
                btnAlterar.ForeColor = Color.White;
            }

            if (btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void Habilita2(bool status)
        {
            btnSalvar.Enabled = status;

            if (btnSalvar.Enabled == false)
            {
                btnSalvar.BackColor = Color.LightGray;
                btnSalvar.ForeColor = Color.Black;
            }
            else
            {
                btnSalvar.BackColor = Color.FromArgb(0, 122, 204);
                btnSalvar.ForeColor = Color.White;
            }
        }

        public void LimpaGeral()
        {
            txtCodigo.Clear();
            txtNomeAutor.Clear();
            txtPesquisaAutor.Clear();
            for (int i = 0; i < dgvResultadosBusca.RowCount; i++)
            {
                dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
            }
        }

        private void TxtNomeAutor_Click(object sender, EventArgs e)
        {
            lblAviso.Visible = false;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeAutor.Text != "")
                {
                    CarregarProp();

                    if (txtCodigo.Text == "")
                    {
                        if ((new AutorRepositorio()).LocalizaAutor(txtNomeAutor.Text) == null)
                        {
                            (new AutorRepositorio()).Inserir(model);
                            MessageBox.Show("Autor(a) cadastrado(a) com sucesso!");
                            txtNomeAutor.Clear();
                            Habilita(false);
                        }
                        else
                        {
                            MessageBox.Show("Autor já cadastrado");
                            lblAviso.Visible = true;
                        }
                    }
                    else
                        (new AutorRepositorio()).Alterar(model);
                }
                else
                    MessageBox.Show("Informe o nome do autor!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void BtnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                dgvResultadosBusca.DataSource = 
                    (new AutorRepositorio()).Localizar(txtPesquisaAutor.Text);
                    
                for(int i = 2; i< dgvResultadosBusca.Columns.Count; i++)
                {
                    dgvResultadosBusca.Columns[i].Visible = false; 
                }
                dgvResultadosBusca.Columns[0].HeaderText = "Código";
                dgvResultadosBusca.Columns[1].HeaderText = "Autor";
                dgvResultadosBusca.Columns[0].Width = 60;
                dgvResultadosBusca.Columns[1].Width = 240;
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao localizar");
            }
        }

        private void DgvResultadosBusca_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvResultadosBusca.Rows[e.RowIndex].Cells["Codigo_Autor"].Value;
            if (codigo != 0)
            {
                model = (new AutorRepositorio()).Localizar(codigo);
                txtCodigo.Text = model.Codigo_Autor.ToString();
                txtNomeAutor.Text = model.Nome;
                Habilita(true);
                Habilita2(false);
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeAutor.Text != "" && txtCodigo.Text != "")
                {
                    model.Nome = txtNomeAutor.Text;

                    if ((new AutorRepositorio().LocalizaAutor(txtNomeAutor.Text)) == null)
                    {
                        (new AutorRepositorio()).Alterar(model);
                        MessageBox.Show("Registrado alterado com sucesso!");
                        BtnProcurar_Click(sender, e);
                        Habilita(true);
                    }
                    else
                    {
                        MessageBox.Show("Autor já cadastrado!");
                        lblAviso.Visible = true;
                    }
                }
                else
                    MessageBox.Show("Selecione um registro!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNomeAutor.Text != "" && txtCodigo.Text != "")
                {
                    (new AutorRepositorio()).Excluir(model);
                    MessageBox.Show("Registro excluído com sucesso!");
                    
                    Habilita(false);
                    Habilita2(true);
                    LimpaGeral();
                }
                else
                    MessageBox.Show("Selecione um registro!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao Excluir!");
            }
        }

        private void BtnNovoRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                Habilita(false);
                Habilita2(true);
                LimpaGeral();
                txtNomeAutor.Focus();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao criar novo registro!");
            }
        }
    }
}
