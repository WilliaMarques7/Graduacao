﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastroUsuarios : Form
    {
        Usuario model;
        //public int codigo;

        public CadastroUsuarios()
        {
            InitializeComponent();
        }

        private void CadastroUsuarios_Load(object sender, EventArgs e)
        {
            model = new Usuario();

            txtNome.Focus();
            cbTipoUsuario.DataSource = (new TipoUsuarioRepositorio()).Localizar("");
            cbTipoUsuario.ValueMember = "Codigo_TipoUsuario";
            cbTipoUsuario.DisplayMember = "Tipo";
            cbTipoUsuario.SelectedIndex = -1;
        }

        private void PbFecharMenu_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void VerificaLabels()
        {
            if (txtNome.Text == "")
                lblInformeNome.Visible = true;
            else
                lblInformeNome.Visible = false;

            if (txtEmail.Text == "")
                lblInformeEmail.Visible = true;
            else
                lblInformeEmail.Visible = false;

            if (txtCPF.Text == "")
                lblInformaCpf.Visible = true;
            else
                lblInformaCpf.Visible = false;

            if (txtTelefone.Text == "")
                lblInformeTel.Visible = true;
            else
                lblInformeTel.Visible = false;

            if (rbFeminino.Checked == false && rbMasculino.Checked == false)
                lblInformeSexo.Visible = true;
            else
                lblInformeSexo.Visible = false;

            if (cbTipoUsuario.SelectedIndex == -1)
                lblInformeTipo.Visible = true;
            else
                lblInformeTipo.Visible = false;

            if (cbAtivo.SelectedIndex == -1)
                lblInformaAtivo.Visible = true;
            else
                lblInformaAtivo.Visible = false;
        }

        public void LimparCampos()
        {
            txtNome.Clear();
            txtEmail.Clear();
            txtCPF.Clear();
            txtTelefone.Clear();
            txtCodigo.Clear();
            cbTipoUsuario.SelectedIndex = -1;
            cbAtivo.SelectedIndex = -1;
            if (rbFeminino.Checked == true)
                rbFeminino.Checked = false;
            if (rbMasculino.Checked == true)
                rbMasculino.Checked = false;

            Habilita(false);
            Habilita2(true);

            txtNome.Focus();
        }

        public void CarregaCampos()
        {
            txtCodigo.Text = model.Codigo_Usuario.ToString();
            txtNome.Text = model.Nome;
            txtTelefone.Text = model.Telefone;
            txtEmail.Text = model.Email;
            txtCPF.Text = model.CPF;
            if (model.Sexo == "Feminino")
                rbFeminino.Checked = true;
            if (model.Sexo == "Masculino")
                rbMasculino.Checked = true;
            cbTipoUsuario.SelectedValue = model.TipoUsuario_codigo;

            if (model.Status == "S")
                cbAtivo.Text = "SIM";
            else
                cbAtivo.Text = "NÃO";

        }

        public bool VerificaCampos()
        {
            bool retorno = false;

            if (txtNome.Text.Trim() != "" && txtEmail.Text.Trim() != "" && txtCPF.Text.Trim() != ""
                && txtTelefone.Text.Trim() != "" && cbTipoUsuario.Text != "" && cbAtivo.Text != "")
            {
                if (rbFeminino.Checked == true || rbMasculino.Checked == true)
                    retorno = true;
            }
            else
                retorno = false;

            VerificaLabels();

            return retorno;
        }

        public void CarregaProp()
        {

            model.Nome = txtNome.Text;
            model.CPF = txtCPF.Text;
            model.Email = txtEmail.Text;
            model.Telefone = txtTelefone.Text;
            if (rbFeminino.Checked == true)
                model.Sexo = rbFeminino.Text;
            if(rbMasculino.Checked == true)
                model.Sexo = rbMasculino.Text;

            if (txtCodigo.Text == "")
                model.Codigo_Usuario = 0;
            else
                model.Codigo_Usuario = int.Parse(txtCodigo.Text);

            model.TipoUsuario_codigo = (int)cbTipoUsuario.SelectedValue;

            model.Status = cbAtivo.Text.Substring(0, 1);
        }

        public void Habilita(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;
        }

        public void Habilita2(bool status)
        {
            btnSalvar.Enabled = status;
            btnProcura.Enabled = status;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimparCampos();
            Habilita(false);
            Habilita2(true);
        }


        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if(txtCodigo.Text == "")
                    {
                        if ((new UsuarioRepositorio()).LocalizaExiste(txtNome.Text) == null ||
                            (new UsuarioRepositorio()).LocalizaExiste(txtNome.Text).TipoUsuario_codigo ==
                            model.TipoUsuario_codigo)
                        {
                            (new UsuarioRepositorio()).Inserir(model);
                            LimparCampos();
                            MessageBox.Show("Usuário cadastrado com sucesso!");
                        }
                        else
                            MessageBox.Show("Usuário já cadastrado!");
                    }
                    else
                    {
                        (new UsuarioRepositorio()).Alterar(model);
                        txtNome.Focus();
                    }
                }
                else
                    MessageBox.Show("Preencha todos os campos!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar!" + ex);
            }
        }

        private void btnProcura_Click(object sender, EventArgs e)
        {
            try
            {
                LocalizaUsuario frm = new LocalizaUsuario();
                frm.ShowDialog();
                if(frm.codigo != 0)
                {
                    model = (new UsuarioRepositorio()).Localizar(frm.codigo);
                    CarregaCampos();
                    Habilita(true);
                    Habilita2(false);
                }
                frm.Dispose();
                frm = null;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao localizar!" + ex);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if(txtCodigo.Text != "")
                    {
                        (new UsuarioRepositorio()).Alterar(model);
                        MessageBox.Show("Cadastro alterado com sucesso!");
                        btnNovo_Click(sender, e);
                    }
                }
                else
                    MessageBox.Show("Nenhum campo pode estar vazio!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    if(MessageBox.Show("Tem certeza que deseja excluir o registro?", "Atenção!",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, 
                        MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        (new UsuarioRepositorio()).Excluir(model);
                        MessageBox.Show("Registro excluído com sucesso!");
                        btnNovo_Click(sender, e);
                    }
                }
                else
                    MessageBox.Show("Nenhum campo pode estar vazio!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluír!");
            }
        }

        private void txtNome_Click(object sender, EventArgs e)
        {
            lblInformeNome.Visible = false;
        }

        private void txtCPF_Click(object sender, EventArgs e)
        {
            lblInformaCpf.Visible = false;
        }

        private void rbFeminino_Click(object sender, EventArgs e)
        {
            lblInformeSexo.Visible = false;
        }

        private void rbMasculino_Click(object sender, EventArgs e)
        {
            lblInformeSexo.Visible = false;
        }

        private void txtEmail_Click(object sender, EventArgs e)
        {
            lblInformeEmail.Visible = false;
        }

        private void txtTelefone_Click(object sender, EventArgs e)
        {
            lblInformeTel.Visible = false;
        }

        private void cbTipoUsuario_Click(object sender, EventArgs e)
        {
            lblInformeTipo.Visible = false;
        }

        private void cbAtivo_Click(object sender, EventArgs e)
        {
            lblInformaAtivo.Visible = false;
        }

        private void txtCPF_Leave(object sender, EventArgs e)
        {
            if (txtCPF.Text != "")
            {
                if (Funcoes.ValidaCPF(txtCPF.Text) == false || txtCPF.Text == "00000000000")
                {
                    MessageBox.Show("CPF Inválido!");
                    txtCPF.Text = "";
                }
            }
        }
    }
}
