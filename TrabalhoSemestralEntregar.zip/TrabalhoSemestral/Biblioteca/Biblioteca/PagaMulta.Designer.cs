﻿namespace Biblioteca
{
    partial class PagaMulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PagaMulta));
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLocalizar = new System.Windows.Forms.Button();
            this.txtCodigoUsuario = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgvLocalizaUsuario = new System.Windows.Forms.DataGridView();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.txtValorMulta = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCodigoMulta = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDataMulta = new System.Windows.Forms.DateTimePicker();
            this.txtStatusMuta = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gbDadosMulta = new System.Windows.Forms.GroupBox();
            this.txtNomeUsuario = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPagamentoMulta = new System.Windows.Forms.DateTimePicker();
            this.lblMultaPagaEm = new System.Windows.Forms.Label();
            this.btnPagar = new System.Windows.Forms.Button();
            this.btnLimpaGeral = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaUsuario)).BeginInit();
            this.gbDadosMulta.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(811, 1);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 12;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 17);
            this.label2.TabIndex = 22;
            this.label2.Text = "Código usuário";
            // 
            // btnLocalizar
            // 
            this.btnLocalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocalizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLocalizar.FlatAppearance.BorderSize = 0;
            this.btnLocalizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLocalizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLocalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizar.ForeColor = System.Drawing.Color.White;
            this.btnLocalizar.Location = new System.Drawing.Point(41, 99);
            this.btnLocalizar.Name = "btnLocalizar";
            this.btnLocalizar.Size = new System.Drawing.Size(165, 23);
            this.btnLocalizar.TabIndex = 1;
            this.btnLocalizar.Text = "Localizar";
            this.btnLocalizar.UseVisualStyleBackColor = false;
            this.btnLocalizar.Click += new System.EventHandler(this.btnLocalizar_Click);
            // 
            // txtCodigoUsuario
            // 
            this.txtCodigoUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoUsuario.Location = new System.Drawing.Point(169, 41);
            this.txtCodigoUsuario.Name = "txtCodigoUsuario";
            this.txtCodigoUsuario.ReadOnly = true;
            this.txtCodigoUsuario.Size = new System.Drawing.Size(96, 23);
            this.txtCodigoUsuario.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Usuário";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.Location = new System.Drawing.Point(41, 67);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(341, 23);
            this.txtUsuario.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvLocalizaUsuario);
            this.groupBox1.Controls.Add(this.btnLimpar);
            this.groupBox1.Controls.Add(this.txtUsuario);
            this.groupBox1.Controls.Add(this.btnLocalizar);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 70);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(428, 440);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Busca por usuários inadimplentes";
            // 
            // dgvLocalizaUsuario
            // 
            this.dgvLocalizaUsuario.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvLocalizaUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLocalizaUsuario.Location = new System.Drawing.Point(41, 127);
            this.dgvLocalizaUsuario.MultiSelect = false;
            this.dgvLocalizaUsuario.Name = "dgvLocalizaUsuario";
            this.dgvLocalizaUsuario.Size = new System.Drawing.Size(341, 287);
            this.dgvLocalizaUsuario.TabIndex = 3;
            this.dgvLocalizaUsuario.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLocalizaUsuario_CellDoubleClick_1);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpar.FlatAppearance.BorderSize = 0;
            this.btnLimpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLimpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(217, 99);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(165, 23);
            this.btnLimpar.TabIndex = 2;
            this.btnLimpar.Text = "Nova consulta";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // txtValorMulta
            // 
            this.txtValorMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorMulta.Location = new System.Drawing.Point(169, 167);
            this.txtValorMulta.Name = "txtValorMulta";
            this.txtValorMulta.ReadOnly = true;
            this.txtValorMulta.Size = new System.Drawing.Size(96, 23);
            this.txtValorMulta.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 17);
            this.label3.TabIndex = 74;
            this.label3.Text = "Valor da multa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(30, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 17);
            this.label4.TabIndex = 76;
            this.label4.Text = "Código multa";
            // 
            // txtCodigoMulta
            // 
            this.txtCodigoMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoMulta.Location = new System.Drawing.Point(169, 124);
            this.txtCodigoMulta.Name = "txtCodigoMulta";
            this.txtCodigoMulta.ReadOnly = true;
            this.txtCodigoMulta.Size = new System.Drawing.Size(96, 23);
            this.txtCodigoMulta.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(30, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 17);
            this.label5.TabIndex = 78;
            this.label5.Text = "Data da multa";
            // 
            // txtDataMulta
            // 
            this.txtDataMulta.Enabled = false;
            this.txtDataMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataMulta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtDataMulta.Location = new System.Drawing.Point(169, 213);
            this.txtDataMulta.Name = "txtDataMulta";
            this.txtDataMulta.Size = new System.Drawing.Size(117, 23);
            this.txtDataMulta.TabIndex = 4;
            // 
            // txtStatusMuta
            // 
            this.txtStatusMuta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatusMuta.Location = new System.Drawing.Point(169, 257);
            this.txtStatusMuta.Name = "txtStatusMuta";
            this.txtStatusMuta.ReadOnly = true;
            this.txtStatusMuta.Size = new System.Drawing.Size(96, 23);
            this.txtStatusMuta.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(30, 263);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 17);
            this.label6.TabIndex = 81;
            this.label6.Text = "Multa paga";
            // 
            // gbDadosMulta
            // 
            this.gbDadosMulta.Controls.Add(this.txtNomeUsuario);
            this.gbDadosMulta.Controls.Add(this.label7);
            this.gbDadosMulta.Controls.Add(this.txtPagamentoMulta);
            this.gbDadosMulta.Controls.Add(this.lblMultaPagaEm);
            this.gbDadosMulta.Controls.Add(this.txtStatusMuta);
            this.gbDadosMulta.Controls.Add(this.txtCodigoUsuario);
            this.gbDadosMulta.Controls.Add(this.label6);
            this.gbDadosMulta.Controls.Add(this.label2);
            this.gbDadosMulta.Controls.Add(this.txtDataMulta);
            this.gbDadosMulta.Controls.Add(this.label3);
            this.gbDadosMulta.Controls.Add(this.label5);
            this.gbDadosMulta.Controls.Add(this.txtValorMulta);
            this.gbDadosMulta.Controls.Add(this.label4);
            this.gbDadosMulta.Controls.Add(this.txtCodigoMulta);
            this.gbDadosMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDadosMulta.Location = new System.Drawing.Point(472, 70);
            this.gbDadosMulta.Name = "gbDadosMulta";
            this.gbDadosMulta.Size = new System.Drawing.Size(339, 360);
            this.gbDadosMulta.TabIndex = 82;
            this.gbDadosMulta.TabStop = false;
            this.gbDadosMulta.Text = "Dados da multa";
            this.gbDadosMulta.Visible = false;
            // 
            // txtNomeUsuario
            // 
            this.txtNomeUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeUsuario.Location = new System.Drawing.Point(169, 80);
            this.txtNomeUsuario.Name = "txtNomeUsuario";
            this.txtNomeUsuario.ReadOnly = true;
            this.txtNomeUsuario.Size = new System.Drawing.Size(142, 23);
            this.txtNomeUsuario.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(30, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 17);
            this.label7.TabIndex = 75;
            this.label7.Text = "Usuário";
            // 
            // txtPagamentoMulta
            // 
            this.txtPagamentoMulta.Enabled = false;
            this.txtPagamentoMulta.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPagamentoMulta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtPagamentoMulta.Location = new System.Drawing.Point(169, 302);
            this.txtPagamentoMulta.Name = "txtPagamentoMulta";
            this.txtPagamentoMulta.Size = new System.Drawing.Size(117, 23);
            this.txtPagamentoMulta.TabIndex = 6;
            this.txtPagamentoMulta.Visible = false;
            // 
            // lblMultaPagaEm
            // 
            this.lblMultaPagaEm.AutoSize = true;
            this.lblMultaPagaEm.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMultaPagaEm.Location = new System.Drawing.Point(30, 308);
            this.lblMultaPagaEm.Name = "lblMultaPagaEm";
            this.lblMultaPagaEm.Size = new System.Drawing.Size(113, 17);
            this.lblMultaPagaEm.TabIndex = 82;
            this.lblMultaPagaEm.Text = "Multa paga em:";
            this.lblMultaPagaEm.Visible = false;
            // 
            // btnPagar
            // 
            this.btnPagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnPagar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPagar.FlatAppearance.BorderSize = 0;
            this.btnPagar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnPagar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnPagar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPagar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPagar.ForeColor = System.Drawing.Color.White;
            this.btnPagar.Location = new System.Drawing.Point(472, 444);
            this.btnPagar.Name = "btnPagar";
            this.btnPagar.Size = new System.Drawing.Size(339, 30);
            this.btnPagar.TabIndex = 3;
            this.btnPagar.Text = "Efetuar pagamento";
            this.btnPagar.UseVisualStyleBackColor = false;
            this.btnPagar.Visible = false;
            this.btnPagar.Click += new System.EventHandler(this.btnPagar_Click);
            // 
            // btnLimpaGeral
            // 
            this.btnLimpaGeral.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLimpaGeral.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpaGeral.FlatAppearance.BorderSize = 0;
            this.btnLimpaGeral.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLimpaGeral.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLimpaGeral.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpaGeral.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpaGeral.ForeColor = System.Drawing.Color.White;
            this.btnLimpaGeral.Location = new System.Drawing.Point(472, 480);
            this.btnLimpaGeral.Name = "btnLimpaGeral";
            this.btnLimpaGeral.Size = new System.Drawing.Size(339, 30);
            this.btnLimpaGeral.TabIndex = 83;
            this.btnLimpaGeral.Text = "Limpar";
            this.btnLimpaGeral.UseVisualStyleBackColor = false;
            this.btnLimpaGeral.Visible = false;
            this.btnLimpaGeral.Click += new System.EventHandler(this.btnLimpaGeral_Click);
            // 
            // PagaMulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(833, 531);
            this.Controls.Add(this.btnLimpaGeral);
            this.Controls.Add(this.pbFechaForm);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnPagar);
            this.Controls.Add(this.gbDadosMulta);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PagaMulta";
            this.Text = "PagaMulta";
            this.Load += new System.EventHandler(this.PagaMulta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaUsuario)).EndInit();
            this.gbDadosMulta.ResumeLayout(false);
            this.gbDadosMulta.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLocalizar;
        private System.Windows.Forms.TextBox txtCodigoUsuario;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox txtValorMulta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCodigoMulta;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker txtDataMulta;
        private System.Windows.Forms.TextBox txtStatusMuta;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gbDadosMulta;
        private System.Windows.Forms.Label lblMultaPagaEm;
        private System.Windows.Forms.DataGridView dgvLocalizaUsuario;
        private System.Windows.Forms.DateTimePicker txtPagamentoMulta;
        private System.Windows.Forms.Button btnPagar;
        private System.Windows.Forms.Button btnLimpaGeral;
        private System.Windows.Forms.TextBox txtNomeUsuario;
        private System.Windows.Forms.Label label7;
    }
}