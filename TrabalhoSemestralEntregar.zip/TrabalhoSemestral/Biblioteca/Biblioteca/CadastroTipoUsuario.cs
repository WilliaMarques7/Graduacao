﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastroTipoUsuario : Form
    {
        TipoUsuario model;
        public int codigo;

        public CadastroTipoUsuario()
        {
            InitializeComponent();
        }

        private void CadastroTipoUsuario_Load(object sender, EventArgs e)
        {
            model = new TipoUsuario();
            txtTipoUsuario.Focus();
            Habilita(false);
            Habilita2(true);
        }

        public void CarregaProp()
        {
            model.Tipo = txtTipoUsuario.Text;
            model.Prazo = int.Parse(txtPrazo.Text);
            model.Quantidade_Livros = int.Parse(txtQtdlivros.Text);
        }

        public void CarregaCampos()
        {
            txtTipoUsuario.Text = model.Tipo;
            txtPrazo.Text = model.Prazo.ToString();
            txtQtdlivros.Text = model.Quantidade_Livros.ToString();
            txtCodigo.Text = model.Codigo_TipoUsuario.ToString();
        }

        public bool VerificaCampos()
        {
            bool retorno = false;

            if (txtTipoUsuario.Text != "" && txtPrazo.Text != ""
                && txtQtdlivros.Text != "")
                retorno = true;
            else
                retorno = false;

            return retorno;
        }

        public void Habilita(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;

            if (btnAlterar.Enabled == false)
            {
                btnAlterar.BackColor = Color.LightGray;
                btnAlterar.ForeColor = Color.Black;
            }
            else
            {
                btnAlterar.BackColor = Color.FromArgb(0, 122, 204);
                btnAlterar.ForeColor = Color.White;
            }

            if (btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void Habilita2(bool status)
        {
            btnSalvar.Enabled = status;

            if (btnSalvar.Enabled == false)
            {
                btnSalvar.BackColor = Color.LightGray;
                btnSalvar.ForeColor = Color.Black;
            }
            else
            {
                btnSalvar.BackColor = Color.FromArgb(0, 122, 204);
                btnSalvar.ForeColor = Color.White;
            }
        }

        public void LimpaTudo()
        {
            txtCodigo.Clear();
            txtTipoUsuario.Clear();
            txtPrazo.Clear();
            txtQtdlivros.Clear();
            for (int i = 0; i < dgvResultadosBusca.RowCount; i++)
            {
                dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
            }
        }

        private void PbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos() == false)
                    this.Close();
                else
                {
                    if (MessageBox.Show("Sair sem finalizar?", "Atenção!",
                       MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        this.Close();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar");
            }
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();

                    if (txtCodigo.Text == "")
                    {
                        if ((new TipoUsuarioRepositorio().LocalizarUsuario(txtTipoUsuario.Text)) 
                            == null)
                        {
                            (new TipoUsuarioRepositorio()).Inserir(model);
                            MessageBox.Show("Tipo de usuário cadastrado com sucesso!");
                            btnNovoRegistro_Click(sender, e);
                        }
                        else
                        {
                            MessageBox.Show("Tipo de usuário já cadastrado!");
                            lblAviso.Visible = true;
                        }
                    }
                    else
                        (new TipoUsuarioRepositorio()).Alterar(model);
                }
                else
                    MessageBox.Show("Todos os campos precisam ser preenchidos!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void txtTipoUsuario_Click(object sender, EventArgs e)
        {
            lblAviso.Visible = false;
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                LimpaTudo();
                Habilita(false);
                Habilita2(true);
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao gerar novo cadastro!");
            }
        }

        private void btnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                    dgvResultadosBusca.DataSource =
                        (new TipoUsuarioRepositorio()).Localizar(txtBuscaTipo.Text);

                    for (int i = 2; i < dgvResultadosBusca.Columns.Count; i++)
                    {
                        dgvResultadosBusca.Columns[i].Visible = false;
                    }

                    dgvResultadosBusca.Columns[0].HeaderText = "Código";
                    dgvResultadosBusca.Columns[1].HeaderText = "Tipo";
                    dgvResultadosBusca.Columns[0].Width = 60;
                    dgvResultadosBusca.Columns[1].Width = 240;
                
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao procurar!");
            }
        }

        private void dgvResultadosBusca_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvResultadosBusca.Rows[e.RowIndex].Cells["Codigo_TipoUsuario"].Value;
            if(codigo != 0)
            {
                model = (new TipoUsuarioRepositorio()).Localizar(codigo);
                CarregaCampos();
                Habilita(true);
                Habilita2(false);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();
                    (new TipoUsuarioRepositorio()).Alterar(model);
                    MessageBox.Show("Registro alterado com sucesso!");
                    btnProcurar_Click(sender, e);
                }
                else
                    MessageBox.Show("Todos os campos devem estar preenchidos!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (VerificaCampos())
                {
                    CarregaProp();
                    (new TipoUsuarioRepositorio()).Excluir(model);
                    MessageBox.Show("Registro excluído com sucesso!");
                    btnNovoRegistro_Click(sender, e);
                }
                else
                    MessageBox.Show("Todos os campos devem estar preenchidos" + Environment.NewLine +
                        "para confirmação dos dados!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir!");
            }
        }
    }
}
