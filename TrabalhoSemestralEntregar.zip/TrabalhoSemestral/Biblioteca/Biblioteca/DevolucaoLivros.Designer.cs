﻿namespace Biblioteca
{
    partial class DevolucaoLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DevolucaoLivros));
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.btnLocalizar = new System.Windows.Forms.Button();
            this.txtCodigoUsuario = new System.Windows.Forms.TextBox();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.dgvLocalizaUsuario = new System.Windows.Forms.DataGridView();
            this.btnFinalizaEmp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblAvisoMulta = new System.Windows.Forms.Label();
            this.lblAviso = new System.Windows.Forms.Label();
            this.lblAviso2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaUsuario)).BeginInit();
            this.SuspendLayout();
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(812, 0);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 12;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // btnLocalizar
            // 
            this.btnLocalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocalizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLocalizar.FlatAppearance.BorderSize = 0;
            this.btnLocalizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLocalizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLocalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalizar.ForeColor = System.Drawing.Color.White;
            this.btnLocalizar.Location = new System.Drawing.Point(429, 84);
            this.btnLocalizar.Name = "btnLocalizar";
            this.btnLocalizar.Size = new System.Drawing.Size(158, 23);
            this.btnLocalizar.TabIndex = 3;
            this.btnLocalizar.Text = "Localizar";
            this.btnLocalizar.UseVisualStyleBackColor = false;
            this.btnLocalizar.Click += new System.EventHandler(this.btnLocalizar_Click);
            // 
            // txtCodigoUsuario
            // 
            this.txtCodigoUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoUsuario.Location = new System.Drawing.Point(93, 84);
            this.txtCodigoUsuario.Name = "txtCodigoUsuario";
            this.txtCodigoUsuario.Size = new System.Drawing.Size(60, 23);
            this.txtCodigoUsuario.TabIndex = 1;
            this.txtCodigoUsuario.TextChanged += new System.EventHandler(this.txtCodigoUsuario_TextChanged);
            // 
            // txtUsuario
            // 
            this.txtUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.Location = new System.Drawing.Point(168, 84);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.ReadOnly = true;
            this.txtUsuario.Size = new System.Drawing.Size(255, 23);
            this.txtUsuario.TabIndex = 2;
            // 
            // dgvLocalizaUsuario
            // 
            this.dgvLocalizaUsuario.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvLocalizaUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLocalizaUsuario.Location = new System.Drawing.Point(93, 113);
            this.dgvLocalizaUsuario.MultiSelect = false;
            this.dgvLocalizaUsuario.Name = "dgvLocalizaUsuario";
            this.dgvLocalizaUsuario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLocalizaUsuario.Size = new System.Drawing.Size(658, 250);
            this.dgvLocalizaUsuario.TabIndex = 5;
            // 
            // btnFinalizaEmp
            // 
            this.btnFinalizaEmp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnFinalizaEmp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizaEmp.FlatAppearance.BorderSize = 0;
            this.btnFinalizaEmp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnFinalizaEmp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnFinalizaEmp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinalizaEmp.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizaEmp.ForeColor = System.Drawing.Color.White;
            this.btnFinalizaEmp.Location = new System.Drawing.Point(93, 369);
            this.btnFinalizaEmp.Name = "btnFinalizaEmp";
            this.btnFinalizaEmp.Size = new System.Drawing.Size(658, 29);
            this.btnFinalizaEmp.TabIndex = 6;
            this.btnFinalizaEmp.Text = "Finalizar Empréstimo";
            this.btnFinalizaEmp.UseVisualStyleBackColor = false;
            this.btnFinalizaEmp.Click += new System.EventHandler(this.btnFinalizaEmp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(90, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 17);
            this.label1.TabIndex = 74;
            this.label1.Text = "Código";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(165, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 75;
            this.label2.Text = "Usuário";
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpar.FlatAppearance.BorderSize = 0;
            this.btnLimpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnLimpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.btnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.White;
            this.btnLimpar.Location = new System.Drawing.Point(593, 84);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(158, 23);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Nova Pesquisa";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblAvisoMulta
            // 
            this.lblAvisoMulta.AutoSize = true;
            this.lblAvisoMulta.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvisoMulta.ForeColor = System.Drawing.Color.Red;
            this.lblAvisoMulta.Location = new System.Drawing.Point(89, 424);
            this.lblAvisoMulta.Name = "lblAvisoMulta";
            this.lblAvisoMulta.Size = new System.Drawing.Size(64, 23);
            this.lblAvisoMulta.TabIndex = 77;
            this.lblAvisoMulta.Text = "Multa";
            this.lblAvisoMulta.Visible = false;
            // 
            // lblAviso
            // 
            this.lblAviso.AutoSize = true;
            this.lblAviso.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAviso.ForeColor = System.Drawing.Color.Black;
            this.lblAviso.Location = new System.Drawing.Point(90, 447);
            this.lblAviso.Name = "lblAviso";
            this.lblAviso.Size = new System.Drawing.Size(42, 17);
            this.lblAviso.TabIndex = 78;
            this.lblAviso.Text = "Multa";
            this.lblAviso.Visible = false;
            // 
            // lblAviso2
            // 
            this.lblAviso2.AutoSize = true;
            this.lblAviso2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAviso2.ForeColor = System.Drawing.Color.Black;
            this.lblAviso2.Location = new System.Drawing.Point(90, 464);
            this.lblAviso2.Name = "lblAviso2";
            this.lblAviso2.Size = new System.Drawing.Size(42, 17);
            this.lblAviso2.TabIndex = 78;
            this.lblAviso2.Text = "Multa";
            this.lblAviso2.Visible = false;
            // 
            // DevolucaoLivros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(833, 531);
            this.Controls.Add(this.lblAviso2);
            this.Controls.Add(this.lblAviso);
            this.Controls.Add(this.lblAvisoMulta);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFinalizaEmp);
            this.Controls.Add(this.dgvLocalizaUsuario);
            this.Controls.Add(this.btnLocalizar);
            this.Controls.Add(this.txtCodigoUsuario);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.pbFechaForm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DevolucaoLivros";
            this.Text = "DevolucaoLivros";
            this.Load += new System.EventHandler(this.DevolucaoLivros_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaUsuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Button btnLocalizar;
        private System.Windows.Forms.TextBox txtCodigoUsuario;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.DataGridView dgvLocalizaUsuario;
        private System.Windows.Forms.Button btnFinalizaEmp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblAvisoMulta;
        private System.Windows.Forms.Label lblAviso;
        private System.Windows.Forms.Label lblAviso2;
    }
}