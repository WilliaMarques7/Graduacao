﻿namespace Biblioteca
{
    partial class LocalizaExemplar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocalizaExemplar));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTituloExemplar = new System.Windows.Forms.TextBox();
            this.dgvLocalizaExemplar = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaExemplar)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnLocaliza);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txtTituloExemplar);
            this.panel1.Controls.Add(this.dgvLocalizaExemplar);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(476, 366);
            this.panel1.TabIndex = 0;
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocaliza.FlatAppearance.BorderSize = 0;
            this.btnLocaliza.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnLocaliza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocaliza.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocaliza.ForeColor = System.Drawing.Color.White;
            this.btnLocaliza.Location = new System.Drawing.Point(303, 65);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(128, 23);
            this.btnLocaliza.TabIndex = 2;
            this.btnLocaliza.Text = "Buscar";
            this.btnLocaliza.UseVisualStyleBackColor = false;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(35, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 17);
            this.label9.TabIndex = 76;
            this.label9.Text = "Livro";
            // 
            // txtTituloExemplar
            // 
            this.txtTituloExemplar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTituloExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTituloExemplar.Location = new System.Drawing.Point(38, 66);
            this.txtTituloExemplar.Name = "txtTituloExemplar";
            this.txtTituloExemplar.Size = new System.Drawing.Size(239, 23);
            this.txtTituloExemplar.TabIndex = 1;
            // 
            // dgvLocalizaExemplar
            // 
            this.dgvLocalizaExemplar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvLocalizaExemplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLocalizaExemplar.Location = new System.Drawing.Point(38, 95);
            this.dgvLocalizaExemplar.MultiSelect = false;
            this.dgvLocalizaExemplar.Name = "dgvLocalizaExemplar";
            this.dgvLocalizaExemplar.Size = new System.Drawing.Size(393, 250);
            this.dgvLocalizaExemplar.TabIndex = 3;
            this.dgvLocalizaExemplar.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLocalizaExemplar_CellDoubleClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pbFechaForm);
            this.panel2.Location = new System.Drawing.Point(-1, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(476, 28);
            this.panel2.TabIndex = 78;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(18, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 79;
            this.label1.Text = "Livro disponíveis";
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(450, 3);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 3;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // LocalizaExemplar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(500, 390);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LocalizaExemplar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LocalizaExemplar";
            this.Load += new System.EventHandler(this.LocalizaExemplar_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaExemplar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTituloExemplar;
        private System.Windows.Forms.DataGridView dgvLocalizaExemplar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
    }
}