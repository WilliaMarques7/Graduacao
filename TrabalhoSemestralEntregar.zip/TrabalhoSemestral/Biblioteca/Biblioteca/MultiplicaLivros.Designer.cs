﻿namespace Biblioteca
{
    partial class MultiplicaLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MultiplicaLivros));
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbExemplar = new System.Windows.Forms.RadioButton();
            this.rbTitulo = new System.Windows.Forms.RadioButton();
            this.btnNovo = new System.Windows.Forms.Button();
            this.gbRemoveExemplar = new System.Windows.Forms.GroupBox();
            this.txtStatusExemplar = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTituloExemplar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCodigoExemplar = new System.Windows.Forms.TextBox();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.gbExemplares = new System.Windows.Forms.GroupBox();
            this.lblInformaExemplar = new System.Windows.Forms.Label();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtLivro = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCodigoLivro = new System.Windows.Forms.TextBox();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtQtdExemplar = new System.Windows.Forms.TextBox();
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.dgvLocalizaLivro = new System.Windows.Forms.DataGridView();
            this.txtBuscaLivro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            this.panel1.SuspendLayout();
            this.gbRemoveExemplar.SuspendLayout();
            this.gbExemplares.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaLivro)).BeginInit();
            this.SuspendLayout();
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(550, -1);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 2;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.rbExemplar);
            this.panel1.Controls.Add(this.rbTitulo);
            this.panel1.Controls.Add(this.btnNovo);
            this.panel1.Controls.Add(this.gbRemoveExemplar);
            this.panel1.Controls.Add(this.gbExemplares);
            this.panel1.Controls.Add(this.btnLocaliza);
            this.panel1.Controls.Add(this.dgvLocalizaLivro);
            this.panel1.Controls.Add(this.txtBuscaLivro);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pbFechaForm);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(572, 538);
            this.panel1.TabIndex = 3;
            // 
            // rbExemplar
            // 
            this.rbExemplar.AutoSize = true;
            this.rbExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbExemplar.Location = new System.Drawing.Point(292, 34);
            this.rbExemplar.Name = "rbExemplar";
            this.rbExemplar.Size = new System.Drawing.Size(175, 21);
            this.rbExemplar.TabIndex = 2;
            this.rbExemplar.TabStop = true;
            this.rbExemplar.Text = "Pesquisar por exemplar";
            this.rbExemplar.UseVisualStyleBackColor = true;
            // 
            // rbTitulo
            // 
            this.rbTitulo.AutoSize = true;
            this.rbTitulo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTitulo.Location = new System.Drawing.Point(116, 34);
            this.rbTitulo.Name = "rbTitulo";
            this.rbTitulo.Size = new System.Drawing.Size(148, 21);
            this.rbTitulo.TabIndex = 1;
            this.rbTitulo.TabStop = true;
            this.rbTitulo.Text = "Pesquisar por título";
            this.rbTitulo.UseVisualStyleBackColor = true;
            // 
            // btnNovo
            // 
            this.btnNovo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovo.ForeColor = System.Drawing.Color.White;
            this.btnNovo.Location = new System.Drawing.Point(292, 103);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(183, 23);
            this.btnNovo.TabIndex = 4;
            this.btnNovo.Text = "Limpar";
            this.btnNovo.UseVisualStyleBackColor = false;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // gbRemoveExemplar
            // 
            this.gbRemoveExemplar.Controls.Add(this.txtStatusExemplar);
            this.gbRemoveExemplar.Controls.Add(this.label7);
            this.gbRemoveExemplar.Controls.Add(this.label6);
            this.gbRemoveExemplar.Controls.Add(this.txtTituloExemplar);
            this.gbRemoveExemplar.Controls.Add(this.label5);
            this.gbRemoveExemplar.Controls.Add(this.txtCodigoExemplar);
            this.gbRemoveExemplar.Controls.Add(this.btnExcluir);
            this.gbRemoveExemplar.Enabled = false;
            this.gbRemoveExemplar.Location = new System.Drawing.Point(292, 294);
            this.gbRemoveExemplar.Name = "gbRemoveExemplar";
            this.gbRemoveExemplar.Size = new System.Drawing.Size(254, 224);
            this.gbRemoveExemplar.TabIndex = 7;
            this.gbRemoveExemplar.TabStop = false;
            this.gbRemoveExemplar.Text = "Remover exemplares";
            // 
            // txtStatusExemplar
            // 
            this.txtStatusExemplar.Enabled = false;
            this.txtStatusExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatusExemplar.Location = new System.Drawing.Point(95, 121);
            this.txtStatusExemplar.Name = "txtStatusExemplar";
            this.txtStatusExemplar.Size = new System.Drawing.Size(143, 23);
            this.txtStatusExemplar.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(16, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 17);
            this.label7.TabIndex = 79;
            this.label7.Text = "Título";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(92, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 17);
            this.label6.TabIndex = 78;
            this.label6.Text = "Status";
            // 
            // txtTituloExemplar
            // 
            this.txtTituloExemplar.Enabled = false;
            this.txtTituloExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTituloExemplar.Location = new System.Drawing.Point(19, 54);
            this.txtTituloExemplar.Name = "txtTituloExemplar";
            this.txtTituloExemplar.Size = new System.Drawing.Size(219, 23);
            this.txtTituloExemplar.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 17);
            this.label5.TabIndex = 77;
            this.label5.Text = "Exemplar";
            // 
            // txtCodigoExemplar
            // 
            this.txtCodigoExemplar.Enabled = false;
            this.txtCodigoExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoExemplar.Location = new System.Drawing.Point(19, 121);
            this.txtCodigoExemplar.Name = "txtCodigoExemplar";
            this.txtCodigoExemplar.Size = new System.Drawing.Size(64, 23);
            this.txtCodigoExemplar.TabIndex = 1;
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.ForeColor = System.Drawing.Color.White;
            this.btnExcluir.Location = new System.Drawing.Point(19, 182);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(219, 23);
            this.btnExcluir.TabIndex = 3;
            this.btnExcluir.Text = "Remover";
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // gbExemplares
            // 
            this.gbExemplares.Controls.Add(this.lblInformaExemplar);
            this.gbExemplares.Controls.Add(this.btnAdicionar);
            this.gbExemplares.Controls.Add(this.label4);
            this.gbExemplares.Controls.Add(this.txtLivro);
            this.gbExemplares.Controls.Add(this.label3);
            this.gbExemplares.Controls.Add(this.txtCodigoLivro);
            this.gbExemplares.Controls.Add(this.cbStatus);
            this.gbExemplares.Controls.Add(this.label2);
            this.gbExemplares.Controls.Add(this.txtQtdExemplar);
            this.gbExemplares.Enabled = false;
            this.gbExemplares.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbExemplares.Location = new System.Drawing.Point(25, 294);
            this.gbExemplares.Name = "gbExemplares";
            this.gbExemplares.Size = new System.Drawing.Size(261, 224);
            this.gbExemplares.TabIndex = 6;
            this.gbExemplares.TabStop = false;
            this.gbExemplares.Text = "Adicionar exemplares";
            // 
            // lblInformaExemplar
            // 
            this.lblInformaExemplar.AutoSize = true;
            this.lblInformaExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformaExemplar.ForeColor = System.Drawing.Color.Red;
            this.lblInformaExemplar.Location = new System.Drawing.Point(22, 155);
            this.lblInformaExemplar.Name = "lblInformaExemplar";
            this.lblInformaExemplar.Size = new System.Drawing.Size(14, 17);
            this.lblInformaExemplar.TabIndex = 77;
            this.lblInformaExemplar.Text = "x";
            this.lblInformaExemplar.Visible = false;
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnAdicionar.FlatAppearance.BorderSize = 0;
            this.btnAdicionar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.White;
            this.btnAdicionar.Location = new System.Drawing.Point(20, 182);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(219, 23);
            this.btnAdicionar.TabIndex = 4;
            this.btnAdicionar.Text = "Adicionar ";
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 17);
            this.label4.TabIndex = 76;
            this.label4.Text = "Título";
            // 
            // txtLivro
            // 
            this.txtLivro.Enabled = false;
            this.txtLivro.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLivro.Location = new System.Drawing.Point(20, 54);
            this.txtLivro.Name = "txtLivro";
            this.txtLivro.Size = new System.Drawing.Size(219, 23);
            this.txtLivro.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(93, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 17);
            this.label3.TabIndex = 75;
            this.label3.Text = "Status";
            // 
            // txtCodigoLivro
            // 
            this.txtCodigoLivro.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoLivro.Location = new System.Drawing.Point(191, 20);
            this.txtCodigoLivro.Name = "txtCodigoLivro";
            this.txtCodigoLivro.Size = new System.Drawing.Size(48, 23);
            this.txtCodigoLivro.TabIndex = 71;
            this.txtCodigoLivro.Visible = false;
            // 
            // cbStatus
            // 
            this.cbStatus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] {
            "DISPONÍVEL",
            "INDISPONÍVEL"});
            this.cbStatus.Location = new System.Drawing.Point(96, 117);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(143, 25);
            this.cbStatus.TabIndex = 3;
            this.cbStatus.Click += new System.EventHandler(this.cbStatus_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 73;
            this.label2.Text = "Qtd.";
            // 
            // txtQtdExemplar
            // 
            this.txtQtdExemplar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQtdExemplar.Location = new System.Drawing.Point(20, 119);
            this.txtQtdExemplar.Name = "txtQtdExemplar";
            this.txtQtdExemplar.Size = new System.Drawing.Size(59, 23);
            this.txtQtdExemplar.TabIndex = 2;
            this.txtQtdExemplar.Click += new System.EventHandler(this.txtQtdExemplar_Click);
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocaliza.FlatAppearance.BorderSize = 0;
            this.btnLocaliza.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnLocaliza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocaliza.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocaliza.ForeColor = System.Drawing.Color.White;
            this.btnLocaliza.Location = new System.Drawing.Point(102, 103);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(184, 23);
            this.btnLocaliza.TabIndex = 3;
            this.btnLocaliza.Text = "Buscar";
            this.btnLocaliza.UseVisualStyleBackColor = false;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // dgvLocalizaLivro
            // 
            this.dgvLocalizaLivro.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvLocalizaLivro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLocalizaLivro.Location = new System.Drawing.Point(102, 132);
            this.dgvLocalizaLivro.Name = "dgvLocalizaLivro";
            this.dgvLocalizaLivro.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLocalizaLivro.Size = new System.Drawing.Size(373, 146);
            this.dgvLocalizaLivro.TabIndex = 5;
            this.dgvLocalizaLivro.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLocalizaLivro_CellDoubleClick);
            // 
            // txtBuscaLivro
            // 
            this.txtBuscaLivro.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBuscaLivro.Location = new System.Drawing.Point(170, 74);
            this.txtBuscaLivro.Name = "txtBuscaLivro";
            this.txtBuscaLivro.Size = new System.Drawing.Size(274, 23);
            this.txtBuscaLivro.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Livro";
            // 
            // MultiplicaLivros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(596, 562);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MultiplicaLivros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MultiplicaLivros";
            this.Load += new System.EventHandler(this.MultiplicaLivros_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbRemoveExemplar.ResumeLayout(false);
            this.gbRemoveExemplar.PerformLayout();
            this.gbExemplares.ResumeLayout(false);
            this.gbExemplares.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaLivro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtBuscaLivro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.DataGridView dgvLocalizaLivro;
        private System.Windows.Forms.TextBox txtCodigoLivro;
        private System.Windows.Forms.GroupBox gbExemplares;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtQtdExemplar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtLivro;
        private System.Windows.Forms.Button btnAdicionar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.GroupBox gbRemoveExemplar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCodigoExemplar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Label lblInformaExemplar;
        private System.Windows.Forms.RadioButton rbExemplar;
        private System.Windows.Forms.RadioButton rbTitulo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTituloExemplar;
        private System.Windows.Forms.TextBox txtStatusExemplar;
    }
}