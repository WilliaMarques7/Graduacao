﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repositorio;

namespace Biblioteca
{
    public partial class CadastrarEditora : Form
    {
        Editora model;
        public int codigo;

        public CadastrarEditora()
        {
            InitializeComponent();
        }

        private void CadastrarEditora_Load(object sender, EventArgs e)
        {
            model = new Editora();
            txtEditora.Focus();
            Habilita(false);
        }

        private void PbFechaForm_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEditora.Text == "")
                {
                    this.Close();
                }
                else
                {
                    if (MessageBox.Show("Sair sem finalizar?", "Atenção!",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        this.Close();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao fechar!");
            }
        }

        public void Habilita(bool status)
        {
            btnAlterar.Enabled = status;
            btnExcluir.Enabled = status;

            if (btnAlterar.Enabled == false)
            {
                btnAlterar.BackColor = Color.LightGray;
                btnAlterar.ForeColor = Color.Black;
            }
            else
            {
                btnAlterar.BackColor = Color.FromArgb(0, 122, 204);
                btnAlterar.ForeColor = Color.White;
            }

            if (btnExcluir.Enabled == false)
            {
                btnExcluir.BackColor = Color.LightGray;
                btnExcluir.ForeColor = Color.Black;
            }
            else
            {
                btnExcluir.BackColor = Color.FromArgb(0, 122, 204);
                btnExcluir.ForeColor = Color.White;
            }
        }

        public void Habilita2(bool status)
        {
            btnSalvar.Enabled = status;

            if (btnSalvar.Enabled == false)
            {
                btnSalvar.BackColor = Color.LightGray;
                btnSalvar.ForeColor = Color.Black;
            }
            else
            {
                btnSalvar.BackColor = Color.FromArgb(0, 122, 204);
                btnSalvar.ForeColor = Color.White;
            }
        }

        public void LimpaGeral()
        {
            txtCodigo.Clear();
            txtEditora.Clear();
            txtPesquisaEditora.Clear();
            for (int i = 0; i < dgvResultadosBusca.RowCount; i++)
            {
                dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
            }
        }

        public void CarregaProp()
        {
            model.Nome = txtEditora.Text;
            if (txtCodigo.Text == "")
                model.Codigo_Editora = 0;
            else
                model.Codigo_Editora = int.Parse(txtCodigo.Text);
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEditora.Text != "")
                {
                    CarregaProp();

                    if (txtCodigo.Text == "")
                    {
                        if ((new EditoraRepositorio()).LocalizaEditora(txtEditora.Text) == null)
                        {
                            (new EditoraRepositorio()).Inserir(model);
                            MessageBox.Show("Registro salvo com sucesso!");
                            txtEditora.Clear();
                            Habilita(false);
                        }
                        else
                        {
                            lblAviso.Visible = true;
                            MessageBox.Show("Editora já cadastrada!");
                        }
                    }
                    else
                        (new EditoraRepositorio()).Alterar(model);
                }
                else
                    MessageBox.Show("Informe a Editora!");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao salvar!");
            }
        }

        private void BtnProcurar_Click(object sender, EventArgs e)
        {
            try
            {
                    dgvResultadosBusca.DataSource =
                        (new EditoraRepositorio()).Localizar(txtPesquisaEditora.Text);

                    for (int i = 2; i < dgvResultadosBusca.Columns.Count; i++)
                    {
                        dgvResultadosBusca.Columns[i].Visible = false;
                    }
                    dgvResultadosBusca.Columns[0].HeaderText = "Código";
                    dgvResultadosBusca.Columns[1].HeaderText = "Editora";
                    dgvResultadosBusca.Columns[0].Width = 60;
                    dgvResultadosBusca.Columns[1].Width = 240;
                
            }
            catch (Exception)
            {

                MessageBox.Show("Erro ao procurar!");
            }
        }

        private void BtnNovoRegistro_Click(object sender, EventArgs e)
        {
            try
            {
                Habilita(false);
                Habilita2(true);
                LimpaGeral();
                for (int i = 0; i < dgvResultadosBusca.RowCount; i++)
                {
                    dgvResultadosBusca.Rows[i].DataGridView.Columns.Clear();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro!");
            }
        }

        private void DgvResultadosBusca_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = (int)dgvResultadosBusca.Rows[e.RowIndex].Cells["Codigo_Editora"].Value;
            if (codigo != 0)
            {
                model = (new EditoraRepositorio()).Localizar(codigo);
                txtCodigo.Text = model.Codigo_Editora.ToString();
                txtEditora.Text = model.Nome.ToString();
                Habilita(true);
                Habilita2(false);
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEditora.Text != "" && txtCodigo.Text != "")
                {
                    model.Nome = txtEditora.Text;
                    if ((new EditoraRepositorio().LocalizaEditora(txtEditora.Text)) == null)
                    {
                        (new EditoraRepositorio()).Alterar(model);
                        MessageBox.Show("Registro alterado com sucesso!");
                        BtnProcurar_Click(sender, e);
                        Habilita(true);
                    }
                    else
                    {
                        MessageBox.Show("Editora já cadastrada!");
                        lblAviso.Visible = true;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar!");
            }
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEditora.Text != "" && txtCodigo.Text != "")
                {
                    (new EditoraRepositorio()).Excluir(model);
                    MessageBox.Show("Registro excluído com sucesso!");
                    BtnProcurar_Click(sender, e);
                }
                else
                    MessageBox.Show("Selecione um registro!");

                Habilita2(true);
                Habilita(false);
                LimpaGeral();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao excluir!");
            }
        }

        private void TxtEditora_Click(object sender, EventArgs e)
        {
            lblAviso.Visible = false;
        }
    }
}
