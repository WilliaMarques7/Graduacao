﻿namespace Biblioteca
{
    partial class CadastrarLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarLivro));
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.txtTitulo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbAutor = new System.Windows.Forms.ComboBox();
            this.dgvAutor = new System.Windows.Forms.DataGridView();
            this.dgvGenero = new System.Windows.Forms.DataGridView();
            this.cbGenero = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnProcura = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEdicao = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAno = new System.Windows.Forms.TextBox();
            this.pbAddAutor = new System.Windows.Forms.PictureBox();
            this.pbRemoveAutor = new System.Windows.Forms.PictureBox();
            this.pbRemoveGen = new System.Windows.Forms.PictureBox();
            this.pbAddGen = new System.Windows.Forms.PictureBox();
            this.lblInformeTitulo = new System.Windows.Forms.Label();
            this.lblInformeEdicao = new System.Windows.Forms.Label();
            this.lblInformeAno = new System.Windows.Forms.Label();
            this.lblInformeAutor = new System.Windows.Forms.Label();
            this.lblInformeGenero = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbEditora = new System.Windows.Forms.ComboBox();
            this.lblInformaEditora = new System.Windows.Forms.Label();
            this.txtCodigoAutor = new System.Windows.Forms.TextBox();
            this.txtCodigoGen = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.btnMultiplica = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAutor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGenero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddAutor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRemoveAutor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRemoveGen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddGen)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(809, 3);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(21, 20);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 1;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // txtTitulo
            // 
            this.txtTitulo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitulo.Location = new System.Drawing.Point(36, 123);
            this.txtTitulo.Name = "txtTitulo";
            this.txtTitulo.Size = new System.Drawing.Size(252, 23);
            this.txtTitulo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Título";
            // 
            // txtCodigo
            // 
            this.txtCodigo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodigo.Enabled = false;
            this.txtCodigo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigo.Location = new System.Drawing.Point(95, 63);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(73, 23);
            this.txtCodigo.TabIndex = 66;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(31, 69);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 17);
            this.label18.TabIndex = 67;
            this.label18.Text = "Código";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 17);
            this.label2.TabIndex = 68;
            this.label2.Text = "Autor";
            // 
            // cbAutor
            // 
            this.cbAutor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAutor.FormattingEnabled = true;
            this.cbAutor.Location = new System.Drawing.Point(28, 224);
            this.cbAutor.Name = "cbAutor";
            this.cbAutor.Size = new System.Drawing.Size(151, 25);
            this.cbAutor.TabIndex = 5;
            // 
            // dgvAutor
            // 
            this.dgvAutor.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvAutor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAutor.Location = new System.Drawing.Point(185, 224);
            this.dgvAutor.Name = "dgvAutor";
            this.dgvAutor.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAutor.Size = new System.Drawing.Size(226, 149);
            this.dgvAutor.TabIndex = 70;
            // 
            // dgvGenero
            // 
            this.dgvGenero.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvGenero.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGenero.Location = new System.Drawing.Point(587, 224);
            this.dgvGenero.Name = "dgvGenero";
            this.dgvGenero.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGenero.Size = new System.Drawing.Size(226, 149);
            this.dgvGenero.TabIndex = 73;
            // 
            // cbGenero
            // 
            this.cbGenero.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGenero.FormattingEnabled = true;
            this.cbGenero.Location = new System.Drawing.Point(430, 224);
            this.cbGenero.Name = "cbGenero";
            this.cbGenero.Size = new System.Drawing.Size(151, 25);
            this.cbGenero.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(427, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 71;
            this.label3.Text = "Gênero";
            // 
            // btnNovo
            // 
            this.btnNovo.BackColor = System.Drawing.Color.White;
            this.btnNovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovo.FlatAppearance.BorderSize = 0;
            this.btnNovo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNovo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnNovo.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo.Image")));
            this.btnNovo.Location = new System.Drawing.Point(583, 409);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(85, 95);
            this.btnNovo.TabIndex = 11;
            this.btnNovo.Text = "Novo";
            this.btnNovo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNovo.UseVisualStyleBackColor = false;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.BackColor = System.Drawing.Color.White;
            this.btnAlterar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterar.Enabled = false;
            this.btnAlterar.FlatAppearance.BorderSize = 0;
            this.btnAlterar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btnAlterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlterar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAlterar.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterar.Image")));
            this.btnAlterar.Location = new System.Drawing.Point(326, 409);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(85, 95);
            this.btnAlterar.TabIndex = 9;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAlterar.UseVisualStyleBackColor = false;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.Color.White;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.FlatAppearance.BorderSize = 0;
            this.btnSalvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnSalvar.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar.Image")));
            this.btnSalvar.Location = new System.Drawing.Point(58, 409);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(85, 95);
            this.btnSalvar.TabIndex = 7;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.BackColor = System.Drawing.Color.White;
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.Enabled = false;
            this.btnExcluir.FlatAppearance.BorderSize = 0;
            this.btnExcluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btnExcluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExcluir.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnExcluir.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Image")));
            this.btnExcluir.Location = new System.Drawing.Point(456, 409);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(85, 95);
            this.btnExcluir.TabIndex = 10;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExcluir.UseVisualStyleBackColor = false;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnProcura
            // 
            this.btnProcura.BackColor = System.Drawing.Color.White;
            this.btnProcura.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProcura.FlatAppearance.BorderSize = 0;
            this.btnProcura.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btnProcura.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProcura.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProcura.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnProcura.Image = ((System.Drawing.Image)(resources.GetObject("btnProcura.Image")));
            this.btnProcura.Location = new System.Drawing.Point(194, 409);
            this.btnProcura.Name = "btnProcura";
            this.btnProcura.Size = new System.Drawing.Size(85, 95);
            this.btnProcura.TabIndex = 8;
            this.btnProcura.Text = "Procurar";
            this.btnProcura.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProcura.UseVisualStyleBackColor = false;
            this.btnProcura.Click += new System.EventHandler(this.btnProcura_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(539, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 17);
            this.label4.TabIndex = 80;
            this.label4.Text = "Edição";
            // 
            // txtEdicao
            // 
            this.txtEdicao.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEdicao.Location = new System.Drawing.Point(542, 121);
            this.txtEdicao.Name = "txtEdicao";
            this.txtEdicao.Size = new System.Drawing.Size(105, 23);
            this.txtEdicao.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(683, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 17);
            this.label5.TabIndex = 82;
            this.label5.Text = "Ano";
            // 
            // txtAno
            // 
            this.txtAno.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAno.Location = new System.Drawing.Point(686, 121);
            this.txtAno.Name = "txtAno";
            this.txtAno.Size = new System.Drawing.Size(105, 23);
            this.txtAno.TabIndex = 4;
            // 
            // pbAddAutor
            // 
            this.pbAddAutor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbAddAutor.Image = ((System.Drawing.Image)(resources.GetObject("pbAddAutor.Image")));
            this.pbAddAutor.Location = new System.Drawing.Point(28, 255);
            this.pbAddAutor.Name = "pbAddAutor";
            this.pbAddAutor.Size = new System.Drawing.Size(35, 35);
            this.pbAddAutor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAddAutor.TabIndex = 83;
            this.pbAddAutor.TabStop = false;
            this.pbAddAutor.Click += new System.EventHandler(this.pbAddAutor_Click);
            // 
            // pbRemoveAutor
            // 
            this.pbRemoveAutor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbRemoveAutor.Image = ((System.Drawing.Image)(resources.GetObject("pbRemoveAutor.Image")));
            this.pbRemoveAutor.Location = new System.Drawing.Point(69, 255);
            this.pbRemoveAutor.Name = "pbRemoveAutor";
            this.pbRemoveAutor.Size = new System.Drawing.Size(35, 35);
            this.pbRemoveAutor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbRemoveAutor.TabIndex = 84;
            this.pbRemoveAutor.TabStop = false;
            this.pbRemoveAutor.Click += new System.EventHandler(this.pbRemoveAutor_Click);
            // 
            // pbRemoveGen
            // 
            this.pbRemoveGen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbRemoveGen.Image = ((System.Drawing.Image)(resources.GetObject("pbRemoveGen.Image")));
            this.pbRemoveGen.Location = new System.Drawing.Point(471, 255);
            this.pbRemoveGen.Name = "pbRemoveGen";
            this.pbRemoveGen.Size = new System.Drawing.Size(35, 35);
            this.pbRemoveGen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbRemoveGen.TabIndex = 86;
            this.pbRemoveGen.TabStop = false;
            this.pbRemoveGen.Click += new System.EventHandler(this.pbRemoveGen_Click);
            // 
            // pbAddGen
            // 
            this.pbAddGen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbAddGen.Image = ((System.Drawing.Image)(resources.GetObject("pbAddGen.Image")));
            this.pbAddGen.Location = new System.Drawing.Point(430, 255);
            this.pbAddGen.Name = "pbAddGen";
            this.pbAddGen.Size = new System.Drawing.Size(35, 35);
            this.pbAddGen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAddGen.TabIndex = 85;
            this.pbAddGen.TabStop = false;
            this.pbAddGen.Click += new System.EventHandler(this.pbAddGen_Click);
            // 
            // lblInformeTitulo
            // 
            this.lblInformeTitulo.AutoSize = true;
            this.lblInformeTitulo.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformeTitulo.ForeColor = System.Drawing.Color.Red;
            this.lblInformeTitulo.Location = new System.Drawing.Point(33, 149);
            this.lblInformeTitulo.Name = "lblInformeTitulo";
            this.lblInformeTitulo.Size = new System.Drawing.Size(90, 16);
            this.lblInformeTitulo.TabIndex = 87;
            this.lblInformeTitulo.Text = "Informe o título!";
            this.lblInformeTitulo.Visible = false;
            // 
            // lblInformeEdicao
            // 
            this.lblInformeEdicao.AutoSize = true;
            this.lblInformeEdicao.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformeEdicao.ForeColor = System.Drawing.Color.Red;
            this.lblInformeEdicao.Location = new System.Drawing.Point(543, 147);
            this.lblInformeEdicao.Name = "lblInformeEdicao";
            this.lblInformeEdicao.Size = new System.Drawing.Size(104, 16);
            this.lblInformeEdicao.TabIndex = 88;
            this.lblInformeEdicao.Text = "Informe a edição!";
            this.lblInformeEdicao.Visible = false;
            // 
            // lblInformeAno
            // 
            this.lblInformeAno.AutoSize = true;
            this.lblInformeAno.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformeAno.ForeColor = System.Drawing.Color.Red;
            this.lblInformeAno.Location = new System.Drawing.Point(683, 147);
            this.lblInformeAno.Name = "lblInformeAno";
            this.lblInformeAno.Size = new System.Drawing.Size(86, 16);
            this.lblInformeAno.TabIndex = 89;
            this.lblInformeAno.Text = "Informe o ano!";
            this.lblInformeAno.Visible = false;
            // 
            // lblInformeAutor
            // 
            this.lblInformeAutor.AutoSize = true;
            this.lblInformeAutor.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformeAutor.ForeColor = System.Drawing.Color.Red;
            this.lblInformeAutor.Location = new System.Drawing.Point(20, 302);
            this.lblInformeAutor.Name = "lblInformeAutor";
            this.lblInformeAutor.Size = new System.Drawing.Size(159, 16);
            this.lblInformeAutor.TabIndex = 90;
            this.lblInformeAutor.Text = "Informe ao menos um autor!";
            this.lblInformeAutor.Visible = false;
            // 
            // lblInformeGenero
            // 
            this.lblInformeGenero.AutoSize = true;
            this.lblInformeGenero.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformeGenero.ForeColor = System.Drawing.Color.Red;
            this.lblInformeGenero.Location = new System.Drawing.Point(417, 302);
            this.lblInformeGenero.Name = "lblInformeGenero";
            this.lblInformeGenero.Size = new System.Drawing.Size(168, 16);
            this.lblInformeGenero.TabIndex = 91;
            this.lblInformeGenero.Text = "Informe ao menos um gênero!";
            this.lblInformeGenero.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(321, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 17);
            this.label6.TabIndex = 92;
            this.label6.Text = "Editora";
            // 
            // cbEditora
            // 
            this.cbEditora.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEditora.FormattingEnabled = true;
            this.cbEditora.Location = new System.Drawing.Point(324, 121);
            this.cbEditora.Name = "cbEditora";
            this.cbEditora.Size = new System.Drawing.Size(182, 25);
            this.cbEditora.TabIndex = 2;
            // 
            // lblInformaEditora
            // 
            this.lblInformaEditora.AutoSize = true;
            this.lblInformaEditora.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInformaEditora.ForeColor = System.Drawing.Color.Red;
            this.lblInformaEditora.Location = new System.Drawing.Point(327, 149);
            this.lblInformaEditora.Name = "lblInformaEditora";
            this.lblInformaEditora.Size = new System.Drawing.Size(104, 16);
            this.lblInformaEditora.TabIndex = 94;
            this.lblInformaEditora.Text = "Informe a editora!";
            this.lblInformaEditora.Visible = false;
            // 
            // txtCodigoAutor
            // 
            this.txtCodigoAutor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodigoAutor.Enabled = false;
            this.txtCodigoAutor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoAutor.Location = new System.Drawing.Point(23, 333);
            this.txtCodigoAutor.Name = "txtCodigoAutor";
            this.txtCodigoAutor.Size = new System.Drawing.Size(45, 23);
            this.txtCodigoAutor.TabIndex = 95;
            this.txtCodigoAutor.Visible = false;
            // 
            // txtCodigoGen
            // 
            this.txtCodigoGen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodigoGen.Enabled = false;
            this.txtCodigoGen.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoGen.Location = new System.Drawing.Point(420, 333);
            this.txtCodigoGen.Name = "txtCodigoGen";
            this.txtCodigoGen.Size = new System.Drawing.Size(45, 23);
            this.txtCodigoGen.TabIndex = 96;
            this.txtCodigoGen.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pbFechaForm);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(833, 32);
            this.panel1.TabIndex = 97;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(9, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(345, 17);
            this.label7.TabIndex = 100;
            this.label7.Text = "*Para cadastrar os exemplares clique em +Exemplar";
            // 
            // btnMultiplica
            // 
            this.btnMultiplica.BackColor = System.Drawing.Color.White;
            this.btnMultiplica.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMultiplica.FlatAppearance.BorderSize = 0;
            this.btnMultiplica.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SkyBlue;
            this.btnMultiplica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMultiplica.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplica.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnMultiplica.Image = ((System.Drawing.Image)(resources.GetObject("btnMultiplica.Image")));
            this.btnMultiplica.Location = new System.Drawing.Point(705, 409);
            this.btnMultiplica.Name = "btnMultiplica";
            this.btnMultiplica.Size = new System.Drawing.Size(85, 95);
            this.btnMultiplica.TabIndex = 12;
            this.btnMultiplica.Text = "Exemplar";
            this.btnMultiplica.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMultiplica.UseVisualStyleBackColor = false;
            this.btnMultiplica.Click += new System.EventHandler(this.btnMultiplica_Click);
            // 
            // CadastrarLivro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(833, 531);
            this.Controls.Add(this.btnMultiplica);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtCodigoGen);
            this.Controls.Add(this.txtCodigoAutor);
            this.Controls.Add(this.lblInformaEditora);
            this.Controls.Add(this.cbEditora);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblInformeGenero);
            this.Controls.Add(this.lblInformeAutor);
            this.Controls.Add(this.lblInformeAno);
            this.Controls.Add(this.lblInformeEdicao);
            this.Controls.Add(this.lblInformeTitulo);
            this.Controls.Add(this.pbRemoveGen);
            this.Controls.Add(this.pbAddGen);
            this.Controls.Add(this.pbRemoveAutor);
            this.Controls.Add(this.pbAddAutor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAno);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtEdicao);
            this.Controls.Add(this.btnNovo);
            this.Controls.Add(this.btnAlterar);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnProcura);
            this.Controls.Add(this.dgvGenero);
            this.Controls.Add(this.cbGenero);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvAutor);
            this.Controls.Add(this.cbAutor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CadastrarLivro";
            this.Text = "CadastrarLivro";
            this.Load += new System.EventHandler(this.CadastrarLivro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAutor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGenero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddAutor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRemoveAutor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRemoveGen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddGen)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.TextBox txtTitulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbAutor;
        private System.Windows.Forms.DataGridView dgvAutor;
        private System.Windows.Forms.DataGridView dgvGenero;
        private System.Windows.Forms.ComboBox cbGenero;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnAlterar;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnProcura;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEdicao;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAno;
        private System.Windows.Forms.PictureBox pbAddAutor;
        private System.Windows.Forms.PictureBox pbRemoveAutor;
        private System.Windows.Forms.PictureBox pbRemoveGen;
        private System.Windows.Forms.PictureBox pbAddGen;
        private System.Windows.Forms.Label lblInformeTitulo;
        private System.Windows.Forms.Label lblInformeEdicao;
        private System.Windows.Forms.Label lblInformeAno;
        private System.Windows.Forms.Label lblInformeAutor;
        private System.Windows.Forms.Label lblInformeGenero;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbEditora;
        private System.Windows.Forms.Label lblInformaEditora;
        private System.Windows.Forms.TextBox txtCodigoAutor;
        private System.Windows.Forms.TextBox txtCodigoGen;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnMultiplica;
        private System.Windows.Forms.Label label7;
    }
}