﻿namespace Biblioteca
{
    partial class LocalizaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocalizaUsuario));
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dgvLocalizaUsuario = new System.Windows.Forms.DataGridView();
            this.pbFechaForm = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaUsuario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnLocaliza.FlatAppearance.BorderSize = 0;
            this.btnLocaliza.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnLocaliza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocaliza.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocaliza.ForeColor = System.Drawing.Color.White;
            this.btnLocaliza.Location = new System.Drawing.Point(302, 53);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(128, 23);
            this.btnLocaliza.TabIndex = 73;
            this.btnLocaliza.Text = "Buscar";
            this.btnLocaliza.UseVisualStyleBackColor = false;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // txtUsuario
            // 
            this.txtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsuario.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsuario.Location = new System.Drawing.Point(37, 54);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(239, 23);
            this.txtUsuario.TabIndex = 71;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(34, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 17);
            this.label9.TabIndex = 72;
            this.label9.Text = "Usuário";
            // 
            // dgvLocalizaUsuario
            // 
            this.dgvLocalizaUsuario.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.dgvLocalizaUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLocalizaUsuario.Location = new System.Drawing.Point(37, 83);
            this.dgvLocalizaUsuario.MultiSelect = false;
            this.dgvLocalizaUsuario.Name = "dgvLocalizaUsuario";
            this.dgvLocalizaUsuario.Size = new System.Drawing.Size(393, 250);
            this.dgvLocalizaUsuario.TabIndex = 70;
            this.dgvLocalizaUsuario.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLocalizaUsuario_CellDoubleClick);
            // 
            // pbFechaForm
            // 
            this.pbFechaForm.BackColor = System.Drawing.Color.Black;
            this.pbFechaForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbFechaForm.Image = ((System.Drawing.Image)(resources.GetObject("pbFechaForm.Image")));
            this.pbFechaForm.Location = new System.Drawing.Point(451, 3);
            this.pbFechaForm.Name = "pbFechaForm";
            this.pbFechaForm.Size = new System.Drawing.Size(20, 19);
            this.pbFechaForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFechaForm.TabIndex = 69;
            this.pbFechaForm.TabStop = false;
            this.pbFechaForm.Click += new System.EventHandler(this.pbFechaForm_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnLocaliza);
            this.panel1.Controls.Add(this.pbFechaForm);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txtUsuario);
            this.panel1.Controls.Add(this.dgvLocalizaUsuario);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(476, 365);
            this.panel1.TabIndex = 74;
            // 
            // LocalizaUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(500, 390);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LocalizaUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LocalizaUsuario";
            this.Load += new System.EventHandler(this.LocalizaUsuario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLocalizaUsuario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFechaForm)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgvLocalizaUsuario;
        private System.Windows.Forms.PictureBox pbFechaForm;
        private System.Windows.Forms.Panel panel1;
    }
}