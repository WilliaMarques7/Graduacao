use biblioteca

select * from TipoUsuario
select * from livro
select * from autor
select * from genero
select * from usuario
select * from Livro_Autor
select * from Livro_Genero
select * from Multa where Data_Multa = (select max(Data_Multa) from Multa )
select * from Funcionario
select * from Tipo_Funcionario
select * from Emprestimo
select * from exemplares
select * from Inadimplentes

-------------------------------------Relat�rios-------------------------------------
--Relatorio 01
ALTER view vw_UsuariosPorTipo as
select usu.Codigo_Usuario as [C�digo Usu�rio], usu.Nome, usu.TipoUsuario_codigo as [C�digo Tipo de Usu�rio],
tusu.Tipo from Usuario usu
inner join TipoUsuario tusu on usu.TipoUsuario_codigo = tusu.Codigo_TipoUsuario
group by tusu.Tipo, usu.Codigo_Usuario, usu.Nome, tusu.Codigo_TipoUsuario, usu.TipoUsuario_codigo
order by Nome

select * from vw_UsuariosPorTipo

--Relatorio 02
alter view vw_RelacaoEmprestimo as
select emp.Codigo_Emprestimo as [C�digo empr�stimo], usu.Nome as Usu�rio, liv.Titulo as Livro,
exe.Codigo_Exemplar as [C�digo exemplar], (case when emp.Data_EfetivaDevolucao is null then 'N�o devolvido' else 'Devolvido' end) as StatusEmp,
emp.Data_Emprestimo as [Data do Empr�stimo],
emp.Data_PrevistaDevolucao as [Data prevista para de volu��o], emp.Data_EfetivaDevolucao as [Data efetiva da devolu��o]
from Emprestimo emp
inner join Usuario usu on emp.Codigo_Usuario =  usu.Codigo_Usuario
inner join Exemplares exe on emp.Codigo_Exemplar = exe.Codigo_Exemplar
inner join Livro liv on exe.Codigo_Livro = liv.Codigo_livro

select * from vw_RelacaoEmprestimo
 
--Relatorio 03
alter view vw_MultaPendente as
select ina.Codigo_Inadimplente as [C�digo multa], ina.Multa_Dat as Data, usu.Nome as Usu�rio, ina.Multa_Valor as Valor
from Inadimplentes ina
inner join Usuario usu on ina.Codigo_Usuario = usu.Codigo_Usuario
where ina.Multa_Paga = 'N'

select * from vw_MultaPendente
-------------------------------------Relat�rios-------------------------------------




select li.Codigo_livro as codigo, li.Titulo, au.Nome as Autor, ge.Tipo_Genero as Genero, ed.nome as Editora 
from Livro li
inner join livro_autor al on li.Codigo_livro = al.Codigo_Livro
inner join Autor au on al.Codigo_Autor = au.Codigo_Autor
inner join Livro_Genero ag on li.Codigo_livro = ag.Codigo_livro
inner join Genero ge on ag.Codigo_Genero = ge.Codigo_Genero
inner join Editora ed on li.codigo_editora = ed.codigo_editora

select * from vw_LivroAutor
select lia.*, aut.Codigo_Autor, aut.Nome, lia.Codigo_Livro from Livro_Autor lia
inner join Autor aut on lia.Codigo_Autor = aut.Codigo_Autor
where Codigo_Livro = 3


select li.Codigo_livro, li.Titulo, COUNT(exe.Codigo_Exemplar) as [QTD exemplares] from Livro li
inner join Exemplares exe on li.Codigo_livro = exe.Codigo_Livro
group by li.Codigo_livro, li.Titulo

alter view vw_LivroExemplar as
select exe.Codigo_Exemplar as Exemplar, li.Codigo_livro as Livro, li.Titulo,
exe.Status_Livro as [Status do exemplar] from Livro li
inner join Exemplares exe on li.Codigo_livro = exe.Codigo_Livro

select * from vw_LivroExemplar
order by titulo


create view vw_LivroExemplarDisponivel as
select exe.Codigo_Exemplar as Exemplar, li.Codigo_livro as Livro, li.Titulo,
exe.Status_Livro as [Status do exemplar] from Livro li
inner join Exemplares exe on li.Codigo_livro = exe.Codigo_Livro
where Status_Livro = 'D'

select * from vw_LivroExemplarDisponivel
order by titulo

create view vw_PrazoUsuario as
select usu.Codigo_Usuario, tusu.Codigo_TipoUsuario, tusu.Prazo from usuario usu
inner join TipoUsuario tusu on usu.TipoUsuario_codigo= tusu.Codigo_TipoUsuario

select * from vw_PrazoUsuario 

alter view vw_UsuariosAtivos as
select * from usuario
where status = 'S'

select * from vw_UsuariosAtivos

alter view vw_QuantidadeLivrosUsuario as
select usu.Codigo_Usuario, tusu.Quantidade_Livros, COUNT(emp.Codigo_Emprestimo) as [Quantidade de empr�stimos] 
from emprestimo emp
inner join Usuario usu on emp.Codigo_Usuario = usu.Codigo_Usuario
inner join TipoUsuario tusu on usu.TipoUsuario_codigo = tusu.Codigo_TipoUsuario
where emp.Data_EfetivaDevolucao is null
group by usu.Codigo_Usuario, tusu.Tipo, tusu.Quantidade_Livros

select * from vw_QuantidadeLivrosUsuario

--delete from Emprestimo
--where Codigo_Emprestimo = 25

alter view vw_ExemplarRepetido as
select emp.Codigo_Usuario, emp.Codigo_Exemplar, li.Codigo_Livro, li.Titulo, emp.Data_EfetivaDevolucao 
from Emprestimo emp
inner join Exemplares exe on emp.Codigo_Exemplar = exe.Codigo_Exemplar
inner join Livro li on exe.Codigo_Livro = li.Codigo_livro

select * from vw_ExemplarRepetido

--update exemplares
--set status_livro = 'D'
--where codigo_exemplar = 7

alter view vw_EmprestimosPendentes as
select emp.Codigo_Emprestimo, emp.Codigo_Usuario, emp.Codigo_Exemplar, li.Titulo, 
Convert(varchar(11), emp.Data_Emprestimo, 103) as [Data_Emprestimo], 
Convert(varchar(11), emp.Data_PrevistaDevolucao, 103) as [Data_Devolucao],
emp.Data_EfetivaDevolucao
from emprestimo emp
inner join exemplares exe on emp.Codigo_Exemplar = exe.Codigo_Exemplar
inner join Livro li on exe.Codigo_Livro = li.Codigo_livro
where emp.Data_efetivaDevolucao is null

select * from vw_EmprestimosPendentes


--CREATE TRIGGER tg_StatusExemplar 
--   ON  Emprestimo 
--   AFTER UPDATE
--AS 
--BEGIN
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;

--    Declare @exemplar int
--	select @exemplar =  Codigo_Exemplar from inserted

--	update Exemplares
--	set Status_Livro = 'D'
--	where Codigo_Exemplar = @exemplar

--END
--GO

create view vw_ValorAtual as
select * from Multa where Data_Multa = (select max(Data_Multa) from Multa )

select * from vw_ValorAtual

alter view vw_UsuarioPgMulta as
select usu.codigo_usuario, usu.nome, ina.Codigo_Inadimplente, ina.Multa_Paga, ina.Multa_Valor,
ina.Multa_Dat, ina.Multa_DataPagamento
from usuario usu
inner join inadimplentes ina on usu.codigo_usuario = ina.codigo_usuario
where ina.Multa_Paga = 'N'

select * from vw_UsuarioPgMulta